let utils = require('../utils.js')

const fs = require('fs'); 

let clans = require("../database/clans.json");

let botinfo = require("../database/botinfo.json");

let chats = require('../database/chats.json')

let double = require('../database/users.json')

let bossinfo = require('../database/bossinfo.json')

const commands = []

async function upplazma() {
  rand = utils.random(1, 15);

  botinfo.kursplazma = Math.floor(Number(rand * 100000000000));
}

async function upobsidian() {
  rand = utils.random(10, 25);

  botinfo.kursobsidian = Math.floor(Number(rand * 10000000000));
}

async function upmateria() {
  rand = utils.random(1, 16);

  botinfo.kursmateria = Math.floor(Number(rand * 1000000000));
}

async function upalmaz() {
  rand = utils.random(1, 200);

  botinfo.kursalmaz = Math.floor(Number(rand * 1000000));
}

async function upzoloto() {
  rand = utils.random(1, 40);

  botinfo.kurszoloto = Math.floor(Number(rand * 100000));
}

async function upzhelezo() {
  rand = utils.random(1, 50);

  botinfo.kurszhelezo = Math.floor(Number(rand * 10000));
}

async function saveBlago() {
  require("fs").writeFileSync(
    "./save/blago.json",
    JSON.stringify(blago, null, "\t")
  );

  return true;
}
async function saveClan() {
require("fs").writeFileSync(
  "./database/clans.json",
  JSON.stringify(clans, null, "\t")
);
  return true;
}
  


async function saveBoss() {
  require("fs").writeFileSync(
    "./database/bossinfo.json",
    JSON.stringify(bossinfo, null, "\t")
  );

  return true;
}


async function saveAll() {
  require("fs").writeFileSync(
    "./database/botinfo.json",
    JSON.stringify(botinfo, null, "\t")
  );
  return true;
  }

async function saveC()
{
fs.writeFileSync('./database/chats.json', JSON.stringify(chats, null, '\t'));
return true;
}


function saveU() {
  let data;

  try {
    fs.writeFileSync('./database/users.json', JSON.stringify(double, null, '\t')); // Можно перезаписать файл тут, если нужно
  } catch (err) {
    console.error('Ошибка при записи в users.json:', err);
    return false;
  }


  // Читаем данные из JSON файла
  try {
    data = fs.readFileSync('./database/users.json', 'utf8');
  } catch (err) {
    console.error('Ошибка при чтении файла:', err);
    return false;
  }

  // Конвертируем данные JSON в строку
  const users = JSON.stringify(JSON.parse(data), null, '\t');

  // Записываем пользователей в текстовый файл
  try {
    fs.writeFileSync('./database/users.txt', users + '\n');
  } catch (err) {
    console.error('Ошибка при записи в файл:', err);
    return false;
  }

  // Если нужно, можно перезаписать файл users.json с обновлёнными данными (но в данном случае это просто сохраняет то же самое)

  return true;
}





setInterval(async () => {

  await saveAll();
  await saveU();
  await saveC();
  await saveBoss();
  await upplazma();
  await upobsidian();
  await upmateria();
  await upalmaz();
  await upzoloto();
  await upzhelezo();
  await saveBoss()
  await saveClan()

	}, 60000);


 module.exports = commands;
