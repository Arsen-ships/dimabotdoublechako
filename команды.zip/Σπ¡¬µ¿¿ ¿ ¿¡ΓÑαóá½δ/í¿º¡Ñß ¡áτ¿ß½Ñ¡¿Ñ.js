let utils = require('../utils.js')

const commands =[]

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};



const businesses=require('../spisok/business spisok.js')

let double = require('../database/users.json')

let fink=true;

setInterval(async () => {
  if (!fink) {
    return;
  }
  if (fink) {
  double
      .filter((x) => x.bans.ban === false)
      .map((user) => {
        for (let i = 0; i < user.business.length; i++) {
          const biz =
            businesses[user.business[i].id - 1][user.business[i].upgrade - 1];

          if (user.business[i].moneys <= biz.earn * 100)
            user.business[i].moneys += Math.floor(
              (biz.earn / biz.workers) * user.business[i].workers
            );
        }
      });
  }
}, 3600000);




module.exports = commands;
