let utils = require('../utils.js')

const commands = [];

let botinfo = require("../database/botinfo.json");

const fs = require('fs');

let double = require('../database/users.json')

let chats = require('../database/chats.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:репорт)\s(.+)$/i, async (message, bot) => {
  if (message.user.rep == true) return  bot(`Дождитесь ответа на ваш предыдущий репорт.`)
  try {
    if (!message.user.timers.timereport) message.user.timers.timereport = 0;
  // Проверка блокировки репорта
  if (message.user.bans.rban) return message.send(`❌ @id${message.user.id} (${message.user.tag}), не удалось написать в репорт, потому-что Вы имеете блокировку РЕПОРТА.`);

  // Проверка таймера
  if (message.user.timers.timereport > Date.now()) {
    const timeLeft = message.user.timers.timereport - Date.now();
    const minutes = Math.floor(timeLeft / 60000);
    const seconds = Math.floor((timeLeft % 60000) / 1000);
    return message.send(`⏳ @id${message.user.id} (${message.user.tag}), подождите чуть-чуть! 😫\n\n📥 Писать в репорт можно РАЗ в 5 МИНУТ (осталось: ${minutes} мин. ${seconds} сек.)`);
  }
  // Проверка лимита символов
  if (message.args[1].length > 100) return message.send(`❌ @id${message.user.id} (${message.user.tag}), вы превысили лимит 100 символов. Попробуйте укоротить текст.`);

  // Проверка уровня администратора
  if (message.user.settings.adm > 1) return message.send(`❌ @id${message.user.id} (${message.user.tag}), у вас нет прав на отправку репортов.`);

  // Установка нового таймера
  message.user.timers.timereport = Date.now() + 300000; // 5 минут

  // Обновление информации о репорте
  botinfo.reports += 1;
  message.user.rep = true;
  message.user.vopros = message.args[1];

  let smileng = utils.pick([`🌷`, `🌸`, `🌹`, `🌺`, `🌼`, `💐`, `❤️`, `💓`, `💕`]);

  // Отправка репорта
  vk.api.messages.send({
    chat_id: chatlogi,
    forward_messages: message.id,
    message: `✏️ НОВЫЙ РЕПОРТ! ☃️ 🆕

▶️ Отправил игрок › @id${message.user.id} (${message.user.tag})[ID: ${message.user.uid}]
💬 Текст жалобы › «${message.args[1]}»

🔩 Для ответа используйте › «Ответ [ID игрока] [текст]»

@all 🎅`,
    random_id: getRandomId()
  });

  // Ответ пользователю
  return message.send(`✅ @id${message.user.id} (${message.user.tag}), успешно! Сообщение было доставлено до администрации, ожидайте в скором времени ответа от администрации 💬`);
} catch (error) {
  console.error(error);
  return message.send(`❌ Произошла ошибка при отправке вашего репорта. Попробуйте позже.`);
}
});

const getRandomId = () => (Math.floor(Math.random() * 10000) * Date.now());

cmd.hear(/^(?:ответ)\s([0-9]+)\s([^]+)$/i, async (message, bot) => {

  if (message.user.ochenka === undefined) {
    message.user.ochenka = false;
  }
  if (message.user.ochenka === true) {
    message.user.ochenka = false;
  }
  // Если доступ к ответу не задан, установить его в false
 /* if (message.user.answeraccess === undefined) {
    message.user.answeraccess = false;
  } else {
    // Если доступ к ответу false, выходим
    if (message.user.answeraccess === false) return;
  }*/

  // Проверка прав пользователя
  if (message.user.settings.adm < 1 && !message.user.settings.agent) return;

  // Поиск пользователя по UID
  const user = await double.find(x => x.uid == message.args[1]);
  if (!user) return

  // Проверка, уже ли отвечали пользователю
  if (user.rep === false) return bot(`Игроку уже ответили! 😁`);
  user.rep = false; 
  user.admid = message.user.uid; // Сохраняем UID администратора

  message.user.astats.reports += 1; // Увеличиваем количество репортов пользователя
  message.user.rubli += 1; // Увеличиваем донат-рубли

  // Отправка сообщения пользователю
  await vk.api.messages.send({
    user_id: user.id,
    random_id: getRandomId(),
    message: `▶️ @id${message.user.id}(ADMINISTRATOR) успешно ответил на Ваш репорт!\n\n💬 Его ответ: ${message.args[2]} | Приятной игры 😉\n\n✳️ Для оценки работы администратора нажмите на кнопку ниже.`,

    keyboard: JSON.stringify({
      "inline": true,
      "buttons": [
        [{
          "action": {
            "type": "text",
            "payload": { command: `оценить ${message.user.uid} положительно` },
            "label": "👍"
          },
          "color": "default"
        },
        {
          "action": {
            "type": "text",
            "payload": { command: `оценить ${message.user.uid} отрицательно` },
            "label": "👎"
          },
          "color": "default"
        }]
      ]
    })
  }).catch(error => {
    console.error(`Ошибка при отправке сообщения: ${error}`);
  });

  // Выбор случайного смайла из списка
  let smileng = utils.pick([`🌷`, `🌸`, `🌹`, `🌺`, `🌼`, `💐`, `❤️`, `💓`, `💕`]);

  return bot(`Вы успешно ответили игроку @id${user.id} (${user.tag}) на его вопрос! 💬\n+1 донат-рубль 💵`);
});

cmd.hear(/^(?:оценить)\s([0-9]+)\s(.*)$/i, async (message, bot) => {




  // Поиск пользователя по uid
  let user = double.find(x => x.uid === Number(message.args[1]));
  if (!user) {
    console.log('Ошибка: пользователь не найден.');
    return bot(`👤 Пользователь не найден.`);
  }

  if (user.ochenka) {
    return bot(`❌ Вы уже оценивали этого администратора. Оценивание возможно только один раз.`);
  }

  let ratingMessage;
  let smileng = utils.pick([`🌷`, `🌸`, `🌹`, `🌺`, `🌼`, `💐`, `❤️`, `💓`, `💕`]);

  // Оценка положительная
  if (message.args[2].toLowerCase() === "положительно") {

    user.astats.norm += 1;
    user.ochenka = true
    message.user.rep = true;
    message.user.admid = false;

    ratingMessage = `▶️ Игрок @id${message.user.id} (${message.user.tag}) оценил Ваш ответ на положительно! 👍${smileng}\n` +
      `〽️ Ваша репутация: ${utils.sp(user.astats.norm)} 👍 | ${utils.sp(user.astats.bad)} 👎`;
  }

  // Оценка отрицательная
  else if (message.args[2].toLowerCase() === "отрицательно") {
    user.astats.bad += 1;
    user.ochenka = true
    message.user.rep = true;
    message.user.admid = false;

    ratingMessage = `▶️ Игрок @id${message.user.id} (${message.user.tag}) оценил Ваш ответ на отрицательно 👎${smileng}\n` +
      `〽️ Ваша репутация: ${utils.sp(user.astats.norm)} 👍 | ${utils.sp(user.astats.bad)} 👎`;
  } else {
    console.log('Ошибка: некорректная оценка.');
    return bot(`❓ Пожалуйста, укажите корректную оценку: «положительно» или «отрицательно».`);
  }

  // Отправляем сообщение пользователю
  try {
    console.log(`Отправка сообщения пользователю @id${user.id}:`, ratingMessage);
    await vk.api.messages.send({
      user_id: user.id,
      random_id: getRandomId(),
      message: ratingMessage
    });
  } catch (error) {
    console.error(`Ошибка при отправке сообщения: ${error}`);
    return bot(`❌ Не удалось уведомить администратора о вашей оценке.`);
  }

  return bot(`Вы успешно оценили работу администратора на «${message.args[2]}» (${message.args[2] === "положительно" ? "👍" : "👎"}).\n` +
    `😮 Благодарим за оценку, это нам помогает анализировать работу администрации! Администратор будет успешно уведомлён о Вашей оценке.`, { attachment: `photo-203302510_457239156` });
});



cmd.hear(/^(?:асмс)\s([0-9]+)\s([^]+)$/i, async (message, bot) => {
  try {
    if (message.user.settings.adm < 1 && message.user.settings.agent < 1) return;

    if (!message.user.answeraccess) return; // Упрощенная проверка.

    const userId = Number(message.args[1]);
    if (isNaN(userId)) return; // Проверка номера игрока.

    const user = await double.find(x => x.uid === userId);
    if (!user || !user.id) return; // Проверка существования.

    await vk.api.messages.send({
      user_id: user.id,
      message: `▶️ Администратор / агент написал Вам сообщение: ❄️\n✏️ Текст: «${message.args[2]}» ✅`,
      random_id: getRandomId()
    });
  } catch (error) {
    return;
  }

  return bot(`Вы успешно написали игроку сообщение ❄️\n📩 Текст: «${message.args[2]}»`);
});

cmd.hear(/^(?:рбан|rban)\s([0-9]+)$/i, async (message, bot) => {

  if (message.user.settings.adm < 1 && message.user.settings.agent < 1) return;

  if (message.args[1] == 0 || message.args[1] == 1 || message.args[1] == 2033) return bot(`Ваше действие было зарегистрировано и отправлено в специальную беседу логов.`);



  let user = double.find(x => x.uid === Number(message.args[1]));

  if (!user) return bot(`Такого игрока не существует! ❌`);

  if (user.bans.rban != false) return bot(`у игрока уже закрыт репорт ❌`);

  user.bans.rbantimer = Date.now() + 201600000;

  user.bans.rban = true;

  user.stock.strban = "Да";

  message.user.astats.rbans += 1;



  return bot(`вы выдали бан репорта игроку - @id${user.id} (${user.tag}) ❌`);

});



cmd.hear(/^(?:рразбан|runban)\s([0-9]+)$/i, async (message, bot) => {

  if (message.user.settings.adm < 1 && message.user.settings.agent < 1) return;



  let user = double.find(x => x.uid === Number(message.args[1]));

  if (!user) return bot(`Такого игрока не существует! ❌`);

  if (user.bans.rban != true) return bot(`у игрока репорт уже включён 🙃`);

  user.bans.rbantimer = 0;

  user.bans.rban = false;

  user.stock.strban = "Нет";



  return bot(`вы разбанили репорт игроку - @id${user.id} (${user.tag}) ✅`);

});

cmd.hear(/^(?:нреп)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1 && message.user.settings.agent < 1) return;
  let i = 0;
  let test = ``;
  let user = double.filter(x => x.rep === true).map(x => {
    i += 1;
    test += `№${i}. @id${x.id} (${x.tag}) (ID › ${x.uid}). Вопрос › ${x.vopros}\n\n`;
  });

  return bot(`неотвеченные репорты/вопросы:

${test}`);

});









module.exports = commands;
