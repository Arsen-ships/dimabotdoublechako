let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

let blago = require('../database/blago.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

function addZero(i) {
  return i < 10 ? "0" + i : i;
}

function unixStampLefta(stampa) {
  stampa = stampa / 1000;
  let s = stampa % 60;
  stampa = (stampa - s) / 60;
  let m = stampa % 60;
  let text = ``;
  if (m > 0) text += addZero(Math.floor(m)) + " мин. ";
  if (s > 0) text += addZero(Math.floor(s)) + " сек.";
  return text;
}

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });


cmd.hear(
  /^(?:благотворительность положить|благо положить)\s(.*)$/i,
  async (message, bot) => {
    if (blago.balance === undefined || isNaN(blago.balance)) {
      blago.balance = 0;
    }
    let smileng = utils.pick([
      `🌷`,
      `🌸`,
      `🌹`,
      `🌺`,
      `🌼`,
      `💐`,
      `❤️`,
      `💓`,
      `💕`,
    ]);

    message.args[1] = message.args[1].replace(/([.,])/gi, "");

    message.args[1] = message.args[1].replace(/([кk])/gi, "000");

    message.args[1] = message.args[1].replace(/(м|m)/gi, "000000");

    message.args[1] = message.args[1].replace(
      /(вабанк|вобанк|все|всё)/gi,
      message.user.balance
    );

    if (!Number(message.args[1])) return;

    if (message.args[1] < 0) return;

    if (Number(message.args[1]) > message.user.balance)
      return bot(`на вашем балансе столько нет!

💰 Баланс: ${utils.sp(message.user.balance)}$ ${smileng}`);

    if (message.user.settings.adm) return bot(`администрации запрещено!`);

    if (message.user.inf === true) return bot(`Выключите безлимитный баланс!`);

    if (message.args[1] > 1000000000000000)
      return bot(`За один раз больше 1.000.000.000.000.000$ положить нельзя`);

    message.args[1] = Math.floor(Number(message.args[1]));

    blago.balance += message.args[1];

    message.user.balance -= message.args[1];

    await bot(
      `вы успешно положили в благотворительный фонд «Алёша» ${utils.sp(
        message.args[1]
      )}$\n\n▶️ Остаток на балансе: ${utils.sp(
        message.user.balance
      )}$ 💰\n${smileng}`
    );
  }
);

cmd.hear(
  /^(?:благотворительность снять|снять благотворительность)$/i,
  async (message, bot) => {
    if (message.user.bral === undefined) {
      message.user.bral = Date.now() + 86400000;
    }

    if (message.user.bral > Date.now())
      return bot(`вы уже брали деньги с банка благотворительности! ❌
⏳ Подождите ещё ${unixStampLefta(message.user.bral - Date.now())}!`);

    message.user.balance += Math.floor(Number(blago.balance * 0.02));

    blago.balance -= Math.floor(Number(blago.balance * 0.02));

    message.user.bral = Date.now() + 86400000;

    return bot(`вы сняли с счета благотворительности ${utils.sp(
      blago.balance * 0.02
    )}$ 💰
⏳ Возвращайся через ${unixStampLefta(message.user.bral - Date.now())}!`);
  }
);

cmd.hear(
  /^(?:благо|благотворительный фонд|фонд|благотворительный|благотворительность)$/i,
  async (message) => {
    return message.send(
      `✌️ @id${message.user.id} (${message.user.tag
      }), благотворительный фонд «Алёша» — это помощь новичкам в боте.
👨🏻‍💻 Новички и игроки смогут брать 2% с баланса фонда каждые сутки, и тратить их куда угодно.
↪️ Снять деньги с благотворительности: "благотворительность снять"
💬 Положить деньги: "благотворительность положить [сумма]"
💵 Банк благотворительности: ${utils.sp(blago.balance)}$`,
      { attachment: `photo-228669263_457239017` }
    );
  }
);

cmd.hear(
  /^(?:благотворительность снять|снять благотворительность)$/i,
  async (message, bot) => {
    if (message.user.bral === undefined) {
      message.user.bral = Date.now() + 86400000;
    }

    if (message.user.bral > Date.now())
      return bot(`вы уже брали деньги с банка благотворительности! ❌
⏳ Подождите ещё ${unixStampLefta(message.user.bral - Date.now())}!`);

    message.user.balance += Math.floor(Number(blago.balance * 0.02));

    blago.balance -= Math.floor(Number(blago.balance * 0.02));

    message.user.bral = Date.now() + 86400000;

    return bot(`вы сняли с счета благотворительности ${utils.sp(
      blago.balance * 0.02
    )}$ 💰
⏳ Возвращайся через ${unixStampLefta(message.user.bral - Date.now())}!`);
  }
);

cmd.hear(
  /^(?:благо|благотворительный фонд|фонд|благотворительный|благотворительность)$/i,
  async (message) => {
    return message.send(
      `✌️ @id${message.user.id} (${message.user.tag
      }), благотворительный фонд «Алёша» — это помощь новичкам в боте.
👨🏻‍💻 Новички и игроки смогут брать 2% с баланса фонда каждые сутки, и тратить их куда угодно.
↪️ Снять деньги с благотворительности: "благотворительность снять"
💬 Положить деньги: "благотворительность положить [сумма]"
💵 Банк благотворительности: ${utils.sp(blago.balance)}$`,
      { attachment: `photo-228669263_457239017` }
    );
  }
);


module.exports = commands;
