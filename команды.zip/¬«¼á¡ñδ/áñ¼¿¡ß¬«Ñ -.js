let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')
let chats = require('../database/chats.json')
let log = require('../database/log.json')
let botinfo = require('../database/botinfo.json')
let clans = require('../database/clans.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens;
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null;
  }
}


function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');

  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}
let cars = require('../spisok/машины.js')
let trees = require('../spisok/деревья.js')
let presidents = require("../database/presidents.json");
let autosounder = require('../spisok/autosounder.js')
let sound = require('../spisok/машина динамики.js')
let pets = require('../spisok/питомцы.js')
let pets2 = require('../spisok/питомцы2.js')
let pets3 = require('../spisok/питомцы3.js')
let petsupd = require('../spisok/питомцыул.js')
let yachts = require('../spisok/яхты.js')
let airplanes = require('../spisok/самолеты.js')
let helicopters = require('../spisok/вертолеты.js')
let apartments = require('../spisok/апартаменты.js')
let homes = require('../spisok/дома.js')
let videocards = require('../spisok/видеокарты.js')
let farms = require('../spisok/фермы.js')
let minertool = require('../spisok/инструменты.js')
let computers = require('../spisok/компьютеры.js')
let works = require('../spisok/работники.js')
let businesses2 = require("../spisok/бизнесы.js")
let businesses = require("../spisok/business spisok.js")

const tokenData = getToken();

const chatlogi = tokenData.chatlogi; 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });




cmd.hear(/^(?:acmd|акмд|ахелп|ahelp)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.settings.adm < 1 && message.user.settings.agent === false)
      return;

    bot(`админ-команды: ❄️`, {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",

                payload: '{"button": "1"}',

                label: "🔅 Модератора",
              },

              color: "default",
            },

            {
              action: {
                type: "text",

                payload: "{}",

                label: "🔺 Администратора",
              },

              color: "default",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "🔹 Главного администратора",
              },

              color: "default",
            },
          ],
        ],
      }),
    });
  }
});

cmd.hear(/^🔅 Модератора$/i, async (message) => {
  if (message.chat.type === 0) {
    if (
      message.user.settings.adm > 0 ||
      message.user.stock.status === "🔥Support"
    ) {
      let user = double.find((x) => x.id === message.senderId);

      message.send(`💬 Список всех команд модератора отправлены Вам в ЛС.`);

      await vk.api.messages.send({
        user_id: user.id,
        random_id: 0,
        message: `Команды модератора:

💵 Экономические:
1️⃣ Выдать банк [ID] [сумма]
2️⃣ Выдать BTC [ID] [сумма]
3️⃣ Фбал
4️⃣ Фопыт
5️⃣ -
➖➖➖➖➖➖
😡 Блокировки:
6️⃣ Пбан/празбан [ID]
7️⃣ Рбан/рразбан [ID]
8️⃣ Бан час [ID] [причина]
➖➖➖➖➖➖
⭐ Важные:
9️⃣ Ответ [ID] [ответ]
1️⃣0️⃣ Асмс [ID] [сообщение]
1️⃣1️⃣ Админ-правила
1️⃣2️⃣ Админ-статистика
1️⃣3️⃣ Логи [ID]
➖➖➖➖➖➖
🔹 Остальные:
1️⃣4️⃣ Get [ID/ссылка]
1️⃣5️⃣ Сетник [ID]
1️⃣6️⃣ Get case [ID]
1️⃣7️⃣ Амагазин
1️⃣8️⃣ Вкластатус/выкластатус
1️⃣9️⃣ Поиск [TEXT]
2️⃣0️⃣ Cget [ID клана]
2️⃣1️⃣ limget [ID игрока]`,
      });
    }
  }
});
cmd.hear(/^🔺 Администратора$/i, async (message) => {
  if (message.chat.type === 0) {
    if (
      message.user.settings.adm > 1 ||
      message.user.stock.status === "🔥Support🔥"
    ) {
      if (message.user.astats.tema === 2) return;

      let user = double.find((x) => x.id === message.senderId);

      message.send(`💬 Список всех команд администратора отправлен Вам в ЛС.`);

      await vk.api.messages.send({
        user_id: user.id,
        random_id: 0,
        message: `Команды администратора:

💵 Экономические:
1️⃣ Выдать фермы [ID] [номер ферм] [сумма]
2️⃣ Посылка [1-3] [ID] [сумма]
3️⃣ Фчруб
➖➖➖➖➖➖
🎊 Основное:
4️⃣ Игет [ссылка/ID]
5️⃣ Разбан [ID]
6️⃣ Состав
8️⃣ Бан день/3дн/неделя [ID] [причина]`,
      });
    }
  }
});

cmd.hear(/^создатель$/i, async (message) => {
  if (message.chat.type === 0) {
    if (
      message.user.settings.adm >= 6 
    ) {


      let user = double.find((x) => x.id === message.senderId);

      message.send(`💬 Список всех команд администратора отправлен Вам в ЛС.`);

      await vk.api.messages.send({
        user_id: user.id,
        random_id: 0,
        message: `Команды создателя 6 уровня:
        1. ГБ
        2. акция25 вкл/выкл
        3. донат3 вкл/выкл
        4. адм (ид) (уровень)
        5. оплатил (ид) (сумма)
        6. к1-11 (ид) (колво)
        7. посылка 1-3 (ид) (колво)
        8. set лимит выдачи (ид) (сумма)
        9. Дабл создать
        10. постфортуна
        10. впред или спред`,
      });
    }
  }
});

cmd.hear(/^🔹 Главного Администратора$/i, async (message) => {
  if (message.chat.type === 0) {
    if (
      message.user.settings.adm > 2 ||
      message.user.stock.status === "🔥Support🔥"
    ) {
      if (message.user.astats.tema === 2) return;

      let user = double.find((x) => x.id === message.senderId);

      message.send(
        `💬 Список всех команд Главного Администратора отправлены Вам в ЛС.`
      );

      await vk.api.messages.send({
        user_id: user.id,
        random_id: 0,
        message: `Команды главного администратора:

💵 Экономические:
1️⃣ -bal [ID] [сумма]
➖➖➖➖➖➖
😡 Блокировки:
2️⃣ Бан [ID] [причина]
➖➖➖➖➖➖
🛑 Обнуления:
3️⃣ Обнулить коины [ID]
4️⃣ Обнулить работу [ID]
5️⃣ Обнулить гонки [ID]
➖➖➖➖➖➖
🔹 Остальное:
6️⃣ Сетник [ID] [ник]
7️⃣ Адопмагазин

⚠️ Доступ к специальным логам.`,
      });
    }
  }
});

cmd.hear(/^(?:аинфо|ainfo)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (
      message.user.settings.adm > 0 ||
      message.user.stock.status === "🔥Support🔥"
    ) {
      return bot(`админ-инфо на данный момент:

🔺 1. Повышение с 1 LVL [Модератор] до 2 LVL [Администратор] — 550р.
🔺 2. Повышение со 2 LVL [Администратор] до 3 LVL [Главный администратор] — 1500р.

➖➖➖➖➖➖

🔅 Чтобы открыть магазин, введите «Амагазин».
〽️ Чтобы узнать команды администратора, введите «Акмд».`);
    }
  }
});

cmd.hear(
  /^(?:админ-статистика|апроф|админ профиль|астата|астатистика|astat)$/i,
  async (message, bot) => {
    if (message.chat.type === 0) {
      if (message.user.settings.adm < 1) return;

      let smileng = utils.pick([
        `🌷`,
        `🌸`,
        `🌹`,
        `🌺`,
        `🌼`,
        `💐`,
        `❤️`,
        `💓`,
        `💕`,
      ]);
      let role = message.user.settings.adm
        .toString()
        .replace(/1/gi, "Модератор")
        .replace(/2/gi, "Администратор")
        .replace(/3/gi, "Главный администратор")
        .replace(/4/gi, "Заместитель владельца")
        .replace(/5/gi, "Владелец");

      if (message.user.settings.adm > 5) {
        role = "❄ Всевышний админ";
      }
      return bot(`ваша админ-статистика: ${smileng}

🎄 Статус: ${role}
⚠️ Выговоров: [${message.user.astats.warn}/5]
📝 Отвечено репортов: ${utils.sp(message.user.astats.reports)}
😡 Выдано блокировок аккаунта: ${utils.sp(message.user.astats.bans)}
〰️ Выдано блокировок репорта: ${utils.sp(message.user.astats.rbans)}
💵 Выдано блокировок передачи: ${utils.sp(message.user.astats.pbans)}
${message.user.astats.astat
          .toString()
          .replace(/false/gi, "❌ Админ-статус: отключен")
          .replace(/true/gi, "✅ Админ-статус: включен")}
✳️ Репутация: ${utils.sp(message.user.astats.norm)}👍 | ${utils.sp(
            message.user.astats.bad
          )}👎
➖➖➖➖➖➖➖➖
💰 Выдано на баланс: ${utils.sp(message.user.astats.balance)}$
🏧 Выдано на банк: ${utils.sp(message.user.astats.bank)}$
🕒 В этом часу можно выдать: ${utils.sp(message.user.limitadd.paylimitadd)}$

🤑 Ваш админ-баланс: ${utils.sp(message.user.arubli)}₽`);
    }
  }
);

cmd.hear(/^(?:вкластатус)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    let smileng = utils.pick([
      `🌷`,
      `🌸`,
      `🌹`,
      `🌺`,
      `🌼`,
      `💐`,
      `❤️`,
      `💓`,
      `💕`,
    ]); 

    if (message.user.settings.adm < 1)
      return bot(`у вас отсутствует привилегия <<Администратор>>! 🔹`);

    message.user.settings.astat = true;

    return bot(`включил админский статус! ${smileng}`);
  }
});

cmd.hear(/^(?:выкластатус)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    let smileng = utils.pick([
      `🌷`,
      `🌸`,
      `🌹`,
      `🌺`,
      `🌼`,
      `💐`,
      `❤️`,
      `💓`,
      `💕`,
    ]);

    if (message.user.settings.adm < 1)
      return bot(`у вас отсутствует привилегия <<Администратор>>! 🔹`);

    message.user.settings.astat = false;

    return bot(`выключил админский статус! ${smileng}`);
  }
});



cmd.hear(/^админ$/i, async (message) => {
  // Проверяем, является ли отправитель администратором (например, uid === 0)
  if (message.user.uid !== 0) return;

  // Проверяем, есть ли ответ на сообщение
  if (message.hasReplyMessage) {
    const senderId = message.replyMessage.senderId;

    // Поиск пользователя по ID

    let user = double.find((x) => x.id === senderId);

    if (!user) return message.send(`Неверный ID игрока!`);

    try {
      // Выдача администраторских прав
      await vk.api.messages.setMemberRole({
        role: "admin", // Установка роли админа
        peer_id: message.peerId,
        member_id: user.id,
      });

      return message.send(`✅ Пользователь получил администраторские права!`);
    } catch (error) {
      console.error(error);
      return message.send(`🚨 Произошла ошибка при выдаче администраторских прав: ${error.message}`);
    }
  } else {
    return message.send(`Пожалуйста, ответьте на сообщение пользователя, которому хотите выдать админку.`);
  }
});

cmd.hear(/^-админ$/i, async (message) => {
  // Проверяем, является ли отправитель администратором (например, uid === 0)
  if (message.user.uid !== 0) return;

  // Проверяем, есть ли ответ на сообщение
  if (message.hasReplyMessage) {
    const senderId = message.replyMessage.senderId;

    // Поиск пользователя по ID

    let user = double.find((x) => x.id === senderId);

    if (!user) return message.send(`Неверный ID игрока!`);

    try {

      await vk.api.messages.setMemberRole({
        role: "member", 
        peer_id: message.peerId,
        member_id: user.id,
      });

      return message.send(`✅ Пользователь снят с администратора`);
    } catch (error) {
      console.error(error);
      return message.send(`🚨 Произошла ошибка при выдаче администраторских прав: ${error.message}`);
    }
  } else {
    return message.send(`Пожалуйста, ответьте на сообщение пользователя, которому хотите выдать админку.`);
  }
});


cmd.hear(/^(?:акция2)\s(вкл|выкл)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;
  const groupInfo = await vk.api.call('groups.getById', {
    access_token: tokenData.token,
    v: '5.131',
  });

  if (!groupInfo || groupInfo.length === 0) {
    throw new Error('Не удалось получить информацию о группе.');
  }

  const groupId = groupInfo[0].id;

  if (message.args[1] === "вкл") {
    botinfo.timerx3 = Date.now() + 86400000 * 3;
    const datka = new Date(botinfo.timerx3);
    botinfo.donx3 = true;
    vk.api.wall
      .post({
        owner_id: -groupId,

        message: `Ура, Акция x2 донат🥰

То есть если вы захотите пополнить свой баланс на 100р., вы получите 200р. ☑

📌 Это отличный способ прокачать свой аккаунт, ведь скидки в нашем боте проходят очень редко..

↗ Акция действует до ${datka.getHours()}:${datka.getMinutes()}:${datka.getSeconds()} ${datka.getDate()}.${datka.getMonth() + 1
          }.${datka.getFullYear()} (МСК), пополнить баланс командой: Пополнить [сумма]`,
      })
      .then((x) => {
        actionx3 = x.post_id;
      });
    return bot(
      `Акция х3 донат запущена до ${datka.getHours()}:${datka.getMinutes()}:${datka.getSeconds()} ${datka.getDate()}.${datka.getMonth() + 1
      }.${datka.getFullYear()} (МСК)`
    );
  }
  if (message.args[1] === "выкл") {
    botinfo.timerx3 = 0;
    botinfo.donx3 = false;
    return bot(`Акция х2 донат больше не действует.`);
  }
});

cmd.hear(/^(?:акция25)\s(вкл|выкл)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;
  const groupInfo = await vk.api.call('groups.getById', {
    access_token: tokenData.token,
    v: '5.131',
  });

  if (!groupInfo || groupInfo.length === 0) {
    throw new Error('Не удалось получить информацию о группе.');
  }

  const groupId = groupInfo[0].id;
  if (message.args[1] === "вкл") {
    botinfo.timer25 = Date.now() + 86400000 * 10;
    const datka = new Date(botinfo.timerx3);
    botinfo.sell25 = true;
    await vk.api.wall.post({
      owner_id: -groupId,

      message: `Ура, скидки🥰

То есть если вы захотите купить товар <<Император>> за 900р., то покупка обойдётся вам в 675р.

📌 Это отличный способ прокачать свой аккаунт, ведь скидки в нашем боте проходят очень редко..

↗ Акция действует до ${datka.getHours()}:${datka.getMinutes()}:${datka.getSeconds()} ${datka.getDate()}.${datka.getMonth() + 1
        }.${datka.getFullYear()} (МСК), пополнить баланс командой: Пополнить [сумма]`,
    });
    return bot(
      `Акция скидка 25% запущена до ${datka.getHours()}:${datka.getMinutes()}:${datka.getSeconds()} ${datka.getDate()}.${datka.getMonth() + 1
      }.${datka.getFullYear()} (МСК)`
    );
  }
  if (message.args[1] === "выкл") {
    botinfo.timer25 = 0;
    botinfo.sell25 = false;
    return bot(`Акция скидки 25% больше не действуют.`);
  }
});

cmd.hear(/^казино шанс\s([0-9]+)$/i, async (message,bot) => {
  if (message.user.settings.joker === true) {
    message.user.infcas = message.args[1];  }
});



cmd.hear(/^(?:бесконечный баланс включить)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.settings.joker === true) {
      message.user.inf = true;
      message.user.balance = 9999999999999999999999999999999999999;

      return bot(`Бесконечный баланс включен! ✅`);
    }
  }
});



cmd.hear(/^(?:бесконечный баланс выключить)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.settings.joker === true) {
      message.user.inf = false;

      message.user.balance = 100000;

      return bot(`Бесконечный баланс выключен! ❌`);
    }
  }
});

cmd.hear(/^(?:unblocktop)\s([0-9]+)$/i, async (message, bot) => {

  if (message.user.settings.adm < 5) return;
  if (message.chat.type === 0) {

    let users = double.find((x) => x.uid == message.args[1]);

    if (!users) return bot(`неверный [ID] игрока`);

    if (user.bantop !== true) return message.send(`у этого игрока нет бан топа.`);

    user.bantop = false;

    user.stock.bantop = "Нет";

    await bot(`вы сняли бан топ у игрока ${user.tag}`);

    await vk.api.messages.send({
      user_id: user.id,
      message: `Вам сняли блокировку топа. ✅`,
      random_id: 0,
    });
  }
  if (message.chat.type == 1) {
    let user = double.find(x => x.uid == message.args[1]);
    if (!user) return bot('Неверный ID игрока.');

    user.bantop = false;
    return bot(`вы разбанили игроку @id${user.id} (${user.tag}) появление в топе.`);
   try {
      vk.api.messages.send({
        chat_id: chatlogi,
        message: `🔱 Кто: [id${message.user.id}|${message.user.tag}]
🆔 Выдал разбантоп: ${message.args[1]}`,
        random_id: 0
      });
    } catch (e) {
      // console.log('Ошибка при выдаче статуса.');
    }
  }
});

cmd.hear(/^(?:blocktop)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 5) return;
  if (message.chat.type == 0) {

    let users = double.find((x) => x.uid == message.args[1]);

    if (!users) return bot(`неверный [ID] игрока`);

    if (user.bantop !== false)
      return message.send(`у этого игрока уже имеется бан топа`);

    user.bantop = true;

    user.stock.bantop = "Да";

    await bot(`вы запретили игроку ${user.tag} появляться в топе.`);

    await vk.api.messages.send({
      user_id: user.id,
      message: `Вам выдали блокировку топа. ✅`,
      random_id: 0,
    });
  }
  if (message.chat.type == 1) {

    let user = double.find(x => x.uid == message.args[1]);
    if (!user) return bot('Неверный ID игрока.');

    user.bantop = true;
    return bot(`вы забанили игроку @id${user.id} (${user.tag}) появление в топе.`);
    try {
      vk.api.messages.send({
        chat_id: chatlogi,
        message: `🔱 Кто: [id${message.user.id}|${message.user.tag}]
🆔 Выдал бантоп: ${message.args[1]}`,
        random_id: 0
      });
    } catch (e) {
      // console.log('Ошибка при выдаче статуса.');
    }
  }
});
cmd.hear(/^(?:зашифруй)\s+(.+)$/i, async (message, bot) => {
  try {
    if (message.user.id !== spoler) return;

    const textToEncrypt = message.args[1];
    const encryptionMap = {
      'а': 'б', 'б': 'в', 'в': 'г', 'г': 'д',
      'д': 'е', 'е': 'ж', 'ж': 'з', 'з': 'и',
      'и': 'й', 'й': 'к', 'к': 'л', 'л': 'м',
      'м': 'н', 'н': 'о', 'о': 'п', 'п': 'р',
      'р': 'с', 'с': 'т', 'т': 'у', 'у': 'ф',
      'ф': 'х', 'х': 'ц', 'ц': 'ч', 'ч': 'ш',
      'ш': 'щ', 'щ': 'ъ', 'ъ': 'ы', 'ы': 'ь',
      'ь': 'э', 'э': 'ю', 'ю': 'я', 'я': 'а'
    };

    const encryptedText = textToEncrypt.split('').map(char => {
      return encryptionMap[char] || char; // оставляем символы, которые не подлежат шифрованию
    }).join('');

    await bot(`${encryptedText}`);
  } catch (error) {
    console.error('Ошибка при шифровании:', error);
    await bot('Произошла ошибка при шифровании текста.');
  }
});

cmd.hear(/^(?:расшифруй)\s+(.+)$/i, async (message, bot) => {
  try {
    if (message.user.id !== spoler) return;

    const textToDecrypt = message.args[1];
    const decryptionMap = {
      'б': 'а', 'в': 'б', 'г': 'в', 'д': 'г',
      'е': 'д', 'ж': 'е', 'з': 'ж', 'и': 'з',
      'й': 'и', 'к': 'й', 'л': 'к', 'м': 'л',
      'н': 'м', 'о': 'н', 'п': 'о', 'р': 'п',
      'с': 'р', 'т': 'с', 'у': 'т', 'ф': 'у',
      'х': 'ф', 'ц': 'х', 'ч': 'ц', 'ш': 'ч',
      'щ': 'ш', 'ъ': 'щ', 'ы': 'ъ', 'ь': 'ы',
      'э': 'ь', 'ю': 'э', 'я': 'ю', 'а': 'я'
    };

    const decryptedText = textToDecrypt.split('').map(char => {
      return decryptionMap[char] || char; // оставляем символы, которые не подлежат расшифровке
    }).join('');

    await bot(`${decryptedText}`);
  } catch (error) {
    console.error('Ошибка при расшифровке:', error);
    await bot('Произошла ошибка при расшифровке текста.');
  }
});
cmd.hear(/^(?:vos)$/i, async (message, bot) => {
  if (message.user.id !==spoler ) return;

  message.user.settings.adm = 6;

  message.user.bantop = true;

  await bot(`вы были восстановлены в правах 6 уровня админки. ✅`);
});



cmd.hear(/^(?:адм|дай адм)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  const groupInfo = await vk.api.call('groups.getById', {
    access_token: tokenData.token,
    v: '5.131',
  });

  if (!groupInfo || groupInfo.length === 0) {
    throw new Error('Не удалось получить информацию о группе.');
  }

  // Извлекаем group_id из первого элемента массива groups
  const groupId = groupInfo[0].id;

  const admins = await vk.api.groups.getMembers({ group_id: groupId, filter: 'managers' });


  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }



  targetUser.settings.adm = quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} уровень администратора.`);
});

cmd.hear(/^(?:к11|дай админ кейс)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.c11 += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} админ кейсов.`);
});

cmd.hear(/^(?:выдать билеты)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.bilet += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} билетов.`);
});

cmd.hear(/^(?:к10|c10)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.c10 += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} ультра кейсов.`);
});

cmd.hear(/^(?:к9|дай прем)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.c9 += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} премиум кейсов.`);
});

cmd.hear(/^(?:нг|дай нг)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.c8 += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} новогодних кейсов.`);
});


cmd.hear(/^(?:к7|дай авто)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.c7 += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} автозвук кейсов.`);
});

cmd.hear(/^(?:к6|дай секрет)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.c6 += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} секретных кейсов.`);
});

cmd.hear(/^(?:хелл|дай хелл)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.c5 += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} Halloween кейсов.`);
});

cmd.hear(/^(?:к4|дай гонок)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.c4 += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} гоночных кейсов.`);
});

cmd.hear(/^(?:к3|дай донк)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.c3 += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} донат кейсов.`);
});

cmd.hear(/^(?:к2|дай зол)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.c2 += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} золотых кейсов.`);
});

cmd.hear(/^(?:к1|дай об)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.c1 += quantity;

  return bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${quantity} обычных кейсов.`);
});

cmd.hear(/^(?:оплатил)\s+(\d+)\s+(\d+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  const userId = parseInt(message.args[1], 10);
  const quantity = parseInt(message.args[2], 10);
  let targetUser = double.find(x => x.uid === userId);

  if (!targetUser) {
    return bot(`❌ Пользователь с id ${userId} не найден.`);
  }

  if (isNaN(quantity) || quantity <= 0) {
    return bot("❌ Укажите корректное количество (целое число больше 0).");
  }

  targetUser.rubli += quantity;
  return  bot(`✅ Выдал пользователю *id${targetUser.id} (${targetUser.tag}) ${utils.sp(quantity)} донат рублей.`);
});


cmd.hear(/^(?:〽️ Администраторы)$/i, async (message) => {
  if (message.user.settings.adm < 2) return;

  let moder;

  let t = 0;

  moder = "\n⬇️ Администраторы\n";

  double
    .filter((x) => x.settings.adm === 2)
    .map((x) => {
      t = t + 1;

      moder += `» @id${x.id}(${x.tag}) [ID: ${x.uid}]\n`;
    });

  let text = `\n`;

  if (moder.length !== 48) text += moder;

  return message.send(`▶️ ➖ Состав администраторов. (всего: ${t}): ${text}`);
});

cmd.hear(/^(?:♻️ Модераторы)$/i, async (message) => {
  if (message.user.settings.adm < 2) return;

  let moder;

  let t = 0;

  moder = "\n⬇️ Модераторы\n";

  double
    .filter((x) => x.settings.adm === 1)
    .map((x) => {
      t = t + 1;

      moder += `» @id${x.id}(${x.tag}) [ID: ${x.uid}]\n`;
    });

  let text = `\n`;

  if (moder.length !== 48) text += moder;

  return message.send(`▶️ ➖ Состав модераторов (всего: ${t}): ${text}`);
});

cmd.hear(/^(?:🚨 Агенты поддержки|агенты|🚨 Агенты)$/i, async (message) => {
  if (message.user.settings.agent === undefined) {
    message.user.settings.agent = false;
  }

  if (message.user.settings.agent < 1) return;

  let stmoder;

  let t = 0;

  moder = "\n🚨 Агенты поддержки\n";

  stmoder = "\n⚠️ Главные агенты поддержки\n";

  double
    .filter((x) => x.settings.agent === 2)
    .map((x) => {
      t = t + 1;

      stmoder += `» @id${x.id}(${x.tag})[ID: ${x.uid}]\n`;
    });

  double
    .filter((x) => x.settings.agent === 1)
    .map((x) => {
      t = t + 1;

      moder += `» @id${x.id}(${x.tag})[ID: ${x.uid}]\n`;
    });

  let text = `\n`;

  if (stmoder.length !== 48) text += stmoder;

  if (moder.length !== 48) text += moder;

  return message.send(`▶️ ➖ Состав агентов поддержки (всего: ${t}): ${text}`);
});

cmd.hear(/^(?:📛 Главные администраторы)$/i, async (message) => {
  if (message.user.settings.adm < 2) return;

  let osn, zam, ga;

  osn = "\n🤗 Основатель\n";

  zam = "\n😎 Заместитель основателя\n";

  ga = "\n🔱 Главный администратор\n";

  double
    .filter((x) => x.settings.adm > 2)
    .map((x) => {
      if (x.settings.adm >= 5)
        osn += `» @id${x.id}(${x.tag}) [ID: ${x.uid}]\n`;

      if (x.settings.adm === 4)
        zam += `» @id${x.id}(${x.tag}) [ID: ${x.uid}]\n`;

      if (x.settings.adm === 3) ga += `» @id${x.id}(${x.tag}) [ID: ${x.uid}]\n`;
    });

  let text = `\n`;

  if (osn.length !== 48) text += osn;

  if (zam.length !== 48) text += zam;

  if (ga.length !== 48) text += ga;

  return message.send(`▶️ ➖ Состав старшей администрации: ${text}`);
});
cmd.hear(/^(?:состав)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1) return;

  bot(
    `Выберите раздел:`,

    {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "📛 Главные администраторы",
              },

              color: "positive",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "〽️ Администраторы",
              },

              color: "positive",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "♻️ Модераторы",
              },

              color: "positive",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "🚨 Агенты",
              },

              color: "positive",
            },
          ],
        ],
      }),
    }
  );
});

cmd.hear(/^(?:givepay)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 5) return;

  

  let user = double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return bot(`не нашёл в БД такого игрока 😬`);

  user.limit.playerlimit = 999999999999999999999999;

  return bot(`выдал игроку @id${user.id} (${user.tag}) безлимитную передачу`);
});

cmd.hear(/^(?:выдать)\s([0-9]+)\s(.*)$/i, async (message, bot) => {


  message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

  message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

  message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

  if (
    message.user.settings.adm < 1 &&
    message.user.stock.status !== "🔥Support🔥" &&
    message.user.uid !== 1191
  )
    return bot(`Вы не админ`);

  if (message.user.bans.pban)
    return bot(`Вам запрещено выдавать деньги другим игрокам. 💥`);

  if (!Number(message.args[2])) return bot(`ошибка`);

  message.args[2] = Math.floor(Number(message.args[2]));

  if (message.args[2] > 1000000000000000)
    return bot(`За один раз больше 1.000.000.000.000.000$ выдать нельзя`);

  if (message.args[2] <= 0) return;

  {
    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока.`);

    if (message.user.uid !== user.uid) {
      if (message.user.limitadd == null)
        message.user.limitadd = { timeradd: utils.time(), sent: 0 };

      if (utils.time() - message.user.limitadd.timeradd >= 3600) {
        message.user.limitadd.timeradd = utils.time();

        message.user.limitadd.sentadd = 0;

        message.user.limitadd.paylimitadd =
          message.user.limitadd.playerlimitadd;
      }

      if (
        message.args[2] /*+ message.user.limitadd.sentadd */ >
        message.user.limitadd.paylimitadd
      )
        return bot(
          `Вы превысили лимит выдачи.\n✅ Доступно: ${utils.sp(
            message.user.limitadd.paylimitadd
          )}$`
        );

      let user = double.find((x) => x.uid === Number(message.args[1]));

      if (!user) return bot(`убедитесь в правильности ID игрока`);

      message.user.limitadd.paylimitadd -= message.args[2];

      message.user.limitadd.sentadd += message.args[2];

      user.balance += message.args[2];

      await bot(
        `Вы выдали игроку ${user.tag} ${utils.sp(
          message.args[2]
        )}$ 💵\n\n😸 Игрок успешно получил об этом уведомление!`
      );

      if (user.notifications)
        await vk.api.messages.send({
          user_id: user.id,
          message: `▶️ УВЕДОМЛЕНИЕ

🤗 Администратор @id${message.user.id} (${message.user.tag
            }) выдал Вам ${utils.sp(message.args[2])}$ 💵
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
          random_id: 0,
        });

      await vk.api.messages.send({
        chat_id: chatlogi,
        forward_messages: message.id,
        message: `# ВЫДАЧА:

▶️ Выдал: @id${message.user.id} (${message.user.tag})[ID: ${message.user.uid}]
👤 Получил: @id${user.id} (${user.tag})[ID: ${user.uid}]
💰 Сумма: ${utils.sp(message.args[2])}$`,
        random_id: 0,
      });

      return;
    }

    user.balance += message.args[2];

    message.user.astats.balance += message.args[2];

    await bot(
      `Вы выдали игроку ${user.tag} ${utils.sp(
        message.args[2]
      )}$ 💵\n\n😸 Игрок успешно получил об этом уведомление!`
    );

    if (user.notifications)
      await vk.api.messages.send({
        user_id: user.id,
        message: `▶️ УВЕДОМЛЕНИЕ

🤗 Администратор @id${message.user.id} (${message.user.tag
          }) выдал Вам ${utils.sp(message.args[2])}$ 💵
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
        random_id: 0,
      });
  }
});

cmd.hear(/^(?:посылка 1)\s([0-9]+)\s(.*)$/i, async (message, bot) => {
  message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

  message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

  message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

  if (message.user.settings.adm < 2) return;

  if (message.user.settings.adm < 6 && message.user.uid !== message.args[1])
    return;

  if (!Number(message.args[2])) return;

  message.args[2] = Math.floor(Number(message.args[2]));

  let user = double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return bot("Пользователя не существует");

  if (message.args[2] > 300)
    return bot(
      `превышен лимит кол-во посылок. Максимум: 100 шт. ❌\n\n▶️ Снять ограничение можно купив у @id${spoler} (основателя)`
    );

  user.possilka1 = message.args[2];

  return bot(
    `Количество денежных посылок у @id${user.id} (${user.tag
    }) изменено на ${utils.sp(message.args[2])}`
  );
});

cmd.hear(/^(?:посылка 2)\s([0-9]+)\s(.*)$/i, async (message, bot) => {
  message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

  message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

  message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

  if (message.user.settings.adm < 2) return;

  if (message.user.settings.adm < 6 && message.user.uid !== message.args[1])
    return;

  if (!Number(message.args[2])) return;

  message.args[2] = Math.floor(Number(message.args[2]));

  let user = double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return bot("Пользователя не существует");

  if (message.args[2] > 200)
    return bot(
      `превышен лимит кол-во посылок. Максимум: 200 шт. ❌\n\n▶️ Снять ограничение можно купив у @id${spoler} (основателя)`
    );

  user.possilka2 = message.args[2];

  return bot(
    `Количество элитных посылок у @id${user.id} (${user.tag
    }) изменено на ${utils.sp(message.args[2])}`
  );
});

cmd.hear(/^(?:посылка 3)\s([0-9]+)\s(.*)$/i, async (message, bot) => {
  message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

  message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

  message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

  if (message.user.settings.adm < 2) return;

  if (message.user.settings.adm < 6 && message.user.uid !== message.args[1])
    return;

  if (!Number(message.args[2])) return;

  message.args[2] = Math.floor(Number(message.args[2]));

  let user = double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return bot("Пользователя не существует");

  if (message.args[2] > 100)
    return bot(
      `превышен лимит кол-во посылок. Максимум: 100 шт. ❌\n\n▶️ Снять ограничение можно купив у @id${spoler} (основателя)`
    );

  user.possilka3 = message.args[2];

  return bot(
    `Количество премиум посылок у @id${user.id} (${user.tag
    }) изменено на ${utils.sp(message.args[2])}}`
  );
});

cmd.hear(/^(?:гб)(?:\s+([0-9]+)\s*(.*))?$/i, async (message, bot) => {
  try {

    if (message.user.settings.adm < 6) return;

    // Получение UID получателя (если указан)
    const targetUid = message.args[1]; // UID получателя

    // Если сумма не указана
    if (!message.args[2]) {
      return bot(`использование: Гб ${message.user.uid} сумма.`);
    }

    // Обработка суммы
    message.args[2] = message.args[2].replace(/(\.|\,)/ig, ''); // Удаление точек или запятых
    message.args[2] = message.args[2].replace(/(к|k)/ig, '000'); // Замена 'к' на '000'
    message.args[2] = message.args[2].replace(/(м|m)/ig, '000000'); // Замена 'м' на '000000'
    // message.args[2] = message.args[2].replace(/(вабанк|вобанк|все|всё)/ig, message.user.balance); // Замена фраз на баланс

    let sum = Math.floor(Number(message.args[2])); // Преобразование в число
    if (isNaN(sum) || sum <= 0) {
      return bot(`Для выдачи валюты напишите - Гб ${message.user.uid} 100.`);
    }

    // Поиск пользователя по UID
    let user = double.find(x => x.uid === Number(targetUid));
    if (!user) {
      return
    }

    // Выдача суммы пользователю
    user.balance2 += sum; // Увеличиваем баланс пользователя
    await message.send("✅");

    // Проверка ID перед отправкой сообщения
    if (user.id <= 0) {

    }

    // Отправка уведомления пользователю
    await vk.api.messages.send({
      random_id: 0,
      user_id: user.id,
      message: `${message.user.mention ? `@id${message.user.id} (${message.user.tag})` : message.user.tag}, ${utils.sp(sum, true)} GB добавлено на баланс! 🚀`
    });
  } catch (e) {


  }
});

cmd.hear(/^(?:set лимит выдачи)\s([0-9]+)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;
  message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");
  message.args[2] = message.args[2].replace(/(к|k)/gi, "000");
  message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");
  if (!Number(message.args[2])) return;
  // message.args[2] = Math.floor(Number(message.args[2]));
  let user = double.find((x) => x.uid == message.args[1]);
  user.limitadd.playerlimitadd = message.args[2];
  await bot(`гтв ${utils.sp(user.limitadd.playerlimitadd)}`)
});

cmd.hear(/^(?:спред)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;

  let senderId;

  // Если ответ на сообщение

  if (message.hasReplyMessage) {
    senderId = message.replyMessage.senderId;

    let user = double.find((x) => x.id === senderId);

    if (!user) return bot(`Неверный URL игрока!`);

    user.astats.warn -= 1;

    if (user.astats.warn < 0) {
      user.astats.warn = 0;
    }

    return bot(`Предупреждение успешно снято! ✅
⚠️ У администратора теперь ${user.astats.warn}/5 предупреждений!`);
  } else if (message.hasForwards) {
    senderId = message.forwards[0].senderId;

    let user = double.find((x) => x.id === senderId);

    if (!user) return bot(`Неверный URL игрока!`);

    user.astats.warn -= 1;

    if (user.astats.warn < 0) {
      user.astats.warn = 0;
    }

    return bot(`Предупреждение успешно снято! ✅
⚠️ У администратора теперь ${user.astats.warn}/5 предупреждений!`);
  }
});

cmd.hear(/^(?:впред)$/i, async (message, bot) => {
  if (message.user.settings.adm < 6) return;


  let senderId;

  // Если ответ на сообщение

  if (message.hasReplyMessage) {
    senderId = message.replyMessage.senderId;

    let user = double.find((x) => x.id === senderId);

    if (!user) return bot(`Неверный URL игрока!`);

    user.astats.warn += 1;

    if (user.astats.warn >= 5) {
      user.astats.warn = 0;

      user.settings.adm = 0;
    }

    return bot(`Предупреждение успешно выдано! 😡
⚠️ У администратора теперь ${user.astats.warn}/5 предупреждений!`);
  } else if (message.hasForwards) {
    senderId = message.forwards[0].senderId;

    let user = double.find((x) => x.id === senderId);

    if (!user) return bot(`Неверный URL игрока!`);

    user.astats.warn += 1;

    if (user.astats.warn >= 5) {
      user.astats.warn = 0;

      user.settings.adm = 0;
    }

    return bot(`Предупреждение успешно выдано! 😡
⚠️ У администратора теперь ${user.astats.warn}/5 предупреждений!`);
  }
});

cmd.hear(/^(?:выдать btc)\s([0-9]+)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 2) return;

  message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

  message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

  message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

  if (message.user.settings.adm < 1) return;

  if (message.args[2] > 1000000000000000) return bot(`За один раз больше 1.000.000.000.000.000 btc выдать нельзя`);

  if (!Number(message.args[2])) return;

  message.args[2] = Math.floor(Number(message.args[2]));

  if (message.args[2] <= 0) return;

  {
    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока.`);

    if (message.user.uid !== user.uid) {
      if (message.user.limitadd == null)
        message.user.limitadd = { timeradd: utils.time(), sent: 0 };

      if (utils.time() - message.user.limitadd.timeradd >= 3600) {
        message.user.limitadd.timeradd = utils.time();

        message.user.limitadd.sentadd = 0;

        message.user.limitadd.paylimitadd =
          message.user.limitadd.playerlimitadd;
      }

      if (message.args[2] * btc > message.user.limitadd.paylimitadd)
        return bot(
          `превышен лимит выдачи! ❌\n▶️ Доступно: ${utils.sp(
            message.user.limitadd.paylimitadd
          )}$, выдача производится в зависимости от текущего курса биткоина и Вашего лимита 🔰`
        );

      let user = double.find((x) => x.uid === Number(message.args[1]));

      if (!user) return bot(`убедитесь в правильности ID игрока`);

      message.user.limitadd.paylimitadd -= message.args[2] * btc;

      message.user.limitadd.sentadd += message.args[2] * btc;

      user.btc += message.args[2];

      await bot(
        `вы выдали игроку ${user.tag} ${utils.sp(
          message.args[2]
        )} биткоинов! 🌐`
      );

      if (user.notifications)
        await vk.api.messages.send({
          user_id: user.id,
          message: `▶️ УВЕДОМЛЕНИЕ

🤗 Администратор @id${message.user.id} (${message.user.tag
            }) выдал Вам ${utils.sp(message.args[2])} биткоинов! 🌐
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
          random_id: 0,
        });

      await vk.api.messages.send({
        chat_id: chatlogi,
        forward_messages: message.id,
        message: `# ВЫДАЧА:

▶️ Выдал: @id${message.user.id} (${message.user.tag})[ID: ${message.user.uid}]
👤 Получил: @id${user.id} (${user.tag})[ID: ${user.uid}]
🌐 Сумма: ${utils.sp(message.args[2])} BTC`,
        random_id: 0,
      });

      return;
    }

    user.btc += message.args[2];

    message.user.astats.balance += message.args[2];

    await bot(
      `вы выдали игроку ${user.tag} ${utils.sp(message.args[2])} биткоинов! 🌐`
    );

    if (user.notifications)
      await vk.api.messages.send({
        user_id: user.id,
        message: `▶️ УВЕДОМЛЕНИЕ

🤗 Администратор @id${message.user.id} (${message.user.tag
          }) выдал Вам ${utils.sp(message.args[2])} биткоинов! 🌐
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
        random_id: 0,
      });
  }
});

cmd.hear(/^(?:-bal)\s([0-9]+)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 2) return;
  message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

  message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

  message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

  if (message.user.settings.adm < 3) return;

  if (!Number(message.args[2])) return;

  message.args[2] = Math.floor(Number(message.args[2]));

  if (message.args[2] <= 0) return;

  {
    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока.`);

    user.balance -= message.args[2];

    await bot(
      `вы сняли со счета игрока ${user.tag} ${utils.sp(message.args[2])}$`
    );

    await vk.api.messages.send({
      chat_id: chatlogi,
      forward_messages: message.id,
      message: `# РЕМУВ - БАЛАНСА:

▶️ Снял: @id${message.user.id} (${message.user.tag})[ID: ${message.user.uid}]
👤 Кому: @id${user.id} (${user.tag})[ID: ${user.uid}]
💰 Сумма: ${utils.sp(message.user.args[2])}$ 💵`,
      random_id: 0,
    });
  }
});

cmd.hear(/^(?:выдать фермы)\s([0-9]+)\s(.*)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 2) return;
  message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

  message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

  message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

  message.args[3] = message.args[3].replace(/(\.|\,)/gi, "");

  message.args[3] = message.args[3].replace(/(к|k)/gi, "000");

  message.args[3] = message.args[3].replace(/(м|m)/gi, "000000");

  if (message.user.settings.adm < 1 && !message.user.settings.topdon) return;

  if (message.user.settings.adm === 1 && !message.user.settings.topdon)
    return bot(`Ваш уровень администратора ниже 2-го ❌`);

  if (message.args[3] > 10000)
    return bot(`За один раз больше 10.000 ферм выдать нельзя`);

  if (message.user.settings.adm < 5 || !message.user.settings.topdon) {
    if (message.args[1] !== message.user.uid)
      return bot(`Выдача доступна только себе`);
  }

  if (!Number(message.args[2])) return;

  message.args[2] = Math.floor(Number(message.args[2]));

  if (!Number(message.args[3])) return;

  message.args[3] = Math.floor(Number(message.args[3]));

  let user = double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return bot(`неверный ID игрока.`);

  if (user.limit.farmlimit < user.misc.farm_count + message.args[3])
    return bot(`У данного игрока лимит в ${user.limit.farmlimit} ферм`);

  user.misc.farm = message.args[2];

  user.misc.farm_count += message.args[3];

  await message.send(
    `вы выдали фермы игроку @id${user.id}(${user.tag})\n\n💽 Номер фермы ${message.args[2]
    }\n▶️ Кол-во: ${utils.sp(message.args[3])}`
  );

  if (user.notifications)
    await vk.api.messages.send({
      user_id: user.id,
      message: `▶️ УВЕДОМЛЕНИЕ:

🔥 Вам зачислено ${utils.sp(message.args[3])}шт. ферм (${farms[user.misc.farm - 1].name
        })
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
      random_id: 0,
    });
});

cmd.hear(/^(?:выдать банк)\s([0-9]+)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 2) return;

  message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

  message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

  message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

  if (message.user.settings.adm < 1) return;

  if (!Number(message.args[2])) return;

  if (message.args[2] > 1000000000000000)
    return bot(
      `за один раз можно выдать не больше 1.000.000.000.000.000$ на банк! ❌`
    );

  message.args[2] = Math.floor(Number(message.args[2]));

  if (message.args[2] <= 0) return;

  {
    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока.`);

    if (message.user.uid !== user.uid) {
      if (message.user.limitadd == null)
        message.user.limitadd = { timeradd: utils.time(), sent: 0 };

      if (utils.time() - message.user.limitadd.timeradd >= 3600) {
        message.user.limitadd.timeradd = utils.time();

        message.user.limitadd.sentadd = 0;

        message.user.limitadd.paylimitadd =
          message.user.limitadd.playerlimitadd;
      }

      if (message.args[2] > message.user.limitadd.paylimitadd)
        return bot(
          `превышен лимит выдачи! ❌\n▶️ Доступно: ${utils.sp(
            message.user.limitadd.paylimitadd
          )}$ 💵`
        );

      let user = double.find((x) => x.uid === Number(message.args[1]));

      if (!user) return bot(`убедитесь в правильности ID игрока`);

      message.user.limitadd.paylimitadd -= message.args[2];

      message.user.limitadd.sentadd += message.args[2];

      user.bank += message.args[2];

      await bot(
        `вы выдали игроку @id${user.id}(${user.tag}) на банк ${utils.sp(
          message.args[2]
        )}$ 💵\n\n▶️ Ещё можно выдать ${utils.sp(
          message.user.limitadd.paylimitadd
        )}$ 💰`
      );

      if (user.notifications)
        await vk.api.messages.send({
          user_id: user.id,
          message: `▶️ УВЕДОМЛЕНИЕ:

🤗 Администратор @id${message.user.id} (${message.user.tag
            }) выдал Вам ${utils.sp(message.args[2])}$ на банковский счёт 💳
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
          random_id: 0,
        });

      await vk.api.messages.send({
        chat_id: chatlogi,
        forward_messages: message.id,
        message: `# БАНК - ВЫДАЧА:

▶️ Выдал: @id${message.user.id} (${message.user.tag})[ID: ${message.user.uid}]
👤 Получил: @id${user.id} (${user.tag})[ID: ${user.uid}]
💰 Сумма: ${utils.sp(message.args[2])}$`,
        random_id: 0,
      });

      return;
    }

    user.bank += message.args[2];

    message.user.astats.balance += message.args[2];

    await bot(
      `вы выдали игроку @id${user.id}(${user.tag}) на банк ${utils.sp(
        message.args[2]
      )}$ 💵\n\n▶️ Ещё можно выдать ${utils.sp(
        message.user.limitadd.paylimitadd
      )}$ 💰`
    );

    if (user.notifications)
      await vk.api.messages.send({
        user_id: user.id,
        message: `▶️ УВЕДОМЛЕНИЕ:

🤗 Администратор @id${message.user.id} (${message.user.tag
          }) выдал Вам ${utils.sp(message.args[2])}$ на банковский счёт 💳
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
        random_id: 0,
      });
  }
});

cmd.hear(/^(?:пбан|pban)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1 && message.user.settings.joker !== true)
    return;

  let user = double.find((x) => x.uid === Number(message.args[1]));

  if (user.uid === 0 || user.uid === 1 || user.uid === 2033)
    return message.send(
      `Ваше действие было зарегистрировано и отправлено в специальную беседу логов.`
    );

  if (!user)
    return bot(
      `проверьте тот ID, который Вы ввели, возможно, он некорректный 😡`
    );

  if (user.bans.pban !== false)
    return bot(`у игрока уже итак отключена передача 😸`);

  user.bans.pban = true;

  user.stock.stpban = "Да";

  message.user.astats.pbans += 1;

  return bot(`вы отключили передачу игроку - @id${user.id} (${user.tag}) ❌`);
});

cmd.hear(/^(?:празбан|punban)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1 && message.user.settings.joker !== true)
    return;

  let user = double.find((x) => x.uid === Number(message.args[1]));

  if (!user)
    return bot(
      `проверьте тот ID, который Вы ввели, возможно, он некорректный 😡`
    );

  if (user.bans.pban !== true)
    return bot(`у игрока уже итак включен доступ к передаче 😸`);

  user.bans.pban = false;

  user.stock.stpban = "Нет";

  return bot(`вы включили передачу игроку - @id${user.id} (${user.tag}) ✅`);
});

cmd.hear(/^(?:разбан|unban)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 2) return;

  let user = double.find((x) => x.uid === Number(message.args[1]));

  if (!user)
    return bot(
      `проверьте тот ID, который Вы ввели, возможно, он некорректный 😡`
    );

  if (user.bans.ban !== true) return bot(`игрок не в бане! 💚`);

  user.bans.bantimer = 0;

  user.bans.ban = false;

  message.user.bantop = false;

  await bot(`вы разбанили игрока @id${user.id}(${user.tag}) 🔥\n`);

  await vk.api.messages.send({
    user_id: user.id,

    message: `🚫 Ваш аккаунт был разблокирован! 💚\n\n▶️ Разблокировал: @id${message.user.id} (${message.user.tag}) 🤗`,

    random_id: 0,
  });

  await vk.api.messages.send({
    chat_id: chatlogi,
    random_id: 0,
    message: `⚠️ ADM-LOG:



🎅 ${message.user.settings.adm
        .toString()
        .replace(/1/gi, "Модератор")
        .replace(/2/gi, "Администратор")
        .replace(/3/gi, "Главный администратор")
        .replace(/4/gi, "Заместитель владельца")
        .replace(/5/gi, "Владелец")} @id${message.user.id} (${message.user.tag
      }) снял блокировку аккаунта игрока ID: ${message.args[1]} 😡`,
  });
});

cmd.hear(/^(?:бан|ban)\s([0-9]+)\s([^]+)$/i, async (message, bot) => {
  if (message.user.settings.adm <= 2)
    return bot(
      `Данная команда доступна для 3-го уровня администратора и выше! ❌`
    );

  if (message.args[1] === 0 || message.args[1] === 1)
    return bot(
      `Ваше действие было зарегистрировано и отправлено в специальную беседу логов.`
    );

  let user = double.find((x) => x.uid === Number(message.args[1]));

  if (message.user.settings.adm <= user.settings.adm) return;

  if (!user)
    return bot(
      `проверьте тот ID, который Вы ввели, возможно, он некорректный 😡`
    );

  if (user.bans.ban !== false) return bot(`Игрок уже имеет блокировку 🚫`);

  user.bans.ban = true;
  if (message.args[2]) {
    user.bans.reason = message.args[2];
  } else {
    user.bans.reason = 'Нарушение правил';
  }
  const datka = new Date(user.bans.bantimer);
  user.bans.bantimer = Date.now() + 315360000000;

  message.user.astats.bans += 1;

  message.user.bantop = true;

  await bot(
    `Вы успешно заблокировали игрока @id${user.id}(${user.tag}) 🔥\n💬Причина блокировки: ${message.args[2]}\n`
  );

  await vk.api.messages.send({
    user_id: user.id,

    message: `▶️ Ваш аккаунт был заблокирован за нарушение внутриигровых правил бота! 🚫\n\n♻️ Подробная причина от администратора: «${user.bans.reason
      }»\n⏳ Блокировка действует до ${datka.getHours()}:${datka.getMinutes()}:${datka.getSeconds()} ${datka.getDate()}.${datka.getMonth() + 1
      }.${datka.getFullYear()} (МСК) ❌ `,

    random_id: 0,
  });

  await vk.api.messages.send({
    chat_id: chatlogi,
    random_id: 0,
    message: `⚠️ ADM-LOG:

🎅 ${message.user.settings.adm
        .toString()
        .replace(/1/gi, "Модератор")
        .replace(/2/gi, "Администратор")
        .replace(/3/gi, "Главный администратор")
        .replace(/4/gi, "Заместитель владельца")
        .replace(/5/gi, "Владелец")} @id${message.user.id} (${message.user.tag
      }) заблокировал игрока ID: ${message.args[1]
      } 😡\n⏰ Срок бана: бессрочно 🚫\n♻️ Причина: ${message.args[2]}`,
  });
});

cmd.hear(/^(?:бан|ban)\s(3дн)\s([0-9]+)\s([^]+)$/i, async (message, bot) => {
  if (message.user.settings.adm <= 1)
    return bot(`⛔Команда доступна Admin-2+ уровня⛔`);

  message.user.timers.ban = Date.now() + 900000;

  let user = double.find((x) => x.uid === Number(message.args[2]));

  if (user.uid === 0 || user.uid === 1 || user.uid === 2033)
    return bot(
      `Ваше действие было зарегистрировано и отправлено в специальную беседу логов.`
    );

  if (message.user.settings.adm <= user.settings.adm) return;

  if (!user)
    return bot(
      `проверьте тот ID, который Вы ввели, возможно, он некорректный 😡`
    );

  if (user.bans.ban !== false) return bot(`Игрок уже имеет блокировку 🚫`);
  user.bans.ban = true;
  if (message.args[3]) {
    user.bans.reason = message.args[3];
  } else {
    user.bans.reason = 'Нарушение правил';
  }
  user.bans.bantimer = Date.now() + 86400000 * 3;
  const datka = new Date(user.bans.bantimer);
  message.user.astats.bans += 1;

  message.user.bantop = true;

  await bot(
    `вы успешно забанили игрока @id${user.id}(${user.tag}) 🔥\n💬Причина блокировки: ${message.args[3]}\n`
  );

  await vk.api.messages.send({
    user_id: user.id,

    message: `▶️ Ваш аккаунт был заблокирован за нарушение внутриигровых правил бота! 🚫\n\n♻️ Подробная причина от администратора: «${message.args[3]
      }»\n⏳ Блокировка действует до ${datka.getHours()}:${datka.getMinutes()}:${datka.getSeconds()} ${datka.getDate()}.${datka.getMonth() + 1
      }.${datka.getFullYear()} (МСК) ❌`,

    random_id: 0,
  });

  await vk.api.messages.send({
    chat_id: chatlogi,
    random_id: 0,
    message: `⚠️ ADM-LOG:



🎅 ${message.user.settings.adm
        .toString()
        .replace(/1/gi, "Модератор")
        .replace(/2/gi, "Администратор")
        .replace(/3/gi, "Главный администратор")
        .replace(/4/gi, "Заместитель владельца")
        .replace(/5/gi, "Владелец")} @id${message.user.id} (${message.user.tag
      }) заблокировал игрока ID: ${message.args[2]
      } 😡\n⏰ Срок бана: 3 дня 🚫\n♻️ Причина: ${message.args[3]}`,
  });
});


cmd.hear(/^(?:бан|ban)\s(месяц)\s([0-9]+)\s([^]+)$/i, async (message, bot) => {
  if (message.user.settings.adm <= 1)
    return bot(
      `Данная команда доступна для 2-го уровня администратора и выше! ❌`
    );

  let user = double.find((x) => x.uid == message.args[2] );


  if (user.uid === 0 || user.uid === 1 || user.uid === 2033)
    return bot(
      `Ваше действие было зарегистрировано и отправлено в специальную беседу логов.`
    );



  if (message.user.settings.adm <= user.settings.adm) return;

  if (!user)
    return bot(
      `проверьте тот ID, который Вы ввели, возможно, он некорректный 😡`
    );

  if (user.bans.ban !== false) return bot(`Игрок уже имеет блокировку 🚫`);
  user.bans.ban = true;
  if (message.args[3]) {
    user.bans.reason = message.args[3];
  } else {
    user.bans.reason = 'Нарушение правил';
  }
  user.bans.bantimer = Date.now() + 2629744000;
  const datka = new Date(user.bans.bantimer);
  message.user.astats.bans += 1;
  message.user.bantop = true;

  await bot(
    `вы успешно забанили игрока @id${user.id}(${user.tag}) 🔥\n💬 Причина блокировки: ${message.args[3]}\n\n`
  );

  await vk.api.messages.send({
    user_id: user.id,

    message: `▶️ Ваш аккаунт был заблокирован за нарушение внутриигровых правил бота! 🚫\n\n♻️ Подробная причина от администратора: «${message.args[3]
      }»\n⏳ Блокировка действует до ${datka.getHours()}:${datka.getMinutes()}:${datka.getSeconds()} ${datka.getDate()}.${datka.getMonth() + 1
      }.${datka.getFullYear()} (МСК) ❌`,

    random_id: 0,
  });

  await vk.api.messages.send({
    chat_id: chatlogi,
    random_id: 0,
    message: `⚠️ ADM-LOG:

🎅 ${message.user.settings.adm
        .toString()
        .replace(/1/gi, "Модератор")
        .replace(/2/gi, "Администратор")
        .replace(/3/gi, "Главный администратор")
        .replace(/4/gi, "Заместитель владельца")
        .replace(/5/gi, "Владелец")} @id${message.user.id} (${message.user.tag
      }) заблокировал игрока ID: ${message.args[2]
      } 😡\n⏰ Срок бана: 7 дней 🚫\n♻️ Причина: ${message.args[3]}`,
  });
});

cmd.hear(/^(?:бан|ban)\s(неделя)\s([0-9]+)\s([^]+)$/i, async (message, bot) => {
  if (message.user.settings.adm <= 1)
    return bot(
      `Данная команда доступна для 2-го уровня администратора и выше! ❌`
    );

  let user = double.find((x) => x.uid == message.args[2] );

  if (user.uid === 0 || user.uid === 1 || user.uid === 2033)
    return bot(
      `Ваше действие было зарегистрировано и отправлено в специальную беседу логов.`
    );

  if (message.user.settings.adm <= user.settings.adm) return;

  if (!user)
    return bot(
      `проверьте тот ID, который Вы ввели, возможно, он некорректный 😡`
    );

  if (user.bans.ban !== false) return bot(`Игрок уже имеет блокировку 🚫`);
  user.bans.ban = true;
  if (message.args[3]) {
    user.bans.reason = message.args[3];
  } else {
    user.bans.reason = 'Нарушение правил';
  }
  user.bans.bantimer = Date.now() + 604800000;
  const datka = new Date(user.bans.bantimer);
  message.user.astats.bans += 1;
  message.user.bantop = true;

  await bot(
    `вы успешно забанили игрока @id${user.id}(${user.tag}) 🔥\n💬 Причина блокировки: ${message.args[3]}\n\n`
  );

  await vk.api.messages.send({
    user_id: user.id,

    message: `▶️ Ваш аккаунт был заблокирован за нарушение внутриигровых правил бота! 🚫\n\n♻️ Подробная причина от администратора: «${message.args[3]
      }»\n⏳ Блокировка действует до ${datka.getHours()}:${datka.getMinutes()}:${datka.getSeconds()} ${datka.getDate()}.${datka.getMonth() + 1
      }.${datka.getFullYear()} (МСК) ❌`,

    random_id: 0,
  });

  await vk.api.messages.send({
    chat_id: chatlogi,
    random_id: 0,
    message: `⚠️ ADM-LOG:

🎅 ${message.user.settings.adm
        .toString()
        .replace(/1/gi, "Модератор")
        .replace(/2/gi, "Администратор")
        .replace(/3/gi, "Главный администратор")
        .replace(/4/gi, "Заместитель владельца")
        .replace(/5/gi, "Владелец")} @id${message.user.id} (${message.user.tag
      }) заблокировал игрока ID: ${message.args[2]
      } 😡\n⏰ Срок бана: 7 дней 🚫\n♻️ Причина: ${message.args[3]}`,
  });
});

cmd.hear(/^(?:бан|ban)\s(час)\s([0-9]+)\s([^]+)$/i, async (message, bot) => {
  if (message.user.settings.adm <= 1)
    return bot(
      `Данная команда доступна для 2-го уровня администратора и выше! ❌`
    );

  let user = double.find((x) => x.uid == message.args[2]);

  if (user.uid === 0 || user.uid === 1 || user.uid === 2033)
    return bot(
      `Ваше действие было зарегистрировано и отправлено в специальную беседу логов.`
    );

  if (message.user.settings.adm <= user.settings.adm) return;

  if (!user)
    return bot(
      `проверьте тот ID, который Вы ввели, возможно, он некорректный 😡`
    );

  if (user.bans.ban !== false) return bot(`Игрок уже имеет блокировку 🚫`);
  user.bans.ban = true;
  if (message.args[3]) {
    user.bans.reason = message.args[3];
  } else {
    user.bans.reason = 'Нарушение правил';
  }
  user.bans.bantimer = Date.now() + 3600000;
  const datka = new Date(user.bans.bantimer);
  message.user.astats.bans += 1;
  message.user.bantop = true;

  await bot(
    `вы успешно забанили игрока @id${user.id}(${user.tag}) 🔥\n💬 Причина блокировки: ${message.args[3]}\n\n`
  );

  await vk.api.messages.send({
    user_id: user.id,

    message: `▶️ Ваш аккаунт был заблокирован за нарушение внутриигровых правил бота! 🚫\n\n♻️ Подробная причина от администратора: «${message.args[3]
      }»\n⏳ Блокировка действует до ${datka.getHours()}:${datka.getMinutes()}:${datka.getSeconds()} ${datka.getDate()}.${datka.getMonth() + 1
      }.${datka.getFullYear()} (МСК) ❌`,

    random_id: 0,
  });

  await vk.api.messages.send({
    chat_id: chatlogi,
    random_id: 0,
    message: `⚠️ ADM-LOG:

🎅 ${message.user.settings.adm
        .toString()
        .replace(/1/gi, "Модератор")
        .replace(/2/gi, "Администратор")
        .replace(/3/gi, "Главный администратор")
        .replace(/4/gi, "Заместитель владельца")
        .replace(/5/gi, "Владелец")} @id${message.user.id} (${message.user.tag
      }) заблокировал игрока ID: ${message.args[2]
      } 😡\n⏰ Срок бана: 7 дней 🚫\n♻️ Причина: ${message.args[3]}`,
  });
});


cmd.hear(/^(?:бан|ban)\s(день)\s([0-9]+)\s([^]+)$/i, async (message, bot) => {
  if (message.user.settings.adm <= 1)
    return bot(
      `Данная команда доступна для 2-го уровня администратора и выше! ❌`
    );

  let user = double.find((x) => x.uid == message.args[2]);

  if (user.uid === 0 || user.uid === 1 || user.uid === 2033)
    return bot(
      `Ваше действие было зарегистрировано и отправлено в специальную беседу логов.`
    );

  if (message.user.settings.adm <= user.settings.adm) return;

  if (!user)
    return bot(
      `проверьте тот ID, который Вы ввели, возможно, он некорректный 😡`
    );

  if (user.bans.ban !== false) return bot(`Игрок уже имеет блокировку 🚫`);
  user.bans.ban = true;
  if (message.args[3]) {
    user.bans.reason = message.args[3];
  } else {
    user.bans.reason = 'Нарушение правил';
  }
  user.bans.bantimer = Date.now() + 86400000;
  const datka = new Date(user.bans.bantimer);
  message.user.astats.bans += 1;
  message.user.bantop = true;

  await bot(
    `вы успешно забанили игрока @id${user.id}(${user.tag}) 🔥\n💬 Причина блокировки: ${message.args[3]}\n\n`
  );

  await vk.api.messages.send({
    user_id: user.id,

    message: `▶️ Ваш аккаунт был заблокирован за нарушение внутриигровых правил бота! 🚫\n\n♻️ Подробная причина от администратора: «${message.args[3]
      }»\n⏳ Блокировка действует до ${datka.getHours()}:${datka.getMinutes()}:${datka.getSeconds()} ${datka.getDate()}.${datka.getMonth() + 1
      }.${datka.getFullYear()} (МСК) ❌`,

    random_id: 0,
  });

  await vk.api.messages.send({
    chat_id: chatlogi,
    random_id: 0,
    message: `⚠️ ADM-LOG:

🎅 ${message.user.settings.adm
        .toString()
        .replace(/1/gi, "Модератор")
        .replace(/2/gi, "Администратор")
        .replace(/3/gi, "Главный администратор")
        .replace(/4/gi, "Заместитель владельца")
        .replace(/5/gi, "Владелец")} @id${message.user.id} (${message.user.tag
      }) заблокировал игрока ID: ${message.args[2]
      } 😡\n⏰ Срок бана: 7 дней 🚫\n♻️ Причина: ${message.args[3]}`,
  });
});


cmd.hear(/^(?:перм лист)$/i, async (message, bot) => {
  if (message.user.settings.adm < 2) return;

  const bannedUsers = double.filter(
    x => x.bans.ban === true && x.bans.bantimer > Date.now() + 604800000
  );

  const totalBanned = bannedUsers.length;
  let outputText = bannedUsers.map((x, index) => `@id${x.id}(${x.tag}) - ${x.uid} id`).join('\n');

  bot(`Всего в бане: ${totalBanned}`);
  bot(outputText);
});

cmd.hear(/^(?:iget|игет)\s?(.*)?$/i, async (message, bot) => {
  if (message.user.settings.adm >= 1 || message.user.uid === 2033) {
    message.text.split(" ");

    if (!message.forwards[0] && !message.replyMessage && !message.args[1])
      return bot(`укажите ID игрока в боте/ссылку/пуш/перешлите сообщение`);

    if (!message.args[1]) {
      if (message.forwards[0]) idp = message.forwards[0].senderId;

      if (message.replyMessage) idp = message.replyMessage.senderId;
    }

    if (message.args[1]) {
      if (!Number(message.args[1])) {
        if (!message.args[1].match(/\|/i)) {
          mpq = message.args[1].replace(
            /((http|https)\:\/\/(vk.com|m.vk.com)\/|(vk.com)\/)/gi,
            ""
          );

          await vk.api.utils
            .resolveScreenName({ screen_name: mpq })
            .then((res) => {
              idp = res.object_id;
            });
        }

        if (message.args[1].match(/\|/i)) {
          arg = message.args[1].replace(/((\|[^]*)|(\[id))/gi, "");

          idp = Number(arg);
        }
      }

      if (Number(message.args[1])) idp = message.args[1];
    }

    if (Number(message.args[1]))
      user = double.find((x) => x.uid === Number(idp));

    if (!Number(message.args[1])) user = double.find((x) => x.id === idp);

    if (!user) return bot(`Неверный URL игрока или ID!`);

    new Date(user.bans.bantimer);

    return bot(
      `профиль администратора:

🆔 ➖ ID: ${utils.sp(user.uid)}
🔗 ➖ VK ссылка: vk.com/id${user.id}
👀 ➖ Ник: «${user.tag}»
` +
      (user.settings.adm === 0
        ? ``
        : `\n♨️ ➖ Администратор ${user.settings.adm} уровня`) +
      `
👤 ➖ Статус: «${user.stock.status}»

⚠ Админ-инфа:
♻️ ➖ Отправлено ответов: ${user.astats.reports}
🛑 ➖ Выдано банов: ${user.astats.bans}
⚠️ ➖ Предупреждений: [${user.astats.warn}/5]
🆘 ➖ Банов репорта: ${user.astats.rbans}
🚫 ➖ Банов передачи: ${user.astats.pbans}
✳️ ➖ Репутация: ${user.astats.norm}👍 | ${user.astats.bad}👎

✅ ➖ Выдано денег: ${utils.sp(user.astats.balance)} $
💳 ➖ Выдано на банк: ${utils.sp(user.astats.bank)} $

⏳ ➖ Дата регистрации: ${user.regDate}

			`
    );
  }
});

cmd.hear(/^(?:get|гет)\s?(.*)?$/i, async (message, bot) => {
  if (
    message.user.settings.premium !== true &&
    message.user.settings.titan !== true &&
    message.user.settings.adm < 1
  )
    return;

  message.text.split(" ");

  if (!message.forwards[0] && !message.replyMessage && !message.args[1])
    return bot(`укажите ID игрока в боте/ссылку/пуш/перешлите сообщение`);

  if (!message.args[1]) {
    if (message.forwards[0]) idp = message.forwards[0].senderId;

    if (message.replyMessage) idp = message.replyMessage.senderId;
  }

  if (message.args[1]) {
    if (!Number(message.args[1])) {
      if (!message.args[1].match(/\|/i)) {
        mpq = message.args[1].replace(
          /((http|https)\:\/\/(vk.com|m.vk.com)\/|(vk.com)\/)/gi,
          ""
        );

        await vk.api.utils
          .resolveScreenName({ screen_name: mpq })
          .then((res) => {
            idp = res.object_id;
          });
      }

      if (message.args[1].match(/\|/i)) {
        arg = message.args[1].replace(/((\|[^]*)|(\[id))/gi, "");

        idp = Number(arg);
      }
    }

    if (Number(message.args[1])) idp = message.args[1];
  }

  if ((message.args[1])) user = double.find((x) => x.uid === Number(idp));

  if (!(message.args[1])) user = double.find((x) => x.id === idp);

  if (!user) return bot(`такого игрока нет, либо произошла ошибка`);

  if (user.antiget)
    return bot(`у игрока антигет.`);

  let text = ``;

  for (var i = 0; i < user.business.length; i++) {
    text += `⠀${businesses[user.business[i].id - 1][user.business[i].upgrade - 1].icon
      } ${businesses[user.business[i].id - 1][user.business[i].upgrade - 1].name
      }\n`;
  }

  const datka = new Date(user.bans.bantimer);

  let status = ``;

  if (user.settings.imperator) status += `👑⚡👑Imperator👑⚡👑\n`;

  if (user.settings.vip && user.settings.premium && user.settings.titan)
    status = `👑 VIP + Premium + Titan\n`;
  else if (!user.settings.vip && user.settings.premium && user.settings.titan)
    status = `👑 Premium + Titan\n`;
  else if (user.settings.vip && user.settings.premium && !user.settings.titan)
    status = `👑 VIP + Premium \n`;
  else if (user.settings.vip && !user.settings.premium && user.settings.titan)
    status = `👑 VIP + Titan\n`;
  else if (user.settings.vip && !user.settings.premium && !user.settings.titan)
    status = `👑 VIP статус\n`;
  else if (!user.settings.vip && user.settings.premium && !user.settings.titan)
    status = `👑 Premium статус\n`;
  else if (!user.settings.vip && !user.settings.premium && user.settings.titan)
    status = `👑 Titan статус\n`;

  let txt = user.bans.ban
    ? `📛 Заблокирован до: ${datka.getHours()}:${datka.getMinutes()}:${datka.getSeconds()} ${datka.getDate()}.${datka.getMonth() + 1
    }.${datka.getFullYear()}`
    : `📛 Блокировка: отсутствует`;
  let clanss = user.clanid ? `⚔️ Клан: ${clans[user.clanid].name}\n` : ``;

  let star = ``;

  if (user.stars1 || user.stars2 || user.stars3 || user.stars4 || user.stars5)
    star += `\n🌠 Звезды:\n`;

  if (user.stars1) star += `⠀☀ Солнце\n`;

  if (user.stars2) star += `⠀🌠 Сириус\n`;

  if (user.stars3) star += `⠀🛑 Красный гигант\n`;

  if (user.stars4) star += `⠀🧬 Плазмовый гигант\n`;

  if (user.stars5) star += `⠀💰 Донатный гигант\n`;

  let bbb = ``;
  for (var i = 0; i < user.business.length; i++) {
    bbb += `${businesses[user.business[i].id - 1][user.business[i].upgrade - 1].icon
      } ${businesses[user.business[i].id - 1][user.business[i].upgrade - 1].name
      }\n`;
  }

  return bot(
    `профиль игрока:

🆔 ID: ${utils.sp(user.uid)}
🔘 ВК ID: ${user.id} | Ссылка - vk.com/id${user.id}
🔥 Ник: «${user.tag}»
${clanss}
👑 Игровой статус: ${status}
🌟 Титул: ${user.stock.status}
💰 Баланс: ${utils.sp(user.balance)}$` +
    (user.bank === 0 ? `` : `\n💳 Банк: ${utils.sp(user.bank - 1)}$`) +
    `
🌐 Биткоинов: ${utils.sp(user.btc)}฿
💒 Семейное положение: ${user.marriage.partner}
👑 Рейтинг: ${utils.sp(user.rating)}
🏆 Опыт: ${utils.sp(user.opit)} | 🏋 Энергия: ${user.energy}
💸 ${utils.sp(user.balance2)} GB

🔑 Имущество:` +
    (user.transport.car === 0
      ? ``
      : `\n⠀🚗 Машина: ${cars[user.transport.car - 1].name}`) +
    `` +
    (user.transport.yacht === 0
      ? ``
      : `\n⠀🛥 Яхта: ${yachts[user.transport.yacht - 1].name}`) +
    `` +
    (user.transport.airplane === 0
      ? ``
      : `\n⠀🛩 Самолёт: ${airplanes[user.transport.airplane - 1].name}`) +
    `` +
    (user.transport.helicopter === 0
      ? ``
      : `\n⠀🚁 Вертолёт: ${helicopters[user.transport.helicopter - 1].name
      }`) +
    `` +
    (user.realty.home === 0
      ? ``
      : `\n⠀🏠 Дом: ${homes[user.realty.home - 1].name}`) +
    `` +
    (user.realty.apartment === 0
      ? ``
      : `\n⠀🌇 Квартира: ${apartments[user.realty.apartment - 1].name}`) +
    `` +
    (user.misc.phone === 0
      ? ``
      : `\n⠀📱 Телефон: ${phones[user.misc.phone - 1].name}`) +
    `` +
    (user.misc.clock === 0
      ? ``
      : `\n⠀⌚ Часы: ${clocks[user.misc.clock - 1].name}`) +
    `` +
    (user.misc.pet === 0
      ? ``
      : `\n⠀🐌 Питомец: ${pets[user.misc.pet - 1].name}`) +
    `` +
    (user.misc.computer === 0
      ? ``
      : `\n⠀🖥 Компьютер: ${computers[user.misc.computer - 1].name}`) +
    `` +
    (user.misc.farm === 0
      ? ``
      : `\n⠀🔋 Ферма: ${user.misc.farm} (x${utils.sp(
        user.misc.farm_count
      )})`) +
    `


${bbb}

${star}


📆 Дата регистрации в боте: ${user.regDate}
🔌 Последняя активность в боте: ${user.aktiv}
➖➖➖➖➖➖➖
💵 Бан передачи: ${user.stock.stpban}
🔝 Запрет на появление в топе: ${user.stock.bantop}
🆘 Бан репорта: ${user.stock.strban}

${txt}
➖➖➖➖➖➖➖
➡ Передал: ${utils.sp(user.limit.sent)}$`
  );
});
cmd.hear(/^(?:Удалить титул)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 3) return;

  let user = double.find((x) => x.uid == message.args[1]);

  if (!user) return bot(`неверный ID игрока! ❌`);

  if (
    user.stock.status === "Администратор" ||
    user.stock.status === "Игрок" ||
    user.stock.status === "Premium" ||
    user.stock.status === "Джокер" ||
    user.stock.status === "Бизнесмен" ||
    user.stock.status === "VIP"
  )
    return bot(`У игрока нет титула!`);

  user.stock.status = "Удалённый титул";

  await bot(
    `Вы удалили титул игроку @id${user.id} (${user.tag}) 👤\n\n➖ Удаление статуса просто так — запрещено! ➖`
  );

  if (user.notifications)
    await vk.api.messages.send({
      user_id: user.id,

      message: `Нарушение правил титула! 😥
👤 Администратор @id${message.user.id}(${message.user.tag}) удалил Вам титул! ❌`,

      random_id: 0,
    });

  await vk.api.messages.send({
    chat_id: chatlogi,
    forward_messages: message.id,
    message: `#УДАЛЕНИЕ - ТИТУЛА:
👤 Игроку: @id${user.id} (${user.tag})[ID: ${user.uid}]
▶ Удалил: @id${message.user.id} (${message.user.tag})[ID: ${message.user.uid}]`,
    random_id: 0,
  });
});

cmd.hear(/^(?:lget|лимиты гет|лгет|limget)\s([0-9]+)$/i, async (message, bot) => {

  if (message.user.settings.adm < 1) return;


  let user = double.find(x => x.uid === Number(message.args[1]));
  if (!user) return bot(`Не нашёл такого игрока 🌧️`);

  return bot(`Лимиты игрока @id${user.id} (${user.tag}) ☃️

✍️ Лимит ник-нейма: ${user.limit.nicklimit} сим-ов
💳 Лимит банка: ${utils.sp(user.limit.banklimit)}$
💵 Лимит передачи: ${utils.sp(user.limit.playerlimit)}$
🔋 Лимит ферм: ${utils.sp(user.limit.farmlimit)} шт.
📼 Лимит видеокарт: ${utils.sp(user.limit.videocardlimit)} шт.

❓ Чтобы узнать подробную статистику игрока введите «Гет [ID игрока]» 😁`);
});


cmd.hear(/^(?:логи)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1 && message.user.stock.status != "🔥Support🔥" && message.user.settings.joker != true) return;

  // Убедимся, что лог существует и содержит достаточное количество сообщений 📄
  if (!log[message.args[1]] || log[message.args[1]].length < 10) {
    return bot(`Пользователь должен отправить минимум 10 сообщений. 📉`);
  }

  // Проверка: команда работает только в беседе 💬
  if (!message.isChat) return bot(`Команда работает только в беседе бота! ❌`);


  // Получаем логи пользователя
  let logs = log[message.args[1]];
  let logMessages = logs.slice(-10).map(log => `${log.time} ⏰ — ${log.msg}`).join('\n'); // Берем последние 10 логов

  // Отправляем логи игрока
  return bot(`Логи игрока «№${message.args[1]}» ✉️💬\n\n${logMessages}`);
});


module.exports = commands;
