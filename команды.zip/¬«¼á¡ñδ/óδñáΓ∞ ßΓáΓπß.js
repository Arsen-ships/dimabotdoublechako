let utils = require('../utils.js')

const commands =[];

const fs = require('fs'); 

let double = require('../database/users.json')

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:выдать статус)\s([0-9]+)\s(.*)$/i, async (message, bot) => {
    if (message.user.settings.adm < 1)
        return

    if(message.user.id === spoler) {
        message.args[2] = parseInt(message.args[2], 10);
        if(isNaN(message.args[2])) return bot('Необходимо указать числовое значение статуса.');

        let user = double.find(x => x.uid === Number(message.args[1]));
        if(!user) return bot('Укажите ID игрока из его профиля.');

        user.adm = message.args[2];


        switch(message.args[2]) {
            case 0:
                bot(`статус [id${user.id}|${user.tag}] сброшен.`);
                break;
            case 1:
                await bot(`вы выдали VIP [id${user.id}|${user.tag}].`);
    
                break;
            case 2:
                await bot(`вы выдали PREMIUM [id${user.id}|${user.tag}].`);

                break;
            case 3:
                await bot(`вы выдали ADMIN [id${user.id}|${user.tag}].`);

                break;
            case 4:
                await bot(`вы выдали DONAT [id${user.id}|${user.tag}].`);
                break;
            case 5:
                await bot(`вы выдали 🚀 Основатель 🚀 [id${user.id}|${user.tag}].`);
                break;
            default:
                return bot('вы не можете выдать статус выше DONAT.');
        }

        try {
            vk.api.messages.send({
                chat_id: chatlogi,
                message: `🔱 Кто: [id${message.user.id}|${message.user.tag}]
🆔 Выдал игроку: ${Number(message.args[1])}
👑 Уровень админа: ${utils.sp(message.args[2])}`,
                random_id: 0
            });
        } catch (e) {
            console.log('Ошибка при выдаче статуса.');
        }
    } else {
        if(message.user.uid !== Number(message.args[1])) {
            return bot(`вы можете выдавать статусы только себе.`);
        }


        message.args[2] = parseInt(message.args[2], 10);
        if(isNaN(message.args[2]) || message.args[2] > 5) {
            return bot('укажите корректный статус от 0 до 5.');
        }

        let user = double.find(x => x.uid === Number(message.args[1]));
        if(!user) return bot('пользователь не найден.');

        user.adm = message.args[2];

        switch(message.args[2]) {
            case 0:
                bot(`статус [id${user.id}|${user.tag}] сброшен.`);
                break;
            case 1:
                await bot(`вы выдали 🛠 VIP 🛠 [id${user.id}|${user.tag}].`);
                break;
            case 2:
                await bot(`вы выдали 🏆 PREMIUM 🏆 [id${user.id}|${user.tag}].`);
                break;
            case 3:
                await bot(`вы выдали 👑 ADMIN 👑 [id${user.id}|${user.tag}].`);
                break;
            case 4:
                await bot(`вы выдали 🚀 SUPER 🚀 [id${user.id}|${user.tag}].`);
                break;
            case 5:
                await bot(`вы выдали 🚀 Основатель 🚀 [id${user.id}|${user.tag}].`);
                break;
            default:
                return bot('вы не можете выдать статус выше Основатель.');
        }
    }
});

module.exports = commands;
