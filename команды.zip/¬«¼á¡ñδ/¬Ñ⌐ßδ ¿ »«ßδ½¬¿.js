let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });


cmd.hear(/(?:кейсы|📦 Список кейсов|📦 Кейсы 🎰|@chakobot 📦 Кейсы|📦 Кейсы)$/i, async (message, bot) => {

  let text = `📦 Ваши кейсы:`

  if (message.user.c1 == 0) {

    if (message.user.c2 == 0) {

      if (message.user.c3 == 0) {

        if (message.user.c4 == 0) {

          if (message.user.c5 == 0) {

            if (message.user.c6 == 0) {

              if (message.user.c7 == 0) {

                if (message.user.c8 == 0) {

                  if (message.user.c9 == 0) {

                    if (message.user.c10 == 0) {

                      if (message.user.c11 == 0) {

                        text += `У вас нет кейсов.\n`

                      }

                    }

                  }

                }

              }

            }

          }

        }

      }

    }

  }

  if (message.user.c1 > 0) {

    text += `\n🔹 1. Обычный Кейс (${utils.sp(message.user.c1)} шт.)`;

  }

  if (message.user.c2 > 0) {

    text += `\n🔹 2. Золотой Кейс (${utils.sp(message.user.c2)} шт.)`;
  }

  if (message.user.c3 > 0) {

    text += `\n🔹 3. Донат-кейс (${utils.sp(message.user.c3)} шт.)`;

  }

  if (message.user.c4 > 0) {

    text += `\n🔹 4. Гоночный кейс (${utils.sp(message.user.c4)} шт.)`;

  }

  if (message.user.c5 > 0) {

    text += `\n🔹 5. Halloween кейсов (${utils.sp(message.user.c5)} шт.)`;

  }

  if (message.user.c6 > 0) {

    text += `\n🔹 6. Секретных кейсов (${utils.sp(message.user.c6)} шт.)`;

  }

  if (message.user.c7 > 0) {

    text += `\n🔹 7. Автозвук кейсов (${utils.sp(message.user.c7)} шт.)`;

  }

  if (message.user.c8 > 0) {

    text += `\n🔹 8. Новогодних кейсов (${utils.sp(message.user.c8)} шт.)`;

  }

  if (message.user.c9 > 0) {

    text += `\n🔹 9. Премиум кейсов (${utils.sp(message.user.c9)} шт.)`;

  }

  if (message.user.c10 > 0) {

    text += `\n🔹 10. Ультра кейсов (${utils.sp(message.user.c10)} шт.)`;

  }

  if (message.user.c11 > 0) {

    text += `\n🔹 11. Админ кейсов (${utils.sp(message.user.c11)} шт.)`;

  }

  text += `\n❓ Покупка: «Кейс [номер] [кол-во]» ❄️\n🔑 Открыть кейс: «Кейс открыть [номер]» 🔥`;



  return bot(`кейсы:

📦 1. Обычный Кейс — 50.000.000.000.000$
📦 2. Золотой Кейс — 5.000.000.000.000.000$
📦 3. Донат-кейс — 15руб. (иначе = 150 ЧакоРуб)

${text}`);

});

cmd.hear(/^(?:кейс инфо)\s([0-9]+)$/i, async (message, bot) => {

  if (message.args[1] < 0 && message.args[1] > 7) return bot(`Вы ввели неверный номер кейса`);

  if (message.args[1] == 1)

    return bot(`Призы из обычного кейса:\n⃣ 💰 Деньги 💰\n⃣ 📈 Опыт 📈\n⃣ 💥 Рейтинг 💥\n⃣ 💸 Биткоины 💸`);

  if (message.args[1] == 2)

    return bot(`Призы из золотых кейса:\n⃣ 💰 Деньги 💰\n⃣ 📈 Опыт 📈\n⃣ 💥 Рейтинг\n⃣ 💸 Биткоины 💸💥`);

  if (message.args[1] == 3)

    return bot(`Призы из донат кейса:\n⃣ 💰 Деньги 💰\n⃣ 📈 Опыт 📈\n⃣ 💥 Рейтинг\n⃣ 📦 Донат кейсы 📦\n⃣ 💎 VIP статус 💎\n⃣ 💎 Premium статус 💎`);

  if (message.args[1] == 4)

    return bot(`Призы из гоночного кейса:\n⃣ 💰 Деньги ??\n⃣ 📈 Опыт 📈\n⃣ 💥 Рейтинг 💥`);

  if (message.args[1] == 5)

    return bot(`Призы из супер кейса:\n⃣ 💰 Деньги 💰\n⃣ 💥 Рейтинг 💥\n⃣ 🌳 Дерево 🌳\n⃣ 🐙 Питомец 🐙\n⃣ 🏦 Бизнес 🏦\n⃣ 🚙 Машина 🚙\n⃣ 🔥 Premium статус🔥`);

  if (message.args[1] == 6)

    return bot(`Призы из секретного кейса:\n⃣ 💰 Деньги 💰\n⃣ 📈 Опыт 📈\n⃣ 💥 Рейтинг 💥\n⃣ 🐙 Питомец 🐙\n⃣ 📜 Сертификат на кинобизнес 📜\n⃣ 📜 Сертификат на лучшую машину 📜\n⃣ 🔥 Premium статус🔥`);

  if (message.args[1] == 7)

    return bot(`Призы из автозвук кейса:\n⃣ 💰 Деньги 💰\n⃣ 📈 Опыт 📈\n⃣ 💥 Рейтинг 💥`);

  if (message.args[1] == 8)

    return bot(`Информацию узнать нельзя`);

  if (message.args[1] == 9)

    return bot(`Призы из премиум кейса:\n⃣ 💰 Деньги 💰\n⃣ 📈 Опыт 📈\n⃣ 💥 Рейтинг 💥\n📜 Сертификат на кинобизнес 📜\n⃣ 💸 Биткоины 💸\n⃣ 📜 Сертификат на лучшую машину 📜\n⃣ 🔥 Сертификат на Premium статус\n⃣ 🔥 Titan VIP 🔥`);

});

cmd.hear(/^(?:кейс открыть 1)\s([0-9]+)$/i, async (message, bot) => {

  if (message.user.c1 < message.args[1]) return bot(`У вас нет столько кейсов.`);



  if (!message.user.settings.titan && !message.user.settings.premium) return bot(`Открывать несколько кейсов можно со статусом "Premium VIP" `);



  if (message.args[1] < 1 || message.args[1] > 15 && !message.user.settings.titan) return bot(`Больше 15 кейсов за раз открывать нельзя.`);

  if (message.args[1] < 1 || message.args[1] > 100 && message.user.settings.titan) return bot(`Больше 100 кейсов за раз открывать нельзя.`);



  message.user.c1 -= message.args[1];

  if (message.user.otkr == undefined) {
    message.user.otkr = 0;
  }
  message.user.otkr += message.args[1];

  let btc = 0;

  let money = 0;

  let rating = 0;

  let opit = 0;

  let t = message.args[1];

  for (let i = 0; i < t; i++) {

    let rand = utils.random(1, 4);

    if (rand == 1) {

      let bon = utils.random(10, 100);

      bon *= 1000000000;

      money += bon;

    }

    if (rand == 2) {

      let bon = utils.random(10, 60);

      opit += bon;

    }

    if (rand == 3) {

      let bon = utils.random(1, 500);

      rating += bon;

    }

    if (rand == 4) {

      btc += 500000;

    }

  }

  message.user.btc += btc;

  message.user.balance += money;

  message.user.opit += opit;

  message.user.rating += rating;

  return bot(`Вы успешно открыли ${utils.sp(message.args[1])} кейсов.

✅ ➖ С них Вам выпало:
🌐 Биткоины: ${utils.sp(btc)} BTC
💲 Деньги: ${utils.sp(money)}$
👑 Рейтинг: ${utils.sp(rating)}
📈 Опыт: ${utils.sp(opit)}

▶️ Весь лут уже находится на Вашем аккаунте.`,

    {

      keyboard: JSON.stringify(

        {

          "inline": true,

          "buttons": [

            [{

              "action": {

                "type": "text",

                "payload": "{}",

                "label": `Кейс открыть 1 ${message.args[1]}`

              },

              "color": "primary"

            }]

          ]

        })

    });

});

cmd.hear(/^(?:📦 кейс открыть 1|кейс открыть 1)$/i, async (message, bot) => {

  if (message.user.c1 < 1) return bot(`У Вас нет «Обычного кейса» ❌`)

  message.user.c1 -= 1
  if (message.user.otkr == undefined) {
    message.user.otkr = 0;
  }
  message.user.otkr += 1;


  let rand = utils.random(1, 4)

  if (rand == 1) {

    let bon = utils.random(10, 100)

    bon *= 100000000000

    message.user.balance += bon

    return bot(`Вы выиграли ${utils.sp(bon)}$ 💵`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "📦 Кейс открыть 1" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 2) {

    let bon = utils.random(10, 100)

    message.user.opit += bon

    return bot(`Вы выиграли ${utils.sp(bon)} опыта! 🏆`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "📦 Кейс открыть 1" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 3) {

    let bon = utils.random(30, 600)

    message.user.rating += bon

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга! 👑`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "📦 Кейс открыть 1" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 4) {

    message.user.btc += 50000000

    return bot(`Вы выиграли 50.000.000 биткоинов! 🌐`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "📦 Кейс открыть 1" },

          "color": "positive"

        }],]

      })

    })

  }

});

cmd.hear(/^(?:кейс открыть 2)\s([0-9]+)$/i, async (message, bot) => {

  if (message.user.c2 < message.args[1]) return bot(`У вас нет столько кейсов.`);

  if (!message.user.settings.premium) return bot(`Открывать несколько кейсов можно со статусом "Premium VIP" `);

  if (message.args[1] < 1 || message.args[1] > 15 && !message.user.settings.titan) return bot(`Больше 15 кейсов за раз открывать нельзя.`);

  if (message.args[1] < 1 || message.args[1] > 100 && message.user.settings.titan) return bot(`Больше 100 кейсов за раз открывать нельзя.`);



  message.user.c2 -= message.args[1];
  if (message.user.otkr == undefined) {
    message.user.otkr = 0;
  }
  message.user.otkr += message.args[1];

  let btc = 0;

  let money = 0;

  let rating = 0;

  let opit = 0;

  let t = message.args[1];

  for (let i = 0; i < t; i++) {

    let rand = utils.random(1, 23)

    if (rand == 1) {

      let bon = utils.random(500, 10000);

      bon *= 1000000000;

      money += bon;

    }

    if (rand == 2) {

      let bon = utils.random(200, 300);

      opit += bon;

    }

    if (rand == 3) {

      let bon = utils.random(300, 30000);

      rating += bon;

    }

    if (rand == 4) {

      money += 200000000000;

    }

    if (rand == 5) {

      opit += 1500;

    }

    if (rand == 6) {

      money += 30000000000000;

    }

    if (rand == 7) {

      btc += 10000000;

    }

    if (rand == 8) {

      message.user.rating += 10000;

    }

    if (rand == 9) {

      money += 3000000000000;

    }

    if (rand == 10) {

      money += 5000000000000;

    }

    if (rand == 11) {

      opit += 1;

    }

    if (rand == 12) {

      let bon = utils.random(50, 2000);

      bon *= 1000000000;

      money += bon;

    }

    if (rand == 13) {

      money += 10000000000;

    }

    if (rand == 14) {

      opit += 1;

    }

    if (rand == 15) {

      money += 1000000000000;

    }

    if (rand == 16) {

      btc += 50000000;

    }

    if (rand == 17) {

      rating += 100000;

    }

    if (rand == 18) {

      let bon = utils.random(100, 10000);

      bon *= 1000000000;

      money += bon;

    }

    if (rand == 19) {

      opit += 1;

    }

    if (rand == 20) {

      money += 3000000000000;

    }

    if (rand == 21) {

      btc += 500000;

    }

    if (rand == 22) {

      money += 10000000000;

    }

    if (rand == 23) {

      opit += 2500;

    }

  }

  message.user.btc += btc;

  message.user.balance += money;

  message.user.opit += opit;

  message.user.rating += rating;

  return bot(`Вы успешно открыли ${utils.sp(message.args[1])} кейсов.



✅ ➖ С них Вам выпало:

🌐 Биткоины: ${utils.sp(btc)} BTC

💲 Деньги: ${utils.sp(money)}$

👑 Рейтинг: ${utils.sp(rating)}

📈 Опыт: ${utils.sp(opit)}



▶️ Весь лут уже находится на Вашем аккаунте.`,

    {

      keyboard: JSON.stringify(

        {

          "inline": true,

          "buttons": [

            [{

              "action": {

                "type": "text",

                "payload": "{}",

                "label": `Кейс открыть 2 ${message.args[1]}`

              },

              "color": "primary"

            }]

          ]

        })

    });

});





cmd.hear(/^(?:кейс открыть 2|📦 кейс открыть 2)$/i, async (message, bot) => {

  if (message.user.captcha.vid !== false) {

    if (message.user.captcha.vid == 1) return bot(`подозрительная активность! ❌

Введите «капча ${message.user.captcha.otvet}», чтобы пройти проверку на робота!`)

    if (message.user.captcha.vid == 2) return bot(`подозрительная активность! ❌

Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2}» и введите "капча [ответ]"`)

  }

  let captcha = utils.random(1, 100)

  if (captcha == 44) {

    let t = utils.pick([1, 2])

    if (t == 1) {

      let otv = utils.random(100, 500)

      message.user.captcha.vid = 1

      message.user.captcha.otvet = otv

      return bot(`подозрительная активность! ❌

Введите «капча ${otv}», чтобы пройти проверку на робота!`)

    }

    if (t == 2) {

      let pr1 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20])

      let pr2 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20])

      message.user.captcha.vid = 2

      message.user.captcha.otvet = pr1 + pr2

      message.user.captcha.primer = pr1 + pr2

      return bot(`подозрительная активность! ❌

Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2}» и введите "капча [ответ]"`)

    }

  }

  if (message.user.c2 < 1) return bot(`У вас нет «Золотого кейса» ❌`)

  message.user.c2 -= 1
  if (message.user.otkr == undefined) {
    message.user.otkr = 0;
  }
  message.user.otkr += 1;

  let rand = utils.random(1, 3)

  if (rand == 1) {

    let bon = utils.random(500, 10000)

    bon *= 10000000000000

    message.user.balance += bon

    return bot(`Вы выиграли ${utils.sp(bon)}$ 💵`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "📦 Кейс открыть 2" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 2) {

    let bon = utils.random(500, 4500)

    message.user.opit += bon

    return bot(`Вы выиграли ${utils.sp(bon)} опыта! 📈`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "📦 Кейс открыть 2" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 3) {

    let bon = utils.random(3000, 35000)

    message.user.rating += bon

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга! 👑`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "📦 Кейс открыть 2" },

          "color": "positive"

        }],]

      })

    })

  }



  return bot(`вы ничего не выиграли.`, {

    keyboard: JSON.stringify({

      "inline": true,

      "buttons": [[{

        "action": { "type": "text", "payload": "{}", "label": "📦 Кейс открыть 2" },

        "color": "positive"

      }],]

    })

  })

});



cmd.hear(/^(?:кейс открыть 3)$/i, async (message, bot) => {

  if (message.user.captcha.vid !== false) {

    if (message.user.captcha.vid == 1) return bot(`подозрительная активность! ❌

Введите «капча ${message.user.captcha.otvet}», чтобы пройти проверку на робота!`)

    if (message.user.captcha.vid == 2) return bot(`подозрительная активность! ❌

Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2}» и введите "капча [ответ]"`)

  }

  let captcha = utils.random(1, 100)

  if (captcha == 44) {

    let t = utils.pick([1, 2])

    if (t == 1) {

      let otv = utils.random(100, 500)

      message.user.captcha.vid = 1

      message.user.captcha.otvet = otv

      return bot(`подозрительная активность! ❌

Введите «капча ${otv}», чтобы пройти проверку на робота!`)

    }

    if (t == 2) {

      let pr1 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20])

      let pr2 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20])

      message.user.captcha.vid = 2

      message.user.captcha.otvet = pr1 + pr2

      message.user.captcha.primer = pr1 + pr2

      return bot(`подозрительная активность! ❌

Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2}» и введите "капча [ответ]"`)

    }

  }

  if (message.user.c3 < 1) return bot(`У вас нет "Донат-кейса".`)

  message.user.c3 -= 1
  if (message.user.otkr == undefined) {
    message.user.otkr = 0;
  }
  message.user.otkr += 1;

  if (typeof message.user.questdonat === "number") {

    message.user.questdonat++;

    if (message.user.questdonat >= 5) {

      message.user.questdonat = true;

      await bot(`Поздравляем, Вы 5 раз открыли донат-кейс и получаете 📦 1 Донат-кейс.`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

            "color": "positive"

          }],]

        })

      });

      message.user.c3 += 1;

    }

  }

  if (typeof message.user.questdonat2 === "number" && message.user.questallfucker == true) {

    message.user.questdonat2++;

    if (message.user.questdonat2 >= 50) {

      message.user.questdonat2 = true;

      await bot(`Поздравляем, Вы 50 раз открыли донат-кейс и получаете 2 Донат-кейсa.`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

            "color": "positive"

          }],]

        })

      });

      message.user.c3 += 2;

    }

  }

  let rand = utils.random(1, 15)

  if (rand == 1) {

    let bon = utils.random(50000, 100000)

    bon *= 1000000000

    message.user.balance += bon

    return bot(`Вы выиграли ${utils.sp(bon)}$ 💵`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 2) {

    let bon = utils.random(15000, 50000)

    message.user.rating += bon

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга! 📈`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 3) {



    if (message.user.settings.vip !== false) {

      message.user.c3++;

      return bot('Вы выиграли VIP статус!\n♻️ Вы уже являетесь VIP, выдана компенсация в виде донат-кейса', {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

            "color": "positive"

          }],]

        })

      });

    }

    if (message.user.settings.premium || message.user.settings.titan) {

      message.user.settings.vip = true;

      return bot('Вы выиграли VIP статус! 🤗\n\n▶️ Узнать список всех команд VIP: «VIP help»', {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

            "color": "positive"

          }],]

        })

      });

    }

    message.user.settings.vip = true

    message.user.stock.status = "VIP"

    message.user.limit.nicklimit = 21

    message.user.level += 5

    message.user.limit.banklimit = 100000000000000;

    message.user.limit.farmlimit = 3000;

    message.user.limit.videocardlimit = 50;

    message.user.limit.playerlimit = 100000000000000;

    message.user.limit.sent = 0;

    message.user.maxenergy = 20;

    return bot(`Вы выиграли VIP статус! 🤗\n\n▶️ Узнать список всех команд VIP: «VIP help»`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 4) {

    let bon = utils.random(10, 50)

    message.user.rub += bon

    return bot(`Вы выиграли ${utils.sp(bon)} ЧакоРуб 💰`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Обмен ЧакоРуб" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 5) {

    message.user.balance += 1000000000000

    return bot(`Вы выиграли 1.000.000.000.000$ 💵`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 6) {

    message.user.balance += 5000000000000

    return bot(`Вы выиграли 5.000.000.000.000$ 💵`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 7) {

    message.user.opit += 500

    return bot(`Вы выиграли 500 опыта! 📈`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 8) {

    message.user.c3 += 2

    return bot(`Вы выиграли 2 Донат-кейса! 📦`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 9) {

    let bon = utils.random(15000, 50000)

    message.user.rating += bon

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга! 👑`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 10) {

    message.user.opit += 3500

    return bot(`Вы выиграли 3500 опыта! 📈`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 11) {

    let bon = utils.random(15000, 50000)

    message.user.rating += bon

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга! 👑`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 12) {

    let bon = utils.random(1000, 5000)

    message.user.balance2 += bon

    return bot(`Вы выиграли ${utils.sp(bon)} GB! 👑`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 13) {

    let bon = utils.random(3000, 15000)

    message.user.balance2 += bon

    return bot(`Вы выиграли ${utils.sp(bon)} GB! 👑`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 14) {

    let bon = utils.random(5000, 10000)

    message.user.balance2 += bon

    return bot(`Вы выиграли ${utils.sp(bon)} GB! 👑`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 15) {

    let bon = utils.random(50000, 100000)

    bon *= 1000000000

    message.user.balance += bon

    return bot(`Вы выиграли ${utils.sp(bon)}$ 💵`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 3" },

          "color": "positive"

        }],]

      })

    })

  }

});

cmd.hear(/^(?:кейс открыть 4)\s([0-9]+)$/i, async (message, bot) => {

  if (message.user.c4 < message.args[1]) return bot(`У вас нет столько кейсов.`);

  if (!message.user.settings.titan && !message.user.settings.premium) return bot(`Открывать несколько кейсов можно со статусом "Premium VIP" `);

  if (message.args[1] < 1 || message.args[1] > 15 && message.user.settings.premium && !message.user.settings.titan) return bot(`Больше 15 кейсов за раз открывать нельзя.`);

  if (message.args[1] < 1 || message.args[1] > 100 && message.user.settings.titan && !message.user.settings.topdon) return bot(`Больше 100 кейсов за раз открывать нельзя.`);

  message.user.c4 -= message.args[1];
  if (message.user.otkr == undefined) {
    message.user.otkr = 0;
  }
  message.user.otkr += message.args[1];

  let money = 0;

  let rating = 0;

  let opit = 0;

  let t = message.args[1];

  for (let i = 0; i < t; i++) {

    let rand = utils.random(1, 6);

    if (rand == 1) {

      let bon = utils.random(100, 3000)

      bon *= 10000000000

      money += bon;

    }

    if (rand == 2) {

      let bon = utils.random(100, 1200)

      opit += bon;

    }

    if (rand == 3) {

      let bon = utils.random(60000, 300000)

      rating += bon;

    }

    if (rand == 4) {

      opit += 1;

    }

    if (rand == 5) {

      money += 400000000000;

    }

    if (rand == 6) {

      money += 200000000000;

    }

  }

  message.user.balance += money;

  message.user.opit += opit;

  message.user.rating += rating;

  return bot(`Вы успешно открыли ${utils.sp(message.args[1])} кейсов.



✅ ➖ С них Вам выпало:

💲 Деньги: ${utils.sp(money)}$

👑 Рейтинг: ${utils.sp(rating)}

📈 Опыт: ${utils.sp(opit)}



▶️ Весь лут уже находится на Вашем аккаунте.`,

    {

      keyboard: JSON.stringify(

        {

          "inline": true,

          "buttons": [

            [{

              "action": {

                "type": "text",

                "payload": "{}",

                "label": `Кейс открыть 4 ${message.args[1]}`

              },

              "color": "primary"

            }]

          ]

        })

    });

});

cmd.hear(/^(?:кейс открыть 4)$/i, async (message, bot) => {

  if (message.user.captcha.vid !== false) {

    if (message.user.captcha.vid == 1) return bot(`подозрительная активность! ❌

Введите "капча ${message.user.captcha.otvet}", чтобы пройти проверку на робота!`)

    if (message.user.captcha.vid == 2) return bot(`подозрительная активность! ❌

Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2}» и введите "капча [ответ]"`)

  }

  let captcha = utils.random(1, 100)

  if (captcha == 44) {

    let t = utils.pick([1, 2])

    if (t == 1) {

      let otv = utils.random(100, 500)

      message.user.captcha.vid = 1

      message.user.captcha.otvet = otv

      return bot(`подозрительная активность! ❌

Введите "капча ${otv}", чтобы пройти проверку на робота!`)

    }

    if (t == 2) {

      let pr1 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20])

      let pr2 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20])

      message.user.captcha.vid = 2

      message.user.captcha.otvet = pr1 + pr2

      message.user.captcha.primer = pr1 + pr2

      return bot(`подозрительная активность! ❌

Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2}» и введите "капча [ответ]"`)

    }

  }

  if (message.user.c4 < 1) return bot(`У вас нет "Гоночного кейса".`) // (советую настроить всю команду под себя)

  message.user.c4 -= 1
  if (message.user.otkr == undefined) {
    message.user.otkr = 0;
  }
  message.user.otkr += 1;

  let rand = utils.random(1, 6)

  if (rand == 1) {

    let bon = utils.random(100, 3000)

    bon *= 10000000000

    message.user.balance += bon

    return bot(`Вы выиграли ${utils.sp(bon)}$`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 4" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 2) {

    let bon = utils.random(100, 1200)

    message.user.opit += bon

    return bot(`Вы выиграли ${utils.sp(bon)} опыта`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 4" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 3) {

    let bon = utils.random(60000, 300000)

    message.user.rating += bon

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 4" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 4) {

    return bot(`вы ничего не выиграли.`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 4" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 5) {

    message.user.balance += 400000000000

    return bot(`Вы выиграли 400.000.000.000$`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 4" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 6) {

    message.user.balance += 200000000000

    return bot(`Вы выиграли 200.000.000.000$`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 4" },

          "color": "positive"

        }],]

      })

    })

  }

});



cmd.hear(/^(?:кейс открыть 7)\s([0-9]+)$/i, async (message, bot) => {

  if (message.user.c7 < message.args[1]) return bot(`У вас нет столько кейсов.`);

  if (!message.user.settings.titan && !message.user.settings.premium) return bot(`Открывать несколько кейсов можно со статусом "Premium VIP" `);



  if (message.args[1] < 1 || message.args[1] > 15 && !message.user.settings.titan) return bot(`Больше 15 кейсов за раз открывать нельзя.`);

  if (message.args[1] < 1 || message.args[1] > 100 && message.user.settings.titan) return bot(`Больше 100 кейсов за раз открывать нельзя.`);



  message.user.c7 -= message.args[1];

  let money = 0;

  let rating = 0;

  let opit = 0;

  let t = message.args[1];

  for (let i = 0; i < t; i++) {

    let rand = utils.random(1, 6);

    if (rand == 1) {

      let bon = utils.random(100, 3000)

      bon *= 10000000000

      money += bon;

    }

    if (rand == 2) {

      let bon = utils.random(100, 1200)

      opit += bon;

    }

    if (rand == 3) {

      let bon = utils.random(60000, 300000)

      rating += bon;

    }

    if (rand == 4) {

      opit += 1;

    }

    if (rand == 5) {

      money += 400000000000;

    }

    if (rand == 6) {

      money += 200000000000;

    }

  }

  message.user.balance += money;

  message.user.opit += opit;

  message.user.rating += rating;

  return bot(`Вы успешно открыли ${utils.sp(message.args[1])} кейсов.



✅ ➖ С них Вам выпало:

💲 Деньги: ${utils.sp(money)}$

👑 Рейтинг: ${utils.sp(rating)}

📈 Опыт: ${utils.sp(opit)}



▶️ Весь лут уже находится на Вашем аккаунте.`,

    {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": `Кейс открыть 7 ${message.args[1]}` },

          "color": "positive"

        }],]

      })

    })

});

cmd.hear(/^(?:кейс открыть 7)$/i, async (message, bot) => {

  if (message.user.c7 < 1) return bot(`У вас нет "Кейса Автозвука".`) // (советую настроить всю команду под себя)

  message.user.c7 -= 1

  let rand = utils.random(1, 6)

  if (rand == 1) {

    let bon = utils.random(100, 3000)

    bon *= 10000000000

    message.user.balance += bon

    return bot(`Вы выиграли ${utils.sp(bon)}$`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 7" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 2) {

    let bon = utils.random(100, 1200)

    message.user.opit += bon

    return bot(`Вы выиграли ${utils.sp(bon)} опыта`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 7" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 3) {

    let bon = utils.random(60000, 300000)

    message.user.rating += bon

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 7" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 4) {

    return bot(`вы ничего не выиграли.`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 7" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 5) {

    message.user.balance += 400000000000

    return bot(`Вы выиграли 400.000.000.000$`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 7" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 6) {

    message.user.balance += 200000000000

    return bot(`Вы выиграли 200.000.000.000$`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 7" },

          "color": "positive"

        }],]

      })

    })

  }

});

cmd.hear(/^(?:кейс открыть 5)$/i, async (message, bot) => {

  if (message.user.c5 < 1) return bot(`У вас нет "Halloween кейса".`)

  message.user.c5 -= 1

  let rand = utils.random(1, 8)

  if (rand == 1) {

    message.user.balance += 100000000000000

    return bot(`Вы выиграли 100.000.000.000.000 $`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 2) {

    if (message.user.tree == 4) {

      return bot(`Вы выиграли Дерево, но у вас уже такое есть, мы дарим вам еще 1 кейс`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

            "color": "positive"

          }],]

        })

      });

      message.user.c5 += 1;

    }

    message.user.tree = 4;

    message.user.irrigation = 100;

    message.user.leafpribil = 100;

    return bot(`Вы выиграли безлиственное дерево`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 3) {

    let bon = utils.random(500000, 1000000)

    message.user.rating += bon

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 5) {

    if (message.user.business.length >= 4) {

      message.user.c5 += 1;

      return bot(`у вас уже есть 4 бизнеса, поэтому мы дарим вам еще 1 кейс`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

            "color": "positive"

          }],]

        })

      });

    }

    message.user.business2.push({

      "id": 17,

      "upgrade": 1,

      "workers": 1,

      "moneys": 10000000000000

    });

    return bot(`Вы выиграли Праздничный бизнес`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 6) {

    let bon = utils.random(1000, 1200)

    message.user.rub += bon

    return bot(`Вы выиграли ${utils.sp(bon)} ЧакоРуб`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Обмен ЧакоРуб" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 7) {

    if (message.user.business.length >= 4) {

      message.user.c5 += 1;

      return bot(`у вас уже есть 4 бизнеса, поэтому мы дарим вам еще 1 кейс`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

            "color": "positive"

          }],]

        })

      });

    }

    message.user.business2.push({

      "id": 14,

      "upgrade": 1,

      "workers": 1,

      "moneys": 10000000000000

    });

    return bot(`Вы выиграли Праздничный бизнес`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 8) {

    if (message.user.settings.premium == true) {

      message.user.c5 += 1;

      return bot(`у вас уже есть Premium поэтому мы дарим вам еще 1 кейс`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

            "color": "positive"

          }],]

        })

      });

    }



    if (message.user.settings.titan == true) {

      message.user.settings.premium = true;

      return bot(`Вы выиграли Premium`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

            "color": "positive"

          }],]

        })

      });

    }



    message.user.settings.premium = true;

    message.user.stock.status = "Premium";

    message.user.limit.nicklimit = 32;

    message.user.opit += 5000;

    message.user.level += 35;

    message.user.bilet += 5;

    message.user.limit.banklimit = 200000000000000;

    message.user.limit.farmlimit = 5000;

    message.user.limit.videocardlimit = 75;

    message.user.limit.playerlimit = 200000000000000;

    message.user.limit.sent = 0;

    message.user.maxenergy = 30;

    return bot(`Вы выиграли Premium`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

          "color": "positive"

        }],]

      })

    });

  } else {

    return bot(`вы ничего не выиграли.`, {
      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 5" },

          "color": "positive"

        }],]

      })

    });

  }

});



cmd.hear(/^(?:кейс открыть 6)$/i, async (message, bot) => {

  if (message.user.c6 < 1) return bot(`У вас нет "Секретного кейса".`) // (советую настроить всю команду под себя)

  message.user.c6 -= 1

  let rand = utils.random(1, 15)

  if (rand == 1) {

    message.user.balance += 100000000000000

    return bot(`Вы выиграли 100.000.000.000.000$`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 2) {

    let bon = utils.random(4000, 6000)

    message.user.opit += bon

    return bot(`Вы выиграли ${utils.sp(bon)} опыта`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 3) {

    let bon = utils.random(500000, 1000000)

    message.user.rating += bon

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 4) {

    if (message.user.misc.pet >= 11) {

      message.user.c6 += 1;///////////////

      return bot(`Вы выиграли улучшенного динозавра, но у вас есть праздничный питомец,и мы не хоти у вас его забирать,поэтому дарим вам еще 1 кейс`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

            "color": "positive"

          }],]

        })

      });

    }

    message.user.misc.pet = 8;

    message.user.pet.lvl = utils.random(10, 20)

    return bot(`Вы выиграли улучшенного динозавра`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 5) {

    message.user.sertificats.business += 1;

    return bot(`Вы выиграли Сертификат на кинобизнес`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 6) {

    message.user.sertificats.car += 1;

    return bot(`Вы выиграли сертификат на лучшую машину`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 7) {

    let bon = utils.random(500, 800)

    message.user.rub += bon

    return bot(`Вы выиграли ${utils.sp(bon)} ЧакоРуб`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Обмен ЧакоРуб" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 8) {

    if (message.user.settings.premium == true) {

      message.user.c6 += 1;

      return bot(`у вас уже есть Premium поэтому мы дарим вам еще 1 кейс`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

            "color": "positive"

          }],]

        })

      });

    }



    if (message.user.settings.titan == true) {

      message.user.settings.premium = true;

      return bot(`Вы выиграли Premium`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

            "color": "positive"

          }],]

        })

      });

    }



    message.user.settings.premium = true;

    message.user.stock.status = "Premium";

    message.user.limit.nicklimit = 32;

    message.user.opit += 5000;

    message.user.level += 35;

    message.user.bilet += 5;

    message.user.limit.banklimit = 200000000000000;

    message.user.limit.farmlimit = 5000;

    message.user.limit.videocardlimit = 75;

    message.user.limit.playerlimit = 200000000000000;

    message.user.limit.sent = 0;

    message.user.maxenergy = 30;

    return bot(`Вы выиграли Premium`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    });

  }

  if (rand == 9) {

    if (message.user.misc.pet >= 11) {

      message.user.c6 += 1;///////////////

      return bot(`Вы выиграли улучшенного динозавра, но у вас есть праздничный питомец,и мы не хоти у вас его забирать,поэтому дарим вам еще 1 кейс`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

            "color": "positive"

          }],]

        })

      });

    }

    message.user.misc.pet = 8;

    message.user.pet.lvl = utils.random(10, 20)

    return bot(`Вы выиграли улучшенного динозавра`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 10) {

    message.user.balance += 100000000000000

    return bot(`Вы выиграли 100.000.000.000.000$`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 11) {

    let bon = utils.random(4000, 6000)

    message.user.opit += bon

    return bot(`Вы выиграли ${utils.sp(bon)} опыта`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 12) {

    let bon = utils.random(500000, 1000000)

    message.user.rating += bon

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 13) {

    let bon = utils.random(1000, 3000)

    message.user.opit += bon

    return bot(`Вы выиграли ${utils.sp(bon)} опыта`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 14) {

    let bon = utils.random(200000, 600000)

    message.user.rating += bon

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand == 15) {

    message.user.sertificats.car += 1;

    return bot(`Вы выиграли сертификат на лучшую машину`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 6" },

          "color": "positive"

        }],]

      })

    })

  }

});



cmd.hear(/^(?:кейс открыть 8)$/i, async (message, bot) => {
  if (message.user.c8 < 1) return bot(`У вас нет "Новогоднего кейса".`); // (советую настроить всю команду под себя)

  message.user.c8 -= 1;

  let rand = utils.random(8, 8);

  if (rand === 1) {
    let bon = utils.random(2000, 10000);

    message.user.balance2 += bon;

    return bot(`Вы выиграли ${utils.sp(bon)} GB`, {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",
                payload: { command: `Кейс открыть 8` },
                label: `📦 Открыть снова`,
              },

              color: "positive",
            },
          ],
        ],
      }),
    });
  }



  if (rand === 2) {
    if (message.user.transport.car === 21) {
      message.user.c8 += 1;

      return bot(`у вас уже есть лыжи, поэтому мы дарим вам еще 1 кейс`, {
        keyboard: JSON.stringify({
          inline: true,

          buttons: [
            [
              {
                action: {
                  type: "text",
                  payload: { command: `Кейс открыть 8` },
                  label: `📦 Открыть снова`,
                },

                color: "positive",
              },
            ],
          ],
        }),
      });
    }

    message.user.transport.car = 21;

    return bot(`Вы выиграли лыжи`, {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",
                payload: { command: `Кейс открыть 8` },
                label: `📦 Открыть снова`,
              },

              color: "positive",
            },
          ],
        ],
      }),
    });
  }

  if (rand === 3) {
    let bon = utils.random(100000, 200000);

    message.user.rating += bon;

    return bot(`Вы выиграли ${utils.sp(bon)} рейтинга`, {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",
                payload: { command: `Кейс открыть 8` },
                label: `📦 Открыть снова`,
              },

              color: "positive",
            },
          ],
        ],
      }),
    });
  }

  if (rand === 4) {
    message.user.balance += 50000000000000;

    return bot(`Вы выиграли 50.000.000.000.000$`, {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",
                payload: { command: `Кейс открыть 8` },
                label: `📦 Открыть снова`,
              },

              color: "positive",
            },
          ],
        ],
      }),
    });
  }

  if (rand === 5) {
    let bon = utils.random(100, 1000);

    message.user.opit += bon;

    return bot(`Вы выиграли ${utils.sp(bon)} опыта`, {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",
                payload: { command: `Кейс открыть 8` },
                label: `📦 Открыть снова`,
              },

              color: "positive",
            },
          ],
        ],
      }),
    });
  }

  if (rand === 6) {
    let bon = 100;

    message.user.gift += bon;

    return bot(`Вы выиграли ${utils.sp(bon)} подарков`, {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",
                payload: { command: `Кейс открыть 8` },
                label: `📦 Открыть снова`,
              },

              color: "positive",
            },
          ],
        ],
      }),
    });
  }

  if (rand === 7) {
    message.user.c3 += 2;

    return bot(`Вы выиграли 2 донат кейса`, {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",
                payload: { command: `Кейс открыть 8` },
                label: `📦 Открыть снова`,
              },

              color: "positive",
            },
          ],
        ],
      }),
    });
  }

  if (rand === 8) {
    if (message.user.misc.pet >= 16) {

      message.user.c8 += 1;

      return bot(`Вам выпал питомец Гринч,который у вас уже есть, вы получили еще 1 кейс`, {

        keyboard: JSON.stringify({

          "inline": true,

          "buttons": [[{

            "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 8" },

            "color": "positive"

          }],]

        })

      });

    }

    message.user.misc.pet = 16;

    message.user.pet.lvl = 1;

    return bot(`Вы выиграли питомца Гринч`, {

      keyboard: JSON.stringify({

        "inline": true,

        "buttons": [[{

          "action": { "type": "text", "payload": "{}", "label": "Кейс открыть 8" },

          "color": "positive"

        }],]

      })

    })

  }

  if (rand === 9) {
    message.user.c6 += 1;

    return bot(`Вы выиграли секретный кейс`, {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",
                payload: { command: `Кейс открыть 8` },
                label: `📦 Открыть снова`,
              },

              color: "positive",
            },
          ],
        ],
      }),
    });
  }

  //if (rand == 9) {

  //	message.user.prazdnikbussines=true;

  //	return bot(`Вы выиграли новогодний бизнес, он будет приносить вам по 50.000.000.000$ в минуту в автоматическом режиме`,{keyboard: JSON.stringify({"inline": true,"buttons": [[{"action": {"type": "text", "payload": "{}", "label": "Кейс открыть 8"}, "color": "positive"}],]})})

  //}
});

cmd.hear(/(?:кейс открыть 9|Открыть 🔥 Premium кейс)$/i, async (message, bot) => {

  if (message.user.c9 < 1) return bot(`У вас нет "🔥 Premium-кейса".`);

  if (message.user.questallfucker && !message.user.questpremcase) {

    message.user.questpremcase = true;

    await bot(`поздравляем, вы открыли премиум кейс и получили 50 трлн`);

    message.user.balance += 50000000000000;

  }

  let rand = utils.random(1, 100)

  message.user.c9 -= 1;
  if (message.user.otkr == undefined) {
    message.user.otkr = 0;
  }
  message.user.otkr += 1;

  if (rand <= 40) {

    let mon = utils.random(1, 100);

    mon = mon * 2000000000000;

    message.user.balance += mon;

    return bot(`🔥Вы открыли Premium-кейс и выиграли ${utils.sp(mon)}$`);

  }



  if (rand > 40 && rand <= 60) {

    let mon = utils.random(1, 100);

    mon = mon * 100;

    message.user.opit += mon;

    return bot(`🔥Вы открыли Premium-кейс и выиграли ${utils.sp(mon)} опыта📈`);

  }



  if (rand > 60 && rand <= 70) {

    let mon = utils.random(1, 100);

    mon = mon * 10000;

    message.user.rating += mon;

    return bot(`🔥Вы открыли Premium-кейс и выиграли ${utils.sp(mon)} рейтинга👑`);

  }



  if (rand > 70 && rand <= 75) {

    message.user.sertificats.premium += 1;

    return bot(`🔥Вы открыли Premium-кейс и выиграли сертификат на Premium VIP📋`);

  }



  if (rand > 75 && rand <= 80) {

    message.user.sertificats.business += 1;

    return bot(`🔥Вы открыли Premium-кейс и выиграли сертификат на Киностудию📋`);

  }



  if (rand > 80 && rand <= 85) {

    message.user.sertificats.car += 1;

    return bot(`🔥Вы открыли Premium-кейс и выиграли сертификат на лучшую машину📋`);

  }

  if (rand > 85 && rand <= 98) {

    let mon = utils.random(1, 100);

    mon = mon * 20000000;

    message.user.btc += mon;

    return bot(`🔥Вы открыли Premium-кейс и выиграли ${utils.sp(mon)} биткоинов💸`);

  }

  if (rand > 98 && rand <= 100) {



    vk.api.messages.send({

      user_id: 690927947, message: `▶️ УВЕДОМЛЕНИЕ:

♻️ Игрок @id${message.user.id} (${message.user.tag}) | vk.com/id${message.senderId} выиграл TITAN 🤗`, random_id: 0

    });

    message.user.settings.titan = true;

    message.user.limit.nicklimit = 48;

    message.user.level += 50;

    message.user.opit += 50000;

    message.user.limit.banklimit = 500000000000000;

    message.user.limit.farmlimit = 10000;

    message.user.limit.playerlimit = 300000000000000;

    message.user.limit.sent = 0;

    message.user.maxenergy = 100;

    return bot(`🔥Вы открыли Premium-кейс и выиграли TITAN VIP🔥`);



  }

});

cmd.hear(/(?:кейс открыть 11)$/i, async (message, bot) => {

  if (message.user.c11 < 1) return bot(`У вас нет "Админ-кейса".`);

  message.user.c11 -= 1;
  if (message.user.otkr == undefined) {
    message.user.otkr = 0;
  }
  message.user.otkr += 1;

  let rand = utils.random(1, 3000000000);

  mon = rand * 1000;

  message.user.limitadd.playerlimitadd += mon;

  return bot(`🔥Вы открыли Админ-кейс и выиграли +${utils.sp(mon)} $ к выдаче\n🏆Лимит обновиться через час!`);

});



cmd.hear(/(?:кейс открыть 10|Открыть 🔥 Ультра кейс)$/i, async (message, bot) => {

  if (message.user.c10 < 1) return bot(`У вас нет "🔥 Ультра-кейса".`);

  let rand = utils.random(1, 1000)

  message.user.c10 -= 1;
  if (message.user.otkr == undefined) {
    message.user.otkr = 0;
  }
  message.user.otkr += 1;

  if (rand <= 300) {

    let mon = utils.random(1, 30);

    mon = mon * 2000000000000;

    message.user.balance += mon;

    return bot(`🔥Вы открыли Ультра-кейс и выиграли ${utils.sp(mon)}$`);

  }



  if (rand > 300 && rand <= 500) {

    let mon = utils.random(1, 50);

    mon = mon * 100;

    message.user.opit += mon;

    return bot(`🔥Вы открыли Ультра-кейс и выиграли ${utils.sp(mon)} опыта📈`);

  }



  if (rand > 500 && rand <= 700) {

    let mon = utils.random(1, 65);

    mon = mon * 18347;

    message.user.rating += mon;

    return bot(`🔥Вы открыли Ультра-кейс и выиграли ${utils.sp(mon)} рейтинга👑`);

  }



  if (rand > 700 && rand <= 750) {

    let mon = utils.random(1, 20);

    message.user.rubli += Number(mon);

    return bot(`🔥Вы открыли Ультра-кейс и выиграли ${utils.sp(mon)} рублей на донат-счет`);

  }

  if (rand > 750 && rand <= 780) {

    message.user.sertificats.premium += 1;

    return bot(`🔥Вы открыли Ультра-кейс и выиграли сертификат на Premium VIP📋`);

  }



  if (rand > 780 && rand <= 820) {

    message.user.sertificats.business += 1;

    return bot(`🔥Вы открыли Ультра-кейс и выиграли сертификат на Киностудию📋`);

  }

  if (rand > 820 && rand <= 970) {

    let mon = utils.random(1, 100);

    mon = mon * 20000000;

    message.user.btc += mon;

    return bot(`🔥Вы открыли Ультра-кейс и выиграли ${utils.sp(mon)} биткоинов💸`);

  }

  if (rand > 970 && rand <= 990) {

    vk.api.messages.send({

      user_id: message.user.id,

      message: `УВЕДОМЛЕНИЕ ✅\n🔥Ссылка на Titan беседу: https://vk.me/join/Uiw63rwTEmFxS9JbZFtpDzv/5h9/4tIrhaQ= `,

      random_id: 0

    });

    vk.api.messages.send({

      user_id: 690927947, message: `[УВЕДОМЛЕНИЕ]

					Игрок: vk.com/id${message.senderId} выиграл титан`, random_id: 0

    });

    message.user.settings.titan = true;

    message.user.limit.nicklimit = 48;

    message.user.level += 50;

    message.user.opit += 50000;

    message.user.limit.banklimit = 500000000000000;

    message.user.limit.farmlimit = 10000;

    message.user.limit.playerlimit = 300000000000000;

    message.user.limit.sent = 0;

    message.user.maxenergy = 100;

    return bot(`🔥Вы открыли Ультра-кейс и выиграли TITAN VIP🔥`);

  }

  if (rand > 990 && rand <= 1000) {

    vk.api.messages.send({

      user_id: 690927947, message: `[УВЕДОМЛЕНИЕ]

					Игрок: vk.com/id${message.senderId} выиграл звезду`, random_id: 0

    });

    message.user.stars5 = true;

    return bot(`🔥вы открыли Ультра-кейс и выиграли Донатного гиганта 💰`);

  }

});



cmd.hear(/^(?:кейс 1)\s([0-9]+)$/i, async (message, bot) => {

  if (message.args[1] < 0) return;

  if (message.user.inf == true) return bot(`выключите безлимитный баланс`)

  message.args[1] = Number(message.args[1])

  let s = message.args[1] * 50000000000000

  s = Number(s)

  if (message.user.balance < s) return bot(`у вас недостаточно денег 😔 `)

  message.user.c1 += message.args[1]

  message.user.balance -= s

  return bot(`вы успешно купили «Обычный Кейс» (${utils.sp(message.args[1])} шт.) за ${utils.sp(s)}$ 💵💰`)

});





cmd.hear(/^(?:кейс 2)\s([0-9]+)$/i, async (message, bot) => {

  if (message.args[1] < 0) return;

  if (message.user.inf == true) return bot(`выключите безлимитный баланс`)

  message.args[1] = Number(message.args[1])

  let s = message.args[1] * 5000000000000000

  s = Number(s)

  if (message.user.balance < s) return bot(` у вас недостаточно денег 😔 `)

  message.user.c2 += message.args[1]

  message.user.balance -= s

  return bot(`вы успешно купили «Золотой Кейс» (${utils.sp(message.args[1])} шт.) за ${utils.sp(s)}$ 💵💰`)

});



cmd.hear(/^(?:кейс 3)\s([0-9]+)$/i, async (message, bot) => {

  if (message.args[1] < 0) return;

  if (message.user.inf == true) return bot(`выключите безлимитный баланс`)

  message.args[1] = Number(message.args[1])

  let s = message.args[1] * 150

  s = Number(s)

  if (message.user.rub < s) return bot(`у вас недостаточно денег 😔 `)

  message.user.c3 += message.args[1]

  message.user.rub -= s;

  return bot(`вы успешно купили «Донат Кейс» (${utils.sp(message.args[1])} шт.) за ${utils.sp(s)} ЧакоРуб 💵💰`)

});

cmd.hear(/^(?:кейс 4)$/i, async (message, bot) => {
  return bot(`Гоночный кейс невозможно приобрести. 💰`)
});
cmd.hear(/^(?:кейс 1|🗂 Обычный кейс)$/i, async (message, bot) => {

  if (message.user.balance < 50000000000) return bot(` у Вас недостаточно денег 😔 `)

  if (message.user.inf == true) return bot(`Выключите безлимитный баланс`)

  message.user.c1 += 1

  message.user.balance -= 50000000000

  return bot(`вы успешно купили «Обычный Кейс» (1 шт.) 📦💰`)

});



cmd.hear(/^(?:кейс 2|🗂 Зотолотой кейс)$/i, async (message, bot) => {
  if (message.user.balance < 5000000000000000) return bot(`у Вас недостаточно денег 😔`)
  if (message.user.inf == true) return bot(`Выключите безлимитный баланс`)
  message.user.c2 += 1
  message.user.balance -= 5000000000000000
  return bot(`вы успешно купили «Золотой Кейс» (1 шт.) 📦💰`)
});

cmd.hear(/^(?:кейс 3|🗂 Донат кейс)$/i, async (message, bot) => {

  if (message.user.rub < 250) return bot(` у Вас недостаточно денег 😔 `)

  message.user.c3 += 1

  message.user.rub -= 250

  return bot(`вы успешно купили «Донат Кейс» (1 шт.) 📦💰`)

});



cmd.hear(/^(?:Посылки|📦 Список посылок|@chakobot 📦Посылки|📦 Посылка)$/i, async (message, bot) => {

  if (typeof message.user.possilka1 != "number") message.user.possilka1 = 0;

  if (typeof message.user.possilka2 != "number") message.user.possilka2 = 0;

  if (typeof message.user.possilka3 != "number") message.user.possilka3 = 0;

  let text = `Ваши посылки:`;

  if (message.user.possilka1 > 0) {

    text += `💵 1. Денежная посылка: (${utils.sp(message.user.possilka1)} шт.)`;

  }

  if (message.user.possilka2 > 0) {

    text += `📩 2. Элитная посылка: (${utils.sp(message.user.possilka2)} шт.)`;

  }

  if (message.user.possilka3 > 0) {

    text += `🔮 3. Премиум посылка: (${utils.sp(message.user.possilka3)} шт.)`;

  }



  return bot(`Посылки:

📦 1. Денежная посылка — 250 ЧакоРуб [15 rub]
➖ Падает: от 1.000.000.000.000 до 200.000.000.000.000 вирт💵
➖➖➖➖➖➖
📦 2. Элитная посылка - 1000 ЧакоРуб [50 rub]
➖ Падает: от 1.000.000.000.000 до 500.000.000.000.000 вирт💵
➖ Падает: от 10.000 рейтинга до 1.000.000 рейтинга👑
🛑 Выпадает два предмета вместе!
➖➖➖➖➖➖
📦 3. Премиум посылка - 5000 ЧакоРуб [100 rub]
➖ Падает: от 1.000.000.000.000 до 750.000.000.000.000 вирт💵
➖ Падает: от 6.000 до 10.000 GB 👑
➖ Падает: от 500 ЧакоРуб до 10.000 ЧакоРуб⁉️
🛑 Выпадает три предмета вместе!
➖➖➖➖➖➖
📂 Открыть: Посылка открыть [номер]
🛒 Покупка за ЧакоРуб: ЧакоРуб [17/18/19]
🔹 Покупка за донат-рубли: «Донат»

${text}`);
});



cmd.hear(/^(?:Посылка открыть 1)$/i, async (message, bot) => {

  if (message.user.possilka1 < 1) return bot(`🛑У вас нет данной посылки.`);

  message.user.possilka1 -= 1;

  let t = utils.random(1, 200);

  message.user.balance += t * 1000000000000;

  return bot(`Денежная посылка была успешно открыта!\n\n✅ ➖ Вам выпало: ${utils.sp(t * 1000000000000)} $`);



});

cmd.hear(/^(?:Посылка открыть 2)$/i, async (message, bot) => {

  if (message.user.possilka2 < 1) return bot(`🛑У вас нет данной посылки.`)

  message.user.possilka2 -= 1;

  let t = utils.random(1, 400);

  let t1 = utils.random(1, 80);

  message.user.balance += t * 1000000000000;

  message.user.rating += t1 * 10000;

  return bot(`Элитная посылка была успешно открыта!\n\n✅ ➖ Вам выпало:\n💰 Деньги: ${utils.sp(t * 1000000000000)} $\n👑 Рейтинг: ${utils.sp(t1 * 10000)}`);



});

cmd.hear(/^(?:Посылка открыть 3)$/i, async (message, bot) => {

  if (message.user.possilka3 < 1) return bot(`🛑У вас нет данной посылки.`)

  message.user.possilka3 -= 1;

  let t = utils.random(1, 500);

  let t1 = utils.random(3000, 5000);

  let t2 = utils.random(1, 10);

  message.user.balance += t * 1000000000000;

  message.user.balance2 += t1 * 2;

  message.user.rub += t2 * 500;

  return bot(`Элитная посылка была успешно открыта!\n\n✅ ➖ Вам выпало:\n💰 Деньги: ${utils.sp(t * 1000000000000)} $\n👑 GB: ${utils.sp(t1 * 2)}\n⁉️ Чакоруб: ${utils.sp(t2 * 500)}`);

});



module.exports = commands;
