let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

function addZero(i) {
  return i < 10 ? "0" + i : i;
}

function unixStampLefta(stampa) {
  stampa = stampa / 1000;
  let s = stampa % 60;
  stampa = (stampa - s) / 60;
  let m = stampa % 60;
  let text = ``;
  if (m > 0) text += addZero(Math.floor(m)) + " мин. ";
  if (s > 0) text += addZero(Math.floor(s)) + " сек.";
  return text;
}

cmd.hear(/^через\s(\d+)\s(минуту|минут|мин|минуты|час|часа|часов)\s(.*)$/i, async (message, bot) => {
  // Инициализируем необходимые свойства, если их нет
  if (!message.user.notif) {
    message.user.notif = {};
  }

  if (!message.user.time) {
    message.user.time = {};
  }

  const timeValue = parseInt(message.args[1], 10);
  const timeUnit = message.args[2].toLowerCase();
  const reminderText = message.args.slice(3).join(' ');

  if (isNaN(timeValue) || timeValue <= 0) return;

  let timeMilliseconds;

  // Определяем, сколько миллисекунд нужно для времени
  if (timeUnit.includes('час')) {
    timeMilliseconds = timeValue * 3600000; // 60 минут * 60 секунд * 1000 миллисекунд
  } else if (timeUnit.includes('мин')) {
    timeMilliseconds = timeValue * 60000; // 60 секунд * 1000 миллисекунд
  } else {
    return; // Неизвестная единица времени
  }

  message.user.notif.one = true;
  message.user.time.one = Date.now() + timeMilliseconds;

  const sendReminder = () => {
    message.user.notif.one = false;

    const reminderMessage = `@id${message.user.id} (${message.user.tag}), часики тик-так! 🕒\n\n✅ Напоминаю о том, что вы хотели:\n_${reminderText}_`;

    if (message.isChat) {
      vk.api.messages.send({
        chat_id: message.chatId,
        random_id: 0,
        message: reminderMessage,
        keyboard: JSON.stringify({
          inline: true,
          buttons: [
            [
              {
                action: {
                  type: "text",
                  payload: "{}",
                  label: "🕒 Напоминания",
                },
                color: "default",
              },
            ],
          ],
        }),
      });
    } else {
      vk.api.messages.send({
        user_id: message.user.id,
        random_id: 0,
        message: reminderMessage,
        keyboard: JSON.stringify({
          inline: true,
          buttons: [
            [
              {
                action: {
                  type: "text",
                  payload: "{}",
                  label: "🕒 Напоминания",
                },
                color: "default",
              },
            ],
          ],
        }),
      });
    }
  };

  setTimeout(sendReminder, timeMilliseconds);

  bot(`Поставил напоминание! Оно произойдёт через ${timeValue} ${timeUnit} 🕒`, {
    keyboard: JSON.stringify({
      inline: true,
      buttons: [
        [
          {
            action: {
              type: "text",
              payload: "{}",
              label: `🕒 Напоминания`,
            },
            color: "default",
          },
        ],
      ],
    }),
  });
});

function scl(number, titles) {
  cases = [2, 0, 1, 1, 1, 2];

  return titles[
    number % 100 > 4 && number % 100 < 20
      ? 2
      : cases[number % 10 < 5 ? number % 10 : 5]
  ];
}

function timer(seconds) {
  if (seconds === "") return "0 секунд";

  let days = parseInt(seconds / 86400);

  seconds = seconds % 86400;

  let hours = parseInt(seconds / 3600);

  seconds = seconds % 3600;

  let minutes = parseInt(seconds / 60);

  seconds = seconds % 60;

  days = days === 0 ? "" : days + " " + scl(days, ["день", "дня", "дней"]);

  hours = hours === 0 ? "" : hours + " " + scl(hours, ["час", "часа", "часов"]);

  minutes =
    minutes === 0
      ? ""
      : minutes + " " + scl(minutes, ["минуту", "минуты", "минут"]);

  seconds =
    seconds === 0
      ? ""
      : seconds + " " + scl(seconds, ["секунду", "секунды", "секунд"]);

  //var gone = days + " " +hours + " " + minutes + " " + seconds

  return `${days} ${hours} ${minutes} ${seconds}`;
}


cmd.hear(
  /^(?:🕒 Напоминания|⏰ Напоминания|напоминания|напоминание)$/i,
  async (message, bot) => {

    if (!message.user.notif) {
      message.user.notif = { one: false, two: false, three: false };
    }
    if (!message.user.reminder) {
      message.user.reminder = { one: '', two: '', three: '' };
    }

    let text = ``;

    if (message.user.notif.one) {
      text += `\n1️⃣ Напоминание: произойдёт через ${unixStampLefta(
      message.user.time.one - Date.now()
    )}`;
    }

    if (message.user.notif.two) {
      text += `\n2️⃣ Напоминание: произойдёт через ${unixStampLefta(
      message.user.time.two - Date.now()
    )}`;
    }

    if (message.user.notif.three) {
      text += `\n3️⃣ Напоминание: произойдёт через ${unixStampLefta(
      message.user.time.three - Date.now()
    )}`;
    }

    if (text === '') {
      text = `У вас нет активных напоминаний.`;
    }

    return bot(`Ваши напоминания:${text}`);
  
  }
)

module.exports = commands;
