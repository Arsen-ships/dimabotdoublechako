let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
    try {
        const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
        return tokens; // Возвращаем все данные из файла
    } catch (error) {
        console.error('Ошибка при чтении токенов:', error);
        return null; // Возвращаем null в случае ошибки
    }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
    const tokens = {
        token: token,
        spoler: spoler,
        chatlogi: chatlogi
    };

    try {
        fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
        console.log('Токены успешно сохранены.');
    } catch (error) {
        console.error('Ошибка при сохранении токенов:', error);
    }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });





cmd.hear(/^(?:Дабл создать)$/i, async (message, bot) => {
    if (message.chat.type == 1) return
    if (message.user.balance2 < 0) return bot('Недостаточно средств! Нужно 1ОО.ООО GB.')
    message.user.balance2 -= 0
    message.chat.type = 1


    message.send('Обновляю...',
        {
            keyboard: JSON.stringify(
                {
                    "one_time": false, "buttons": [
                        [
                            { "action": { "type": "text", "payload": "{}", "label": "Банк" }, "color": "positive" },
                            { "action": { "type": "text", "payload": "{}", "label": "Баланс" }, "color": "positive" }
                        ],
                        [
                            { "action": { "type": "text", "payload": "{}", "label": "x2" }, "color": "primary" },
                            { "action": { "type": "text", "payload": "{}", "label": "x3" }, "color": "primary" },
                            { "action": { "type": "text", "payload": "{}", "label": "x5" }, "color": "primary" }
                        ],
                        [
                            { "action": { "type": "text", "payload": "{}", "label": "x50" }, "color": "positive" }
                        ],
                        [
                            { "action": { "type": "text", "payload": "{}", "label": "Рейтинг" }, "color": "negative" },
                            { "action": { "type": "text", "payload": "{}", "label": "Донат" }, "color": "default" },
                            { "action": { "type": "text", "payload": "{}", "label": "Бонус" }, "color": "default" }
                        ]
                    ]
                })
        })

    return bot(`⚡ Чат был переведён в режим дабла! 🚀`)

})

cmd.hear(/^(?:Дабл стандарт)$/i, async (message, bot) => {

    message.chat.type = 0


    return bot(`⚡ Чат был переведён в режим стандарт! 🚀`)

})



module.exports = commands;
