let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
    try {
        const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
        return tokens; // Возвращаем все данные из файла
    } catch (error) {
        console.error('Ошибка при чтении токенов:', error);
        return null; // Возвращаем null в случае ошибки
    }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
    const tokens = {
        token: token,
        spoler: spoler,
        chatlogi: chatlogi
    };

    try {
        fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
        // console.log('Токены успешно сохранены.');
    } catch (error) {
        console.error('Ошибка при сохранении токенов:', error);
    }
}


const tokenData = getToken();

const chatlogi = tokenData.chatlogi; 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:баланс|💰 Баланс|бал|money|my balance)$/i, async (message, bot) => {
    if (message.chat.type == 1) {
        let text = ``;

        text += `ваш баланс: ${utils.sp(message.user.balance2)} GB 💸 \n`;

        await bot(`${text}`)
    }
    
    if (message.chat.type == 0) {
        let text = `баланс:\n\n`;

        if (message.user.balance2 > 0) {
            text += `💸 ${utils.sp(message.user.balance2)} GB\n`;
        } else {

        }

        if (message.user.inf) {
            text += `💵 Наличными: ∞\n`;
        } else {
            text += `💵 Наличными: ${utils.sp(message.user.balance)} $\n`;
        }

        if (message.user.btc > 0) {
            text += `💽 Биткоинов: ${utils.sp(message.user.btc)} ฿\n`;
        } else {

        }
        message.send({ sticker_id: 110670 });
        await bot(text, {
            keyboard: JSON.stringify({
                "inline": true,
                "buttons": [
                    [{
                        "action": {
                            "type": "text",
                            "payload": "{}",
                            "label": `💎 ресурсы`
                        },
                        "color": "default"
                    }]
                ]
            })
        });
    }
});

cmd.hear(/^(?:ресурсы|💎 ресурсы)$/i, async (message, bot) => {
    if (message.chat.type == 0) {
        let text = `ресурсы:`;
        let hasResources = false; 

        if (message.user.ruds.zhelezo) {
            text += `\n🎛 ${message.user.ruds.zhelezo} железа`;
            hasResources = true;
        }

        if (message.user.ruds.zoloto) {
            text += `\n🏵 ${message.user.ruds.zoloto} золота`;
            hasResources = true;
        }

        if (message.user.ruds.almaz) {
            text += `\n💎 ${message.user.ruds.almaz} алмаза`;
            hasResources = true;
        }

        if (message.user.ruds.materia) {
            text += `\n🌌 ${message.user.ruds.materia} материи`;
            hasResources = true;
        }

        if (message.user.ruds.obsidian) {
            text += `\n🌌 ${message.user.ruds.obsidian} обсидиана`;
            hasResources = true;
        }

        if (message.user.ruds.plazma) {
            text += `\n🌌 ${message.user.ruds.plazma} плазмы`;
            hasResources = true;
        }

        if (hasResources) {
            message.send({ sticker_id: 52995 });
            await bot(text);
        } else {
            message.send({ sticker_id: 52980 });
            let noResourcesText = `У вас нет никаких ресурсов ❌\n💪 Добыть их можно в шахте!`;
            await bot(noResourcesText, {
                keyboard: JSON.stringify({
                    "inline": true,
                    "buttons": [
                        [{
                            "action": {
                                "type": "text",
                                "payload": "{}",
                                "label": `⛏ Шахта`
                            },
                            "color": "default"
                        }]
                    ]
                })
            });
        }
    }
});
        

module.exports = commands;
