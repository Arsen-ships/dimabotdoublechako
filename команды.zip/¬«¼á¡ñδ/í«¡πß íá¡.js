let utils = require('../utils.js')

const commands =[];

const fs = require('fs'); 

let double = require('../database/users.json')

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:бонус бан)\s?([0-9]+)?/i, async (message, bot) => {
    if (message.chat.type === 0) return;

  if (message.user.settings.adm < 5) return;

    let userId = Number(message.args[1]);
   
    
    let user = double.find(x => x.uid === userId);

    if (!user) {
        return bot(`пользователь с ID ${userId} не найден.`);
    }

    // Запретить бонус
    user.bans.bonus = true;
    
    return bot(`бонус для пользователя ${user.tag} был отключен. 🚫`);
});

module.exports = commands;