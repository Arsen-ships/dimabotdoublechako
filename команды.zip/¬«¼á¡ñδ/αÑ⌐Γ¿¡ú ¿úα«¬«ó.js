let utils = require('../utils.js')

const commands =[]

let double = require('../database/users.json')

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const videoAttachments = [
'video690927947_456240011?list=6d4a83698f565d17e5',
'video690927947_456239989?list=a16345569246e3d332',
'video690927947_456240012?list=8f74cd041a765d808d',
'video690927947_456240013?list=5a3a652d6f1f0e9c9d',
'video690927947_456240014?list=0218be78348863b23c',
'video690927947_456240015?list=600c4a18e4e9dedeb0',
'video690927947_456240016?list=a47f5ff92702e25abd',
'video690927947_456240018?list=881e5e0c9aa281346d',
'video690927947_456240019?list=f4272a13091bd88bd4',
'video690927947_456240020?list=723bcdd91b2097c98d',
'video690927947_456240026?list=785db8d65fed567dba',
'video690927947_456240028?list=9d1dcafce5b29e8231',
'video690927947_456240051?list=290700245f9ee86b74',
'video690927947_456240048?list=ba3f1fb560349b8565',
'video690927947_456240090?list=27a3560e1387575bbb',
'video690927947_456240108?list=930f9a7104a2947963',
'video690927947_456240110?list=bfe8097af4cd42c878',
'video690927947_456240111?list=f9462616bfc657971c',
'video690927947_456240112?list=5c4ab7481917ef969c',
'video690927947_456240113?list=c3221b337d45aeff35',
'video690927947_456240114?list=b6d05b2968aa333093',
'video690927947_456240115?list=374e88e28a53459edb',
'video690927947_456240116?list=d30441abc7503036f3',
'video690927947_456240117?list=b01a452de616e0e28a',
'video690927947_456240118?list=e74de82ab7b95282c4',
'video690927947_456240142?list=39cc42461b4468d51b',
'video690927947_456240145?list=4f16080aacfb5a01f7',
'video690927947_456240137?list=d5a59661c06fc50d28',
'video690927947_456240146?list=f67398fd6ba392d027',
'video690927947_456240151?list=eaf9f4960ddf15fcf4',
'video690927947_456240153?list=b61dc807fda7664d8c',
'video690927947_456240154?list=3e21c8b9e83b8a954b',
'video690927947_456240176?list=2343f995758137e407',
'video690927947_456240167?list=164c6d369a12e14f1f'

];


const getRandomVideo = () => {
    const randomIndex = Math.floor(Math.random() * videoAttachments.length);
    const selectedVideo = videoAttachments[randomIndex];
    return videoAttachments[randomIndex];
};


cmd.hear(/^(?:рейтинг|топ|👥 Топ игроков|Топ SpringCoin)$/i, async (message, bot) => {


    if (message.chat.type === 1) {
        if (double.length < 10) return bot(`меньше 10 игроков.`, {
            attachment: getRandomVideo()
        })
        let top = [];

        double.map(x => {
            if (!x.bantop) top.push({ balance: x.balance2, tag: x.tag, id: x.id });
        });
    
        for (let b in double) {
            for (let a in top) {
                if (double[b].settings.adm > 0) {
                    if (top[a].id == double[b].id) {
                        top[a].balance2 = -99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999
                    }
                }
            }
        }

        top.sort((a, b) => {
            return b.balance2 - a.balance2;
        });

        let text = ``;
        const find = () => {
            let pos = 1000;

            for (let i = 0; i < top.length; i++) {
                if (top[i].id === message.senderId) return pos = i;
            }

            return pos;
        }

        for (let i = 0; i < 10; i++) {
            if (!top[i]) return
            const user = top[i]

            text += `${i === 9 ? `&#128287;` : `${i + 1}&#8419;`} ${user.mention ? `@id${user.id} (${user.tag})` : `@id${user.id} (${user.tag})`} -- ${utils.sp(user.balance2)} GB
`;
        }


        let myposition = ''

        if ((find() + 1) > 10) myposition = `———————————————
${utils.gi(find() + 1)} [id${message.user.id}|${message.user.tag}] — ${utils.sp(message.user.balance2)} GB \n\n`
        return bot(`топ игроков по балансу:\n\n${text} ${myposition}`, {
            attachment: getRandomVideo()
        });
    }
    
        if (message.chat.type === 0) {
            let top = [];

            double
                .filter((x) => x.bantop === false)
                .map((x) => {
                    top.push({
                        sprcoin: x.sprcoin,
                        tag: x.tag,
                        id: x.id,
                        mention: x.mention,
                    });
                });

            top.sort((a, b) => {
                return b.sprcoin - a.sprcoin;
            });

            let text = ``;

            const find = () => {
                let pos = 1000;

                for (let i = 0; i < top.length; i++) {
                    if (top[i].id === message.senderId) return (pos = i);
                }

                return pos;
            };

            for (let i = 0; i < 10; i++) {
                if (!top[i])
                    return bot("в боте должно быть зарегистрировано минимум 10 игроков! 👥");

                const user = top[i];

                text += `\n${i === 9 ? `🔟` : `${i + 1}⃣`} ${user.mention ? `@id${user.id} (${user.tag})` : `${user.tag}`
                    } — ☣${utils.sp(user.sprcoin)}`;
            }

            return bot(
                `топ игроков по SpringCoin ☣️${text}
		➖➖➖➖➖➖➖➖
	${utils.gi(find() + 1)} ${message.user.tag} — ☣${utils.sp(
                    message.user.sprcoin
                )}`,

                {
                    keyboard: JSON.stringify({
                        inline: true,

                        buttons: [
                            [
                                {
                                    action: {
                                        type: "text",

                                        payload: "{}",

                                        label: "🔅 Топ реферал",
                                    },

                                    color: "default",
                                },
                            ],

                            [
                                {
                                    action: {
                                        type: "text",

                                        payload: "{}",

                                        label: "😈 Босс топ",
                                    },

                                    color: "default",
                                },

                                {
                                    action: {
                                        type: "text",

                                        payload: "{}",

                                        label: "🏆 Топ рейтинг",
                                    },

                                    color: "default",
                                },
                            ],

                            [
                                {
                                    action: {
                                        type: "text",

                                        payload: "{}",

                                        label: "👥 Топ игроков",
                                    },

                                    color: "default",
                                },

                                {
                                    action: {
                                        type: "text",

                                        payload: "{}",

                                        label: "🌐 Топ биткоины",
                                    },

                                    color: "default",
                                },
                            ],

                            [
                                {
                                    action: {
                                        type: "text",

                                        payload: "{}",

                                        label: "〽️ Топ опыт",
                                    },

                                    color: "default",
                                },

                                {
                                    action: {
                                        type: "text",

                                        payload: "{}",

                                        label: "🏎️ Топ гонщиков",
                                    },

                                    color: "default",
                                },
                            ],

                            [
                                {
                                    action: {
                                        type: "text",

                                        payload: "{}",

                                        label: "💰 Топ баланс",
                                    },

                                    color: "default",
                                },
                            ],

                            [
                                {
                                    action: {
                                        type: "text",

                                        payload: "{}",

                                        label: "💌 Топ сообщения",
                                    },

                                    color: "default",
                                },
                            ],
                        ],
                    }),
                }
            );
        }
    }
);




module.exports = commands;
