let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:фортуна|🎡 Фортуна)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    return bot(
      `выберите определённый номер фортуны:

1️⃣ Денежная фортуна
2️⃣ Донатная фортуна
3️⃣ Билетная фортуна

♻️ Чтобы перейти к определённой фортуне, напишите «фортуна [номер]» или нажмите кнопку ниже.`,

      {
        keyboard: JSON.stringify({
          inline: true,

          buttons: [
            [
              {
                action: {
                  type: "text",

                  payload: "{}",

                  label: "🎡💵 Денежная фортуна",
                },

                color: "default",
              },
            ],

            [
              {
                action: {
                  type: "text",

                  payload: "{}",

                  label: "🎡🔥 Донатная фортуна",
                },

                color: "default",
              },
            ],

            [
              {
                action: {
                  type: "text",

                  payload: "{}",

                  label: "🎡🎫 Билетная фортуна",
                },

                color: "default",
              },
            ],
          ],
        }),
      }
    );
  }
});

cmd.hear(/^(?:🎡💵 Денежная фортуна|денежная фортуна)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    return bot(`В разработке 🙃`);
  }
});

cmd.hear(/^(?:🎡🔥 Донатная фортуна|донатная фортуна)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    return bot(`В разработке 🙃`);
  }
});

cmd.hear(
  /^(?:🎡🎫 Билетная фортуна|бил фортуна|билетная фортуна)$/i,
  async (message, bot) => {
    if (message.chat.type === 0) {
      return bot(
        `Информация о «Билетной фортуне»: ❄️

♻️ ➖ Призы:
1️⃣ Элитные посылки
2️⃣ Сертификат на бизнес «Киностудия по всему миру»
3⃣ Донат кейсы
4⃣ Сертификат на госномер
5⃣ Сертификат на Ламборгини
6⃣ VIP Статус

🔹 Стоимость прокрута: 10 билетов 🎫

▶️ Прокрутить фортуну: «Фортуна 1 крутить»`,
        { attachment: `photo-211261524_457239021` }
      );
    }
  }
);

cmd.hear(/^(?:фортуна 1 крутить)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    let prize = utils.random(1, 6);

    if (message.user.bilet < 10)
      return bot(`недостаточно билетов для прокрута Билетной Фортуны! 🎡❌`);

    let randsmile = utils.pick(["😸", "🙃", "😃", "😁"]);

    if (prize === 1) {
      let randpos = utils.random(1, 3);

      message.user.bilet -= 10;

      message.user.possilka2 += randpos;

      return message.send(
        `🎡 @id${message.user.id} (${message.user.tag}), вам выпало элитная(-ые) посылку(-и) (Х${randpos}) 📦! ${randsmile}`,
        { attachment: `photo-211261524_457239022` }
      );
    }

    if (prize === 2) {
      message.user.bilet -= 10;

      message.user.sertificats.business += 1;

      return message.send(
        `🎡 @id${message.user.id} (${message.user.tag}), вам выпал сертификат на бизнес «🎥 Киностудия по всему миру»! ${randsmile}`,
        { attachment: `photo-211261524_457239023` }
      );
    }

    if (prize === 3) {
      let valuta = utils.random(1, 2);

      message.user.bilet -= 10;

      message.user.c3 += valuta;

      return message.send(
        `🎡 @id${message.user.id} (${message.user.tag}), вам выпало донат-кейс(-ы, -ов) (Х${valuta}) 📦! ${randsmile}`,
        { attachment: `photo-211261524_457239027` }
      );
    }

    if (prize === 4) {
      message.user.bilet -= 10;

      message.user.sertificats.gosnomer += 1;

      return message.send(
        `🎡 @id${message.user.id} (${message.user.tag}), вам выпал сертификат на гос. номер 🎫! ${randsmile}`,
        { attachment: `photo-211261524_457239024` }
      );
    }

    if (prize === 5) {
      message.user.bilet -= 10;

      message.user.sertificats.car += 1;

      return message.send(
        `🎡 @id${message.user.id} (${message.user.tag}), вам выпал сертификат на машину «Ламборгини» 🚗! ${randsmile}`,
        { attachment: `photo-211261524_457239025` }
      );
    }

    if (prize === 6) {
      message.user.bilet -= 10;

      if (message.user.settings.vip !== false) {
        message.user.bilet += 10;

        return message.send(
          `🎡 @id${message.user.id} (${message.user.tag}), вам выпал «VIP» статус! 😲\n▶️ Вы уже имеете статус «VIP», выдана компенсация в виде возврата 10-ти билетов 🎫 {randsmile}`,
          { attachment: `photo-211261524_457239026` }
        );
      }

      if (
        message.user.settings.premium !== false ||
        message.user.settings.titan !== false
      ) {
        message.user.settings.vip = true;

        return bot("Вы выиграли VIP статус!💡");
      }

      message.user.settings.vip = true;

      message.user.stock.status = "VIP";

      message.user.limit.nicklimit = 21;

      message.user.level += 5;

      message.user.limit.banklimit = 100000000000000;

      message.user.limit.farmlimit = 3000;

      message.user.limit.videocardlimit = 50;

      message.user.limit.playerlimit = 100000000000000;

      message.user.limit.sent = 0;

      message.user.maxenergy = 20;

      return message.send(
        `🎡 @id${message.user.id} (${message.user.tag}), вам выпал «VIP» Статус! 😲\n🔥 Для ознакомления с командами введите «VIP help» ${randsmile}`,
        { attachment: `photo-211261524_457239026` }
      );
    }
  }
});
cmd.hear(/^(?:Сертификаты)$/i, async (message) => {
  if (message.chat.type === 0) {
    let text = ``;
    text +=
      `1&#8419; Сертификат на ГОСНОМЕР: ` +
      (message.user.sertificats.gosnomer === 0
        ? `[Нет]`
        : `[${message.user.sertificats.gosnomer}]`) +
      `\n`;

    text +=
      `2&#8419; Сертификат на ЛАМБОРГИНИ: ` +
      (message.user.sertificats.car === 0
        ? `[Нет]`
        : `[${message.user.sertificats.car}]`) +
      `\n`;

    text +=
      `3&#8419; Сертификат на РЕЙТИНГ: ` +
      (message.user.sertificats.rating === 0
        ? `[Нет]`
        : `[${message.user.sertificats.rating}]`) +
      `\n`;

    text +=
      `4&#8419; Сертификат на PREMIUM Статус: ` +
      (message.user.sertificats.premium === 0
        ? `[Нет]`
        : `[${message.user.sertificats.premium}]`) +
      `\n`;

    text +=
      `5&#8419; Сертификат на СЕКРЕТНЫЙ БИЗНЕС: ` +
      (message.user.sertificats.business === 0
        ? `[Нет]`
        : `[${message.user.sertificats.business}]`) +
      `\n`;

    text +=
      `6&#8419; Сертификат на VIP Статус: ` +
      (message.user.sertificats.vip === 0
        ? `[Нет]`
        : `[${message.user.sertificats.vip}]`) +
      `\n`;

    text +=
      `7&#8419; Сертификат на ОПЫТ: ` +
      (message.user.sertificats.opit === 0
        ? `[Нет]`
        : `[${message.user.sertificats.opit}]`) +
      `\n`;
    text += `❓ Для активации введите «Сертификат [номер]»\n\n`;
    text += `▶️ Есть возможность продать сертификаты.\n♻️ Подробнее: «Сертификаты инфо»\n`;

    text += ``;

    return message.send(`📋 Ваши сертификаты:\n\n${text}`);
  }
});

cmd.hear(/^(?:Сертификаты инфо)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    return bot(`информация о продаже сертификатов ❄️

1&#8419; Сертификат на ГОСНОМЕР - 15 билетов 🎡🎫
2&#8419; Сертификат на ЛАМБОРГИНИ - 2 денежные посылки 💵📦
3&#8419; Сертификат на СЕКРЕТНЫЙ БИЗНЕС - 1.000 ЧакоРуб 💰
4&#8419; Сертификат на PREMIUM Статус - 250 SpringCoins ☣️
5&#8419; Сертификат на VIP Статус - 100 SpringCoins ☣️

❓ Для продажи введите «Сертификат продать [номер]» ☃️`);
  }

});

cmd.hear(/^(?:Сертификат продать)\s?([12345])$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.args[1] === "1") {
      if (message.user.sertificats.gosnomer < 1)
        return bot("у вас отсуствует данный сертификат.");

      message.user.sertificats.gosnomer -= 1;

      message.user.bilet += 15;

      return bot(`Сертификат на госномер успешно продан!\n🎡 +15 билетов 🎫`);
    }

    if (message.args[1] === "2") {
      if (message.user.sertificats.car < 1)
        return bot("у вас отсуствует данный сертификат.");

      message.user.sertificats.car -= 1;

      message.user.possilka1 += 2;

      return bot(
        `Сертификат на ламборгини успешно продан!\n📦 +2 денежные посылки 💵`
      );
    }

    if (message.args[1] === "3") {
      if (message.user.sertificats.business < 1)
        return bot("у вас отсуствует данный сертификат.");

      message.user.sertificats.business -= 1;

      message.user.rub += 1000;

      return bot(
        `Сертификат на бизнес «Киностудия по всему миру» успешно продан!\n+1000 ЧакоРуб 💰`
      );
    }

    if (message.args[1] === "4") {
      if (message.user.sertificats.premium < 1)
        return bot("у вас отсуствует данный сертификат.");

      message.user.sertificats.premium -= 1;

      message.user.sprcoin += 250;

      return bot(
        `Сертификат на «PREMIUM» статус успешно продан!\n+250 SpringCoins ☣️`
      );
    }

    if (message.args[1] === "5") {
      if (message.user.sertificats.vip < 1)
        return bot("у вас отсуствует данный сертификат.");

      message.user.sertificats.vip -= 1;

      message.user.sprcoin += 100;

      return bot(
        `Сертификат на «VIP» статус успешно продан!\n+100 SpringCoins ☣️`
      );
    }
  }
});

cmd.hear(/^(?:6⃣ VIP Статус|Сертификат 6)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.sertificats.vip < 1)
      return bot("у вас отсуствует данный сертификат.");

    if (message.user.settings.vip !== false)
      return bot(`Вы уже являетесь «VIP» игроком! 👑`);

    if (message.user.settings.premium || message.user.settings.titan) {
      message.user.settings.vip = true;

      message.user.sertificats.vip -= 1;

      return message.send(
        `☃️ @id${message.user.id} (${message.user.tag}), сертификат активирован!\n\nПросмотреть список команд для VIP'а: «VIP help»`
      );
    }

    const date = new Date();

    message.user.sertificats.vip -= 1;

    message.user.settings.vip = true;

    message.user.stock.status = "VIP";

    message.user.limit.nicklimit = 21;

    message.user.level += 5;

    message.user.limit.banklimit = 100000000000000;

    message.user.limit.farmlimit = 3000;

    message.user.limit.videocardlimit = 50;

    message.user.limit.playerlimit = 100000000000000;

    message.user.limit.sent = 0;

    message.user.maxenergy = 20;

    return message.send(`☃️ @id${message.user.id} (${message.user.tag
      }), сертификат успешно активирован! ❄️



▶️ Выигрыш: VIP статус

♻️ Просмотреть список команд для VIP игрока: «VIP help»

⏰ Дата активации: ${date.getDate()}.${date.getMonth() + 1
      }.${date.getFullYear()}`);
  }
});

cmd.hear(
  /^(?:госномер)\s([а-я])([0-9])([0-9])([0-9])([а-я])([а-я])$/i,
  async (message, bot) => {
    if (message.chat.type === 0) {
      if (!message.user.transport.car) return bot(`у вас нет машины`);

      if (message.user.settings.adm > 0)
        return bot(
          `Администрации бота запрещено использовать данный сертификат!`
        );

      let res = `${message.args[1]}${message.args[2]}${message.args[3]}${message.args[4]}${message.args[5]}${message.args[6]} 777`;

      let text = res.toLowerCase();

      if (res === "А777АХ") return;

      const b =
        /(й|ц|г|ш|щ|з|ъ|ф|ы|п|л|д|ж|э|я|ч|и|ь|б|ю|q|w|e|r|t|y|u|i|o|p|a|s|d|f|g|h|j|k|l|z|x|c|v|b|n|m:)/;

      if (b.test(text) === true)
        return bot(`некорректный номер!



✅Напишите номер по шаблону, например: «A123BC», используя только русские буквы.



➕ Примеры: А777АА, А123МР, Р777РР и др.

🔤 Список разрешенных букв: А, В, Е, К, М, Н, О, Р, С, Т, У, Х`);

      if (message.user.sertificats.gosnomer < 1)
        return bot("у вас отсуствует данный сертификат.");

      const date = new Date();

      let user = double.find((x) => x.scar.gosnomer === res);

      if (user)
        return bot(`номер «${res}» уже занят игроком @id${user.id} (${user.tag}) ❌



▶️ Укажите другой номер.`);

      message.user.scar.gosnomer = res;

      message.user.sertificats.gosnomer -= 1;

      return message.send(`☃️ @id${message.user.id} (${message.user.tag
        }), сертификат успешно активирован! ❄️



▶️ Выигрыш: Госномер на автомобиль [${res}]

♻️ Госномер уже на Вашем автомобиле!

⏰ Дата активации: ${date.getDate()}.${date.getMonth() + 1
        }.${date.getFullYear()}`);
    }
  }
);

cmd.hear(/^(?:1⃣ Госномер|Сертификат 1)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.sertificats.gosnomer < 1)
      return bot("у вас отсуствует данный сертификат.");

    return message.send(
      `⚠️ Используйте «Госномер [номер]»\n♻️ Например: «Госномер М777ММ».`
    );
  }
});

cmd.hear(/^(?:4⃣ Premium Статус|Сертификат 4)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.sertificats.premium < 1)
      return bot("у вас отсуствует данный сертификат.");

    if (message.user.settings.premium !== false)
      return message.send("💡 вы уже являетесь PREMIUM");

    if (message.user.settings.titan) {
      message.user.sertificats.premium -= 1;

      message.user.settings.premium = true;

      return bot(`Сертификат успешно активирован!`);
    }

    const date = new Date();

    message.user.sertificats.premium -= 1;

    message.user.settings.premium = true;

    message.user.stock.status = "Premium";

    message.user.limit.nicklimit = 32;

    message.user.level += 35;

    message.user.opit += 5000;

    message.user.limit.banklimit = 200000000000000;

    message.user.limit.farmlimit = 5000;

    message.user.limit.playerlimit = 200000000000000;

    message.user.limit.sent = 0;

    message.user.maxenergy = 30;

    return message.send(`☃️ @id${message.user.id} (${message.user.tag
      }), сертификат успешно активирован! ❄️



▶️ Выигрыш: PREMIUM статус

♻️ Просмотреть список команд для PREMIUM игрока: «PREMIUM help»

⏰ Дата активации: ${date.getDate()}.${date.getMonth() + 1
      }.${date.getFullYear()}`);
  }
});

cmd.hear(/^(?:7⃣ Опыт|Сертификат 7)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.sertificats.opit < 1)
      return bot("у вас отсуствует данный сертификат.");

    const date = new Date();

    message.user.sertificats.opit -= 1;

    message.user.opit += 5000;

    return message.send(`☃️ @id${message.user.id} (${message.user.tag
      }), сертификат успешно активирован! ❄️



▶️ Выигрыш: 5.000 опыта 📈

⏰ Дата активации: ${date.getDate()}.${date.getMonth() + 1
      }.${date.getFullYear()}`);
  }
});

cmd.hear(/^(?:5⃣ Секретный бизнес|Сертификат 5)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.sertificats.business < 1)
      return bot("у вас отсуствует данный сертификат.");

    const date = new Date();

    if (message.user.business.length >= 3) return bot(`у вас уже есть 3 бизнеса`);

    message.user.sertificats.business -= 1;

    message.user.business2.push({
      id: 16,

      upgrade: 1,

      workers: 7500,

      moneys: 300000000000,
    });

    return message.send(`☃️ @id${message.user.id} (${message.user.tag
      }), сертификат успешно активирован! ❄️



▶️ Выигрыш: Бизнес «Киностудия по всему миру»

⏰ Дата активации: ${date.getDate()}.${date.getMonth() + 1
      }.${date.getFullYear()}`);
  }
});

cmd.hear(/^(?:3⃣ Рейтинг|Сертификат 3)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.sertificats.rating < 1)
      return bot("у вас отсуствует данный сертификат.");

    const date = new Date();

    message.user.sertificats.rating -= 1;

    message.user.rating += 1000000;

    return message.send(`☃️ @id${message.user.id} (${message.user.tag
      }), сертификат успешно активирован! ❄️



▶️ Выигрыш: 1.000.000 рейтинга 👑

⏰ Дата активации: ${date.getDate()}.${date.getMonth() + 1
      }.${date.getFullYear()}`);
  }
});

cmd.hear(/^(?:2⃣ Лучшая машина|Сертификат 2)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.sertificats.car < 1)
      return bot("у вас отсуствует данный сертификат.");

    const date = new Date();

    message.user.sertificats.car -= 1;

    message.user.transport.car = 16;

    message.user.scar.prok_1 = 3;

    message.user.scar.prok_2 = 5;

    message.user.scar.prok_3 = 5;

    message.user.scar.prok_4 = 3;

    message.user.scar.prok_5 = 5;

    return message.send(`☃️ @id${message.user.id} (${message.user.tag
      }), сертификат успешно активирован! ❄️



▶️ Выигрыш: автомобиль Lamborghini Aventador SVJ. (Улучшенная) 🚗

⏰ Дата активации: ${date.getDate()}.${date.getMonth() + 1
      }.${date.getFullYear()}`);
  }
});


module.exports = commands;
