let utils = require('../utils.js');
const { VK } = require('vk-io');
const commands = [];
const fs = require('fs');

let double = require('../database/users.json');

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
    try {
        const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
        return tokens;
    } catch (error) {
        console.error('Ошибка при чтении токенов:', error);
        return null;
    }
}

function saveTokens(token, spoler, chatlogi) {
    const tokens = {
        token: token,
        spoler: spoler,
        chatlogi: chatlogi
    };

    try {
        fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
        console.log('Токены успешно сохранены.');
    } catch (error) {
        console.error('Ошибка при сохранении токенов:', error);
    }
}

const tokenData = getToken();
if (!tokenData) {
    console.error('Не удалось получить токены.');
    process.exit(1); // Завершаем программу, если токены не найдены
}

const vk = new VK({
    token: tokenData.token,
});

cmd.hear(/^(?:рестарт|res|рес|лежать)$/i, async (message, bot) => {

    const groupInfo = await vk.api.call('groups.getById', {
        access_token: tokenData.token,
        v: '5.131',
    });

    if (!groupInfo || groupInfo.length === 0) {
        throw new Error('Не удалось получить информацию о группе.');
    }

    const groupId = groupInfo[0].id;
    const admins = await vk.api.groups.getMembers({ group_id: groupId, filter: 'managers' });

    if (!admins.items.some(admin => admin.id === message.senderId)) {
        return
    }

    const msg = await bot("");

    const printProgress = (percent) => {
        const progressBarLength = 15;
        const filledLength = Math.floor(progressBarLength * percent / 100);
        const bar = '█ '.repeat(filledLength) + ' '.repeat(progressBarLength - filledLength);
        return `${bar} ${percent}%`;
    };

    for (let i = 0; i <= 100; i += 25) {
        try {
            await vk.api.messages.edit({
                peer_id: message.peerId,
                message: printProgress(i),
                conversation_message_id: msg.conversationMessageId
            });
        } catch (error) {
            console.error('Ошибка при редактировании сообщения:', error);
            // continue;
            return;
        }
        await new Promise(resolve => setTimeout(resolve, 1000)); 
    }



    process.exit();

});

module.exports = commands;