let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;

const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

const businesses = require("../spisok/business spisok.js")
const businesses2 = require("../spisok/бизнесы.js")


cmd.hear(/^(?:бизнесы|💼 Бизнесы)\s?([0-9]+)?$/i, async (message, bot) => {
  if (message.chat.type === 1) {
    if (!message.user.settings) {
      message.user.settings = {};
    }
    
    if (!message.args[1])
      return bot(`бизнесы:

 1️⃣ 🌯 Шаурмечная - 50.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 6.ООО GB/час

2️⃣ 🔺 Ларёк - 1ОО.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 1О.ООО GB/час

3️⃣ 🛒 Забегаловка - 25О.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 15.ООО GB/час

4️⃣ 🏪 Мини-магазин - 35О.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 2О.ООО GB/час

5️⃣ 🏭 Завод в гараже - 5ОО.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 3О.ООО GB/час

6️⃣ 🏗 Угольная шахта - 7О0.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 4О.ООО GB/час

7️⃣ 🗄 Маленький офис - 84О.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 5О.ООО GB/час

8️⃣ 🎮 Любительский GameDev - 95О.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 6О.ООО GB/час

9️⃣ 🛢 Нефтевышка - 1.5ОО.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 75.ООО GB/час

1️⃣0️⃣ ⛽ Мини АЭС - 2.5ОО.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 80.ООО GB/час

1️⃣1️⃣ 🚀 Космическое агентство - 3.3ОО.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 9О.ООО GB/час

1️⃣2️⃣ 🌐 CleverCodingNinja - 4.5ОО.ООО GB.
⠀ ⠀ ⠀ 💵 Прибыль: 1ОО.ООО GB/час

Для покупки введите «Бизнесы [номер бизнеса]»`);

    if (message.user.settings.busi === true) {
      if (message.user.business.length >= 5)
        return bot(`максимум можно иметь 5 бизнесов`);
    } else {
      if (message.user.business.length >= 4)
        return bot(`максимум можно иметь 4 бизнеса`);
    }

    if (message.args[1] < 1 || message.args[1] >= 13)
      return bot("неверный номер бизнеса.");

    message.args[1] = Number(message.args[1]) - 1;

    const sell = businesses[message.args[1]][0];

    if (sell == null) return;

    if (message.user.balance2 < sell.cost)
      return bot(
        `у вас недостаточно денег! ❌\n\n💰 Ваш баланс: ${utils.sp(
          message.user.balance2
        )} GB. 💵`
      );

    message.user.balance2 -= sell.cost;

    message.user.business.push({
      id: message.args[1] + 1,

      upgrade: 1,

      workers: 1,

      moneys: 0,
    });

    return bot(`вы купили «${sell.name}» за ${utils.sp(sell.cost)} GB`);
  }
  if (message.chat.type === 0) {
    if (!message.args[1])
      return bot(`бизнесы:

1️⃣ 🏚 Захудалая лачуга - 100.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 2.000.000 $/час

2️⃣ 🏖 Песочница sandbox - 1.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 3.000.000 $/час

3️⃣ 💾 Дискетка - 10.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 100.000.000 $/час

4️⃣ 🍔 Забегаловка - 100.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 1.500.000.000 $/час

5️⃣ 🏪 Уличный киоск - 500.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 10.000.000.000 $/час

6️⃣ 📦 Подвальный магазинчик - 2.000.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 130.000.000.000 $/час

7️⃣ 🏆 Доска достижений - 10.000.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 1.500.000.000.000 $/час

8️⃣ 🎮 Комната отдыха - 50.000.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 2.000.000.000.000 $/час

9️⃣ 📦 Старый сундук - 100.000.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 10.000.000.000.000 $/час

1️⃣0️⃣ 🕹 Консоль управления - 1.000.000.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 19.000.000.000.000 $/час

1️⃣1️⃣ 👶 Новичок - 15.000.000.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 100.000.000.000.000 $/час

1️⃣2️⃣ 🥕 Лоток на рынке - 150.000.000.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 200.000.000.000.000 $/час

1️⃣3️⃣ 💰 Золотая лихорадка - 1.000.000.000.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 500.000.000.000.000 $/час

Для покупки введите «Бизнесы [номер бизнеса]»`);

    if (message.user.inf === true) return bot(`Выключите безлимитный баланс`);

    if (message.user.settings.busi === true) {
      if (message.user.business2.length >= 5)
        return bot(`Максимум можно иметь 5 бизнесов`);
    } else {
      if (message.user.business2.length >= 4)
        return bot(`Максимум можно иметь 4 бизнеса`);
    }

    if (message.args[1] < 1 || message.args[1] >= 15)
      return bot("Неверный номер бизнеса.");


    message.args[1] = Number(message.args[1]) - 1;

    const sell = businesses2[message.args[1]][0];

    if (sell == null) return;

    if (message.user.balance < sell.cost)
      return bot(
        `у Вас недостаточно денег! ❌\n\n💰 Ваш баланс: ${utils.sp(
          message.user.balance
        )} $ 💵`
      );

    message.user.balance -= sell.cost;

    message.user.business2.push({
      id: message.args[1] + 1,

      upgrade: 1,

      workers: 1,

      moneys: 0,
    });

    return bot(`вы купили «${sell.name}» за ${utils.sp(sell.cost)} $`);

  }
});

/*
1️⃣4️⃣ 🦇 Заброшенная пещера - 25.000.000.000.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 5.000.000.000.000.000 $ / час

1️⃣5️⃣ ⭐ Глобальный рынок - 50.000.000.000.000.000.000 $
⠀ ⠀ ⠀ 💵 Прибыль: 10.000.000.000.000.000 $ / час
*/


module.exports = commands;
