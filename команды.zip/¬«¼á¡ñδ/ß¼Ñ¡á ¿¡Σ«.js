let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });


cmd.hear(/^(?:смена инфо|сменить инфо)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1) return;

  return bot(`помощь по смене имущества:

🔹 См машина [название/-]
🔹 См яхта [название/-]
🔹 См вертолет [название/-]
🔹 См самолет [название/-]
🔹 См дом [название/-]
🔹 См квартира [название/-]
🔹 См видеокарта [название/-]`);
});

cmd.hear(/^(?:см дом)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1) return;

  if (!message.args[1])
    return bot(`пожалуйста, напишите название для её смены! ❗

✍️ См дом [название/-]`);

  if (!message.user.realty.home)
    return bot(`у Вас нету машины для смены названия! 😦`);

  if (message.args[1] === "-") {
    message.user.astats.homes = false;

    return bot(`вернул прежнее название дома! 🏡`);
  } else {
    message.user.astats.homes = message.args[1];

    return bot(`ваш дом приобрел новое имя! 🔥
🏡 Новое название Вашего дома: ${message.args[1]}`);
  }
});

cmd.hear(/^(?:см квартира)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1) return;

  if (!message.args[1])
    return bot(`пожалуйста, напишите название для её смены! ❗
✍️ См квартира [название/-]`);

  if (!message.user.realty.apartment)
    return bot(`у Вас нету квартиры для смены названия! 😦`);

  if (message.args[1] === "-") {
    message.user.astats.apartment = false;

    return bot(`вернул прежнее название квартиры! 🌇`);
  } else {
    message.user.astats.apartment = message.args[1];

    return bot(`ваша квартира приобрела новое имя! 🔥
🌇 Новое название Вашей квартиры: ${message.args[1]}`);
  }
});

cmd.hear(/^(?:см видеокарта)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1) return;

  if (!message.args[1])
    return bot(`пожалуйста, напишите название для её смены! ❗
✍️ См видеокарта [название/-]`);

  if (!message.user.misc.videocard)
    return bot(`у Вас нету видеокарты для смены названия! 😦`);

  if (message.args[1] === "-") {
    message.user.astats.videocard = false;

    return bot(`вернул прежнее название видюхи! 📼`);
  } else {
    message.user.astats.videocard = message.args[1];

    return bot(`ваша видеокарта приобрела новое имя! 🔥
📼 Новое название Вашей видеокарты: ${message.args[1]}`);
  }
});

cmd.hear(/^(?:см машина)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1) return;

  if (!message.args[1])
    return bot(`пожалуйста, напишите название для её смены! ❗
✍️ См машина [название/-]`);

  if (!message.user.transport.car)
    return bot(`у Вас нету машины для смены названия! 😦`);

  if (message.args[1] === "-") {
    message.user.astats.car = false;

    return bot(`вернул прежнее название машины! 🚗
Оно поменялось в профиле и в информации о Вашей машине ✅`);
  } else {
    message.user.astats.car = message.args[1];

    return bot(`ваша машина приобрела новое имя! 🔥
🚗 Новое название Вашей машины: ${message.args[1]}`);
  }
});

cmd.hear(/^(?:см яхта)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1) return;

  if (!message.args[1])
    return bot(`пожалуйста, напишите название для её смены! ❗
✍️ См яхта [название/-]`);

  if (!message.user.transport.yacht)
    return bot(`у Вас нету яхты для смены названия! 😦`);

  if (message.args[1] === "-") {
    message.user.astats.yacht = false;

    return bot(`вернул прежнее название яхты! 🚤
Оно поменялось в профиле и в информации о Вашей яхте ✅`);
  } else {
    message.user.astats.yacht = message.args[1];

    return bot(`ваша яхта приобрела новое имя! 🔥
🚤 Новое название Вашей яхты: ${message.args[1]}`);
  }
});

cmd.hear(/^(?:см вертолет)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1) return;

  if (!message.args[1])
    return bot(`пожалуйста, напишите название для её смены! ❗
✍️ См вертолёт [название/-]`);

  if (!message.user.transport.helicopter)
    return bot(`у Вас нету вертолёта для смены названия! 😦`);

  if (message.args[1] === "-") {
    message.user.astats.helicopter = false;

    return bot(`вернул прежнее название вертолёта! 🚁
Оно поменялось в профиле и в информации о Вашем вертолёте ✅`);
  } else {
    message.user.astats.helicopter = message.args[1];

    return bot(`ваш вертолёт приобрел новое имя! 🔥
🚁 Новое название Вашего вертолёта: ${message.args[1]}`);
  }
});

cmd.hear(/^(?:см самолет)\s(.*)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1) return;

  if (!message.args[1])
    return bot(`пожалуйста, напишите название для её смены! ❗
✍️ См самолёт [название/-]`);

  if (!message.user.transport.airplane)
    return bot(`у Вас нету самолёта для смены названия! 😦`);

  if (message.args[1] === "-") {
    message.user.astats.airplane = false;

    return bot(`вернул прежнее название самолёта! ✈️
Оно поменялось в профиле и в информации о Вашем самолёте ✅`);
  } else {
    message.user.astats.airplane = message.args[1];

    return bot(`ваш самолёт приобрел новое имя! 🔥
✈️ Новое название Вашего самолёта: ${message.args[1]}`);
  }
});

module.exports = commands;
