let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')
let config = require('../database/settings.json');
let promo = 0

async function savePromo() {
  require("fs").writeFileSync(
    "./database/settings.json",
    JSON.stringify(config, null, "\t")
  );

  return true;
}


const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^промо\s([^]+)$/i, async (message, bot) => {

 if (message.args[1] === "выкл") {
  

    config.promotip = "balance";

    config.promovalue = 0;

    config.promolimit = 0;

    await savePromo();

    clearPromo();

    return bot("Промокод обнулён! 🔱");
  }

  if (config.promoname === message.args[1]) {

    if (message.user.promo) return bot(`вы уже активировали промокод. ⛔`);
    else {
      if (promo >= config.promolimit)
        return bot(
          `у этого промокода закончились использования!\nВключи уведомления о новых записях в группе, чтобы узнавать о промокодах одним из первых! 📢`
        );

      if (config.promotip === "btc") message.user.btc += config.promovalue;

      if (config.promotip === "баланс")
        message.user.balance += config.promovalue;

      if (config.promotip === "донат-кейсы")
        message.user.c3 += config.promovalue;

      if (config.promotip === "рейтинг")
        message.user.rating += config.promovalue;

      if (config.promotip === "скоины")
        message.user.sprcoin += config.promovalue;

      if (config.promotip === "vip") {
        const user = message.user;

        if (!user) return bot(`неверный ID игрока`);

        if (user.settings.premium !== false)
          return bot("Вы уже являетесь [Premium]. ⚠");

        if (user.settings.vip !== false)
          return bot("игрок уже являетесь [VIP]. ⚠");

        user.settings.vip = true;

        user.stock.status = "VIP";

        user.limit.nicklimit = 21;

        user.level += 5;

        user.limit.banklimit = 100000000000000;

        user.limit.farmlimit = 3000;

        user.limit.videocardlimit = 50;

        user.limit.playerlimit = 100000000000000;

        user.limit.sent = 0;

        user.maxenergy = 20;

        if (user.notifications)
          await vk.api.messages.send({
            user_id: user.id,
            message: `[❗УВЕДОМЛЕНИЕ❗]

			${user.tag} вы получили VIP статус! 💎

			⚠ Для ознакомления с комаднами введите «VIP help»

			🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
            random_id: 0,
          });
      }

      if (config.promotip === "premium") {
        const user = message.user;

        if (!user) return bot(`неверный ID игрока`);

        if (user.settings.premium !== false)
          return bot("игрок уже является [Premium]. ⚠");

        user.settings.vip = false;

        user.settings.premium = true;

        user.stock.status = "Premium";

        user.limit.nicklimit = 32;

        user.level += 35;

        user.opit += 5000;

        user.limit.banklimit = 200000000000000;

        user.limit.farmlimit = 5000;

        user.limit.videocardlimit = 75;

        user.limit.playerlimit = 200000000000000;

        user.limit.sent = 0;

        user.maxenergy = 30;

        await bot(`игрок назначен [Premium] 💎`);

        if (user.notifications)
          await vk.api.messages.send({
            user_id: user.id,
            message: `[❗УВЕДОМЛЕНИЕ❗]
${user.tag} вы получили Premium статус! 💎
⚠ Для ознакомления с комаднами введите «Premium help»
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
            random_id: 0,
          });
      }

      if (config.promotip === "hellpet") {
        message.user.misc.pet = utils.random(11, 12);

        message.user.pet.lvl = 1;
      }

      if (config.promotip === "hellcase") {
        message.user.c5 += config.promovalue;
      }
    }

    message.user.promo = true;

    promo += 1;

    ostalos = config.promolimit - promo;

     await savePromo();

    return bot(`зачислено +${utils.sp(config.promovalue)}${config.promotip
      .toString()
      .replace(/btc/gi, "฿")
      .replace(/balance/gi, "$")
      .replace(/dkeys/gi, " Донат-кейсов")} ✅

	📢 Осталось ${ostalos} использований.`);
  } else {
    return bot(
      `у данного промокода закончились использования, либо его не существует, проверьте правильность его написания`
    );
  }
});



cmd.hear(/^(?:setpromo|sp)\s([^]+)\s([^]+)\s([0-9]+)\s([0-9]+)$/i, async (message, bot) => {

  

  config.promoname = message.args[1];

  config.promotip = message.args[2];

  config.promovalue = Number(message.args[3]);

  config.promolimit = Number(message.args[4]);

  await savePromo();

  return bot(`настройки обновлены. ⚙

	💣 Название: ${message.args[1]}.	

	💣 Тип: ${message.args[2]}.

	💢 Сумма: ${message.args[3]}.

	👥 Кол-во: ${message.args[4]}.`);

});

cmd.hear(/^(?:чек промо)$/i, async (message, bot) => {


  return bot(`настройки промо.

💣 Название: ${config.promoname}.
💣 Тип: ${config.promotip}.
💢 Сумма: ${config.promovalue}.
👥 Кол-во: ${config.promolimit}.
👥 Осталось: ${config.promolimit - promo}.

Типы промо: "btc","баланс","донат-кейсы","рейтинг","vip","premium"
Создать рандомный промокод "randomPromocode"`);
});



module.exports = commands;
