let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:!ник|ник)$/i, async(message, bot) =>{ 
bot(`использование: "ник [новый ник]"
💸 Стоимость: 50.000 GB`)
})

cmd.hear(/^(?:!ник|ник)\s(.*)$/i, async (message, bot) => {


    if (message.user.balance2 < 50000) return bot(' для смены ника вам нужно 50.000 GB 💸')
    if (message.args[1].length > 40) return bot(` максимально 40 символов.`);
    if (message.args[1].length < 3) return bot(` минимально 3 символа.`);
    message.user.balance2 -= 50000
    message.user.tag = message.args[1];
    let smilenick = utils.pick([`😯`, `🙂`, `☺`]);
    let ggtext = utils.pick([`фантастический ник!`, `крутой ник!`, `классный ник!`, `прикольный ник!`, `красивый ник!`, `таких ников я ещё не видел!`]);
    return bot(`${ggtext} ${smilenick}`);
  

});
  
cmd.hear(/^(?:сетник)\s([0-9]+)\s(.+)$/i, async (message, bot) => {

  const groupInfo = await vk.api.call('groups.getById', {
    access_token: tokenData.token,
    v: '5.131',
  });

  if (!groupInfo || groupInfo.length === 0) {
    throw new Error('Не удалось получить информацию о группе.');
  }

  const groupId = groupInfo[0].id;
  const admins = await vk.api.groups.getMembers({ group_id: groupId, filter: 'managers' });

  if (!admins.items.some(admin => admin.id === message.senderId)) {
    return
  }


  let user = double.find(x => x.uid === Number(message.args[1]));
  if (!user) return bot(`пользователь не найден.`);


  let newNickname = message.args[2].trim();
  if (!newNickname) return bot(`укажите новый никнейм.`);


  user.tag = newNickname;

  await bot(`вы изменили никнейм пользователя на "${newNickname}".`);
});


module.exports = commands;
