let utils = require('../utils.js');

const commands = [];

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const promptBet = (message, bot) => {
    return bot('нажми кнопку ИЛИ введи команду: "5 [сумма ставки]"', {
        keyboard: JSON.stringify({
            "inline": true,
            "buttons": [
                [{
                    "action": {
                        "type": "text",
                        "payload": "{}",
                        "label": `x5 ${message.user.lastbet}`
                    },
                    "color": "default"
                },
                {
                    "action": {
                        "type": "text",
                        "payload": "{}",
                        "label": `x5 ${message.user.lastbet * 2}`
                    },
                    "color": "default"
                },
                {
                    "action": {
                        "type": "text",
                        "payload": "{}",
                        "label": `x5 ${message.user.balance2}`
                    },
                    "color": "default"
                }]
            ]
        })
    });
};

const processBetAmount = (input) => {
    return input.replace(/(\.|\,)/ig, '')
                .replace(/(к|k)/ig, '000')
                .replace(/(м|m)/ig, '000000')
                .replace(/(вабанк|вобанк|все|всё)/ig, '');
};

const updateGameStakes = (message, amount) => {
    const lastGame = message.chat.games[message.chat.games.length - 1];
    const existingStake = lastGame.stavki.find(x => x.id === message.senderId && x.type === 5);

    if (existingStake) {
        existingStake.amount += amount;
    } else {
        lastGame.stavki.push({
            uid: message.user.uid,
            id: message.user.id,
            type: 5,
            amount: amount
        });
    }
};

cmd.hear(/^(?:x5|5)$/i, async (message, bot) => {
    if (message.chat.type === 1) {
        if (message.chat.type === 0 || message.user.balance2 <= 0) return bot(`на твоем балансе нет коинов...`);
        if (!isFinite(message.user.balance2)) {
            message.user.balance2 = 0;
            return bot(`На твоем балансе царило бесконечное богатство, но, увы, оно обнулено.`);
        }
        return promptBet(message, bot);
    }
});

cmd.hear(/^(?:x5|5)\s(.*)$/i, async (message, bot) => {
    if (message.chat.type === 1) {
        if (message.chat.type === 0 || message.user.balance2 <= 0) return bot(`на твоем балансе нет коинов...`);
        if (!isFinite(message.user.balance2)) {
            message.user.balance2 = 0;
            return bot(`На твоем балансе царило бесконечное богатство, но, увы, оно обнулено.`);
        }
        if (message.chat.gametime < 6) return;

        const rawAmount = processBetAmount(message.args[1]);
        const betAmount = Math.floor(Number(rawAmount));

        if (isNaN(betAmount) || betAmount <= 0 || betAmount > message.user.balance2) {
            return promptBet(message, bot);
        }

        message.user.balance2 -= betAmount;
        updateGameStakes(message, betAmount);
        message.user.lastbet = betAmount;

        return bot(`успешная ставка ${utils.sp(betAmount)} GB на x5`);
    }
});

module.exports = commands;
