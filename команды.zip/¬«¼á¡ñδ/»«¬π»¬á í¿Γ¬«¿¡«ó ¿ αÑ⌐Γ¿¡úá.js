let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

let btc = 0;
let dog = 0
function getRandomBtcValue() {
  // Генерация случайного значения от 50000 до 61000
  return Math.floor(Math.random() * (61000 - 50000 + 1)) + 50000;
}

function getRandomBtcValue1() {
  // Генерация случайного значения от 0.900 до 2.0
  return (Math.random() * (2.0 - 0.900) + 0.900).toFixed(3);  // .toFixed(3) для округления до трех знаков после запятой
}


// Обновление значения btc каждые 5 секунд
setInterval(() => {
  btc = getRandomBtcValue();
  dog = getRandomBtcValue1();
  // console.log(`Новое значение BTC: ${btc}`);
  // console.log(`Новое значение DOG: ${dog}`);
}, 60000);
// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi;
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:рейтинг)\s(.*)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    message.args[1] = message.args[1].replace(/([.,])/gi, "");

    message.args[1] = message.args[1].replace(/([кk])/gi, "000");

    message.args[1] = message.args[1].replace(/[мm]/gi, "000000");

    if (message.user.inf === true) return bot(`Выключите безлимитный баланс`);

    if (!Number(message.args[1])) return;

    message.args[1] = Math.floor(Number(message.args[1]));

    if (message.args[1] <= 0) return;

    if (message.args[1] * 700000000 > message.user.balance)
      return bot(`у вас недостаточно денег`);
    else if (message.args[1] * 700000000 <= message.user.balance) {
      message.user.balance -= message.args[1] * 700000000;

      message.user.rating += message.args[1];

      return bot(
        `вы успешно повысили свой рейтинг на ${utils.sp(
          message.args[1]
        )}ед. 👑 за ${utils.sp(
          message.args[1] * 700000000
        )}$\n💰 Ваш баланс: ${utils.sp(message.user.balance)}$`
      );
    }
  }
});

cmd.hear(/^(?:биткоин)\s(.*)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    message.args[1] = message.args[1].replace(/([.,])/gi, "");

    message.args[1] = message.args[1].replace(/(к|k)/gi, "000");

    message.args[1] = message.args[1].replace(/(м|m)/gi, "000000");

    message.args[1] = message.args[1].replace(
      /(вабанк|вобанк|все|всё)/gi,
      Math.floor(Number(message.user.balance / btc))
    );

    if (!Number(message.args[1])) return;

    message.args[1] = Math.floor(Number(message.args[1]));

    if (message.user.inf === true) return bot(`Выключите безлимитный баланс`);

    if (message.args[1] <= 0) return;

    if (message.args[1] * btc > message.user.balance)
      return bot(
        `у Вас недостаточно денег! ❌\n\n💰 Ваш баланс: ${utils.sp(
          message.user.balance
        )}$ 💵\n🌐 Курс биткоина: ${btc}$`
      );
    else if (message.args[1] * btc <= message.user.balance) {
      message.user.balance -= message.args[1] * btc;

      message.user.btc += message.args[1];

      return bot(
        `вы купили ${utils.sp(message.args[1])} биткоинов за ${utils.sp(
          message.args[1] * btc
        )}$`
      );
    }
  }
});


module.exports = commands;
