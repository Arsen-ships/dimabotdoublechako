let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')
let yachts = require('../spisok/яхты.js')
let homes = require('../spisok/дома.js')
let minertool = require('../spisok/инструменты.js')
let computers = require('../spisok/компьютеры.js')
let apartments = require('../spisok/апартаменты.js')
let airplanes = require('../spisok/самолеты.js')
let helicopters = require('../spisok/вертолеты.js')
const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });


cmd.hear(/^(?:яхты|🛥 Яхты|яхта)\s?([0-9]+)?$/i, async (message, bot) => {
        if (message.chat.type === 0) {
                let smileng = utils.pick([
                        `🌷`,
                        `🌸`,
                        `🌹`,
                        `🌺`,
                        `🌼`,
                        `💐`,
                        `❤️`,
                        `💓`,
                        `💕`,
                ]);

                if (!message.args[1])
                        return bot(`яхты:

${message.user.transport.yacht === 1 ? "✔️" : "✖️"} 1. Ванна (10.000.000.000$)
${message.user.transport.yacht === 2 ? "✔️" : "✖️"
                                } 2. Nauticat 331 (10.000.000.000.000$)
${message.user.transport.yacht === 3 ? "✔️" : "✖️"
                                } 3. Nordhavn 56 MS (15.000.000.000.000$)
${message.user.transport.yacht === 4 ? "✔️" : "✖️"
                                } 4. Princess 60 (25.000.000.000.000$)
${message.user.transport.yacht === 5 ? "✔️" : "✖️"
                                } 5. Azimut 70 (35.000.000.000.000$)
${message.user.transport.yacht === 6 ? "✔️" : "✖️"
                                } 6. Dominator 40M (50.000.000.000.000$)
${message.user.transport.yacht === 7 ? "✔️" : "✖️"
                                } 7. Moonen 124 (60.000.000.000.000$)
${message.user.transport.yacht === 8 ? "✔️" : "✖️"
                                } 8. Wider 150 (65.000.000.000.000$)
${message.user.transport.yacht === 9 ? "✔️" : "✖️"
                                } 9. Palmer Johnson 42M SuperSport (80.000.000.000.000$)
${message.user.transport.yacht === 10 ? "✔️" : "✖️"
                                } 10. Wider 165 (85.000.000.000.000$)
${message.user.transport.yacht === 11 ? "✔️" : "✖️"
                                } 11. Eclipse (150.000.000.000.000$)
${message.user.transport.yacht === 12 ? "✔️" : "✖️"
                                } 12. Dubai (300.000.000.000.000$)
${message.user.transport.yacht === 13 ? "✔️" : "✖️"
                                } 13. Streets of Monaco (750.000.000.000.000$)

🛒 Для покупки введите «Яхта [номер]»

${smileng}`);

                const sell = yachts.find((x) => x.id === Number(message.args[1]));

                if (!sell) return;

                if (message.user.transport.yacht)
                        return bot(
                                `у вас уже есть яхта (${yachts[message.user.transport.yacht - 1].name
                                }), введите "Продать яхту"`
                        );

                if (message.user.balance < sell.cost) return bot(`недостаточно денег`);
                else if (message.user.balance >= sell.cost) {
                        message.user.balance -= sell.cost;

                        message.user.transport.yacht = sell.id;

                        return bot(`вы купили «${sell.name}» за ${utils.sp(sell.cost)}$`);
                }
        }
});



cmd.hear(
  /^(?:самол[её]т|🛩 Самолеты|самол[её]ты)\s?([0-9]+)?$/i,
        async (message, bot) => {
                if (message.chat.type === 0) {
                        let smileng = utils.pick([
                                `🌷`,
                                `🌸`,
                                `🌹`,
                                `🌺`,
                                `🌼`,
                                `💐`,
                                `❤️`,
                                `💓`,
                                `💕`,
                        ]);

                        if (!message.args[1])
                                return bot(`самолеты:

${message.user.transport.airplane === 1 ? "✔️" : "✖️"
                                        } 1. Параплан (100.000.000.000$)
${message.user.transport.airplane === 2 ? "✔️" : "✖️"
                                        } 2. АН-2 (350.000.000.000$)
${message.user.transport.airplane === 3 ? "✔️" : "✖️"
                                        } 3. Cessna-172E (700.000.000.000$)
${message.user.transport.airplane === 4 ? "✔️" : "✖️"
                                        } 4. Supermarine Spitfire (1.000.000.000.000$)
${message.user.transport.airplane === 5 ? "✔️" : "✖️"
                                        } 5. BRM NG-5 (1.400.000.000.000$)
${message.user.transport.airplane === 6 ? "✔️" : "✖️"
                                        } 6. Cessna T210 (2.600.000.000.000$)
${message.user.transport.airplane === 7 ? "✔️" : "✖️"
                                        } 7. Beechcraft 1900D (5.500.000.000.000$)
${message.user.transport.airplane === 8 ? "✔️" : "✖️"
                                        } 8. Cessna 550 (8.000.000.000.000$)
${message.user.transport.airplane === 9 ? "✔️" : "✖️"
                                        } 9. Hawker 4000 (22.400.000.000.000$)
${message.user.transport.airplane === 10 ? "✔️" : "✖️"
                                        } 10. Learjet 31 (45.000.000.000.000$)
${message.user.transport.airplane === 11 ? "✔️" : "✖️"
                                        } 11. Airbus A318 (85.000.000.000.000$)
${message.user.transport.airplane === 12 ? "✔️" : "✖️"
                                        } 12. F-35A (160.000.000.000.000$)
${message.user.transport.airplane === 13 ? "✔️" : "✖️"
                                        } 13. Boeing 747-430 Custom (225.000.000.000.000$)
${message.user.transport.airplane === 14 ? "✔️" : "✖️"
                                        } 14. C-17A Globemaster III (350.000.000.000.000$)
${message.user.transport.airplane === 15 ? "✔️" : "✖️"
                                        } 15. F-22 Raptor (400.000.000.000.000$)
${message.user.transport.airplane === 16 ? "✔️" : "✖️"
                                        } 16. Airbus 380 Custom (600.000.000.000.000$)
${message.user.transport.airplane === 17 ? "✔️" : "✖️"
                                        } 17. B-2 Spirit Stealth Bomber (1.359.000.000.000.000$)

🛒 Для покупки введите «Самолет [номер]»

${smileng}`);

                        const sell = airplanes.find((x) => x.id === Number(message.args[1]));

                        if (!sell) return;

                        if (message.user.transport.airplane)
                                return bot(
                                        `у вас уже есть самолёт (${airplanes[message.user.transport.airplane - 1].name
                                        }), введите "Продать самолёт"`
                                );

                        if (message.user.balance < sell.cost) return bot(`недостаточно денег`);
                        else if (message.user.balance >= sell.cost) {
                                message.user.balance -= sell.cost;

                                message.user.transport.airplane = sell.id;

                                return bot(`вы купили «${sell.name}» за ${utils.sp(sell.cost)}$`);
                        }
                }
        }
);

cmd.hear(
  /^(?:вертол[её]т|🚁 Вертолеты|вертол[её]ты)\s?([0-9]+)?$/i,
        async (message, bot) => {
                if (message.chat.type === 0) {
                        let smileng = utils.pick([
                                `🌷`,
                                `🌸`,
                                `🌹`,
                                `🌺`,
                                `🌼`,
                                `💐`,
                                `❤️`,
                                `💓`,
                                `💕`,
                        ]);

                        if (!message.args[1])
                                return bot(`вертолеты:

${message.user.transport.helicopter === 1 ? "✔️" : "✖️"
                                        } 1. Шарик с пропеллером (150.000.000.000$)
${message.user.transport.helicopter === 2 ? "✔️" : "✖️"
                                        } 2. RotorWay Exec 162F (300.000.000.000$)
${message.user.transport.helicopter === 3 ? "✔️" : "✖️"
                                        } 3. Robinson R44 (450.000.000.000$)
${message.user.transport.helicopter === 4 ? "✔️" : "✖️"
                                        } 4. Hiller UH-12C (1.300.000.000.000$)
${message.user.transport.helicopter === 5 ? "✔️" : "✖️"
                                        } 5. AW119 Koala (2.500.000.000.000$)
${message.user.transport.helicopter === 6 ? "✔️" : "✖️"
                                        } 6. MBB BK 117 (4.000.000.000.000$)
${message.user.transport.helicopter === 7 ? "✔️" : "✖️"
                                        } 7. Eurocopter EC130 (7.500.000.000.000$)
${message.user.transport.helicopter === 8 ? "✔️" : "✖️"
                                        } 8. Leonardo AW109 Power (10.000.000.000.000$)
${message.user.transport.helicopter === 9 ? "✔️" : "✖️"
                                        } 9. Sikorsky S-76 (15.000.000.000.000$)
${message.user.transport.helicopter === 10 ? "✔️" : "✖️"
                                        } 10. Bell 429WLG (19.000.000.000.000$)
${message.user.transport.helicopter === 11 ? "✔️" : "✖️"
                                        } 11. NHI NH90 (35.000.000.000.000$)
${message.user.transport.helicopter === 12 ? "✔️" : "✖️"
                                        } 12. Kazan Mi-35M (60.000.000.000.000$)
${message.user.transport.helicopter === 13 ? "✔️" : "✖️"
                                        } 13. Bell V-22 Osprey (135.000.000.000.000$)

🛒 Для покупки введите «Вертолет [номер]»

${smileng}`);

                        const sell = helicopters.find((x) => x.id === Number(message.args[1]));

                        if (!sell) return;

                        if (message.user.transport.helicopter)
                                return bot(
                                        `у вас уже есть вертолёт (${homes[message.user.transport.helicopter - 1].name
                                        }), введите "Продать вертолёт"`
                                );

                        if (message.user.balance < sell.cost) return bot(`недостаточно денег`);
                        else if (message.user.balance >= sell.cost) {
                                message.user.balance -= sell.cost;

                                message.user.transport.helicopter = sell.id;

                                return bot(`вы купили «${sell.name}» за ${utils.sp(sell.cost)}$`);
                        }
                }
        }
);

cmd.hear(
        /^(?:квартира|🌇 Квартиры|квартиры)\s?([0-9]+)?$/i,
        async (message, bot) => {
                if (message.chat.type === 0) {
                        if (!message.args[1])
                                return bot(`квартиры:

${message.user.realty.apartment === 1 ? "✔️" : "✖️"} 1. Чердак (${utils.sp(
                                        apartments.find((x) => x.id === Number(1)).cost
                                )}$)
${message.user.realty.apartment === 2 ? "✔️" : "✖️"
                                        } 2. Квартира в общежитии (${utils.sp(
                                                apartments.find((x) => x.id === Number(2)).cost
                                        )}$)
${message.user.realty.apartment === 3 ? "✔️" : "✖️"
                                        } 3. Однокомнатная квартира (${utils.sp(
                                                apartments.find((x) => x.id === Number(3)).cost
                                        )}$)
${message.user.realty.apartment === 4 ? "✔️" : "✖️"
                                        } 4. Двухкомнатная квартира (${utils.sp(
                                                apartments.find((x) => x.id === Number(4)).cost
                                        )}$)
${message.user.realty.apartment === 5 ? "✔️" : "✖️"
                                        } 5. Четырехкомнатная квартира (${utils.sp(
                                                apartments.find((x) => x.id === Number(5)).cost
                                        )}$)
${message.user.realty.apartment === 6 ? "✔️" : "✖️"
                                        } 6. Квартира в центре Москвы (${utils.sp(
                                                apartments.find((x) => x.id === Number(6)).cost
                                        )}$)
${message.user.realty.apartment === 7 ? "✔️" : "✖️"
                                        } 7. Двухуровневая квартира (${utils.sp(
                                                apartments.find((x) => x.id === Number(7)).cost
                                        )}$)
${message.user.realty.apartment === 8 ? "✔️" : "✖️"
                                        } 8. Квартира с Евроремонтом (${utils.sp(
                                                apartments.find((x) => x.id === Number(8)).cost
                                        )}$)

🛒 Для покупки введите «Квартира [номер]»`);

                        const sell = apartments.find((x) => x.id === Number(message.args[1]));

                        if (!sell) return;

                        if (message.user.realty.apartment)
                                return bot(
                                        `у вас уже есть квартира (${apartments[message.user.realty.apartment - 1].name
                                        }), чтобы её продать введите «Продать квартиру»`
                                );

                        if (message.user.balance < sell.cost)
                                return bot(
                                        `у Вас недостаточно денег! ❌\n\n💰 Ваш баланс: ${utils.sp(
                                                message.user.balance
                                        )}$ 💵`
                                );
                        else if (message.user.balance >= sell.cost) {
                                message.user.balance -= sell.cost;

                                message.user.realty.apartment = sell.id;

                                return bot(`вы купили «${sell.name}» за ${utils.sp(sell.cost)}$`);
                        }
                }
        }
);

cmd.hear(
        /^(?:телефон|📱 Телефоны|телефоны)\s?([0-9]+)?$/i,
        async (message, bot) => {
                if (message.chat.type === 0) {
                        if (!message.args[1])
                                return bot(`телефоны:

${message.user.misc.phone === 1 ? "✔️" : "✖️"} 1. Nokia 108 (${utils.sp(
                                        phones.find((x) => x.id === Number(1)).cost
                                )}$)
${message.user.misc.phone === 2 ? "✔️" : "✖️"} 2. Nokia 3310 (${utils.sp(
                                        phones.find((x) => x.id === Number(2)).cost
                                )}$)
${message.user.misc.phone === 3 ? "✔️" : "✖️"} 3. BQ Aquaris M5 (${utils.sp(
                                        phones.find((x) => x.id === Number(3)).cost
                                )}$)
${message.user.misc.phone === 4 ? "✔️" : "✖️"} 4. ASUS ZenFone 4 (${utils.sp(
                                        phones.find((x) => x.id === Number(4)).cost
                                )}$)
${message.user.misc.phone === 5 ? "✔️" : "✖️"
                                        } 5. Samsung Galaxy S11 (${utils.sp(
                                                phones.find((x) => x.id === Number(5)).cost
                                        )}$)
${message.user.misc.phone === 6 ? "✔️" : "✖️"} 6. Escobar Fold 1 (${utils.sp(
                                                phones.find((x) => x.id === Number(6)).cost
                                        )}$)
${message.user.misc.phone === 7 ? "✔️" : "✖️"} 7. iPhone 11 Pro Max (${utils.sp(
                                                phones.find((x) => x.id === Number(7)).cost
                                        )}$)
${message.user.misc.phone === 8 ? "✔️" : "✖️"
                                        } 8. Xiaomi Mi Mix Alpha (${utils.sp(
                                                phones.find((x) => x.id === Number(8)).cost
                                        )}$)
${message.user.misc.phone === 9 ? "✔️" : "✖️"
                                        } 9. Samsung Galaxy S50+ (${utils.sp(
                                                phones.find((x) => x.id === Number(9)).cost
                                        )}$)

🛒 Для покупки введите «Телефоны [номер]»`);

                        const sell = phones.find((x) => x.id === Number(message.args[1]));

                        if (!sell) return;

                        if (message.user.misc.phone)
                                return bot(
                                        `у Вас уже есть телефон «${phones[message.user.misc.phone - 1].name
                                        }» ❌\nЧтобы его продать, введите «Продать телефон»`
                                );

                        if (message.user.balance < sell.cost)
                                return bot(
                                        `у Вас недостаточно денег! ❌\n\n💰 Ваш баланс: ${utils.sp(
                                                message.user.balance
                                        )}$ 💵`
                                );
                        else if (message.user.balance >= sell.cost) {
                                message.user.balance -= sell.cost;

                                message.user.misc.phone = sell.id;

                                message.user.procent.phone = utils.random(50, 100);

                                return bot(`вы купили «${sell.name}» за ${utils.sp(sell.cost)}$`);
                        }
                }
        }
);

//кнопка

cmd.hear(/^(?:часы|⌚ Часы)\s?([0-9]+)?$/i, async (message, bot) => {
        if (message.chat.type === 0) {
                if (!message.args[1])
                        return bot(`часы:

${message.user.misc.clock === 1 ? "✔️" : "✖️"} 1. DKNY NY2342 (150.000.000$)
${message.user.misc.clock === 2 ? "✔️" : "✖️"
                                } 2. Earnshaw ES-8001-03 (2017) (600.000.000$)
${message.user.misc.clock === 3 ? "✔️" : "✖️"} 3. Orient ER27005W (114.000.000$)
${message.user.misc.clock === 4 ? "✔️" : "✖️"
                                } 4. Armani Exchange AX2104 (325.000.000$)
${message.user.misc.clock === 5 ? "✔️" : "✖️"
                                } 5. Swiss Military Hanowa  06-3308.04.007 (750.000.000$)
${message.user.misc.clock === 6 ? "✔️" : "✖️"
                                } 6. Calvin Klein K3M2212Z (900.000.000$)
${message.user.misc.clock === 7 ? "✔️" : "✖️"
                                } 7. Bomberg NS44CHSP.0098.3 (1.300.000.000$)
${message.user.misc.clock === 8 ? "✔️" : "✖️"
                                } 8. Armani Exchange AX2900 (2.225.000.000$)
${message.user.misc.clock === 9 ? "✔️" : "✖️"
                                } 9. Wainer WA. 10000-A (3.440.000.000$)

🛒 Для покупки введите «Часы [номер]»`);

                const sell = clocks.find((x) => x.id === Number(message.args[1]));

                if (!sell) return;

                if (message.user.misc.clock)
                        return bot(
                                `у Вас уже есть часы «${clocks[message.user.misc.clock - 1].name
                                }» ❌\nЧтобы их продать, введите «Продать часы»`
                        );

                if (message.user.balance < sell.cost)
                        return bot(
                                `у Вас недостаточно денег! ❌\n\n💰 Ваш баланс: ${utils.sp(
                                        message.user.balance
                                )}$ 💵`
                        );
                else if (message.user.balance >= sell.cost) {
                        message.user.balance -= sell.cost;

                        message.user.misc.clock = sell.id;

                        message.user.procent.clock = utils.random(1, 100);

                        return bot(`вы купили «${sell.name}» за ${utils.sp(sell.cost)}$`);
                }
        }
});

//кнопка

cmd.hear(
        /^(?:компьютер|🖥 Компьютеры|компьютеры)\s?([0-9]+)?$/i,
        async (message, bot) => {
                if (message.chat.type === 0) {
                        if (!message.args[1])
                                return bot(`компьютеры:

${message.user.misc.computer === 1 ? "✔️" : "✖️"} 1. DЕXР Аquilоn О175 (10.000$)
${message.user.misc.computer === 2 ? "✔️" : "✖️"} 2. HYРЕRРС NЕО (500.000$)
${message.user.misc.computer === 3 ? "✔️" : "✖️"
                                        } 3. DЕLL Аliеnwаrе Аurоrа R7 (1.000.000$)
${message.user.misc.computer === 4 ? "✔️" : "✖️"
                                        } 4. HYРЕRРС СОSMОS X 3 (3.000.000$)
${message.user.misc.computer === 5 ? "✔️" : "✖️"
                                        } 5. HYРЕRРС РRЕMIUM (5.000.000$)

🛒 Для покупки введите «Компьютер [номер]»`);

                        const sell = computers.find((x) => x.id === Number(message.args[1]));

                        if (!sell) return;

                        if (message.user.misc.computer)
                                return bot(
                                        `у Вас уже есть компьютер «${computers[message.user.misc.computer - 1].name
                                        }» ❌\nЧтобы его продать, введите «Продать компьютер»`
                                );

                        if (message.user.balance < sell.cost)
                                return bot(
                                        `у Вас недостаточно денег! ❌\n\n💰 Ваш баланс: ${utils.sp(
                                                message.user.balance
                                        )}$ 💵`
                                );
                        else if (message.user.balance >= sell.cost) {
                                message.user.balance -= sell.cost;

                                message.user.misc.computer = sell.id;

                                return bot(`вы купили «${sell.name}» за ${utils.sp(sell.cost)}$`);
                        }
                }
        }
);

cmd.hear(
        /^(?:Инструменты|🔧Инструменты|🔧 Инструменты)\s?([0-9]+)?$/i,
        async (message, bot) => {
                if (message.chat.type === 0) {
                        if (!message.args[1])
                                return bot(`Инструменты:

${message.user.minertool === 1 ? "✔️" : "✖️"} 1. Деревянная кирка (${utils.sp(
                                        minertool.find((x) => x.id === Number(1)).cost
                                )}$)
${message.user.minertool === 2 ? "✔️" : "✖️"} 2. Стальная кирка (${utils.sp(
                                        minertool.find((x) => x.id === Number(2)).cost
                                )}$)
${message.user.minertool === 3 ? "✔️" : "✖️"} 3. Буровая установка (${utils.sp(
                                        minertool.find((x) => x.id === Number(3)).cost
                                )}$)
${message.user.minertool === 4 ? "✔️" : "✖️"} 4. Адронный коллайдер (${utils.sp(
                                        minertool.find((x) => x.id === Number(4)).cost
                                )}$)
${message.user.minertool === 5 ? "✔️" : "✖️"} 5. Разрушитель частиц (${utils.sp(
                                        minertool.find((x) => x.id === Number(5)).cost
                                )}$)

🛒 Для покупки введите «Инструменты [номер]»`);

                        const sell = minertool.find((x) => x.id === Number(message.args[1]));

                        if (!sell) return;

                        if (message.user.minertool)
                                return bot(
                                        `у Вас уже есть «${minertool[message.user.minertool - 1].name
                                        }» ❌\n Чтобы его продать, введите «Продать инструмент»`
                                );

                        if (message.user.balance < sell.cost)
                                return bot(
                                        `у Вас недостаточно денег! ❌\n\n💰 Ваш баланс: ${utils.sp(
                                                message.user.balance
                                        )}$ 💵`
                                );
                        else if (message.user.balance >= sell.cost) {
                                message.user.balance -= sell.cost;

                                message.user.minertool = sell.id;

                                return bot(`вы купили «${sell.name}» за ${utils.sp(sell.cost)}$`);
                        }
                }
        }
);



module.exports = commands;
