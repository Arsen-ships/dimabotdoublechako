let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });


cmd.hear(/^(?:обмен чакоруб|обменник|о)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    utils.pick([`🌷`, `🌸`, `🌹`, `🌺`, `🌼`, `💐`, `❤️`, `💓`, `💕`]);
    return bot(`Обмен ЧакоРуб:

🏆 ➖ Привилегии
1&#8419; Администратор | 30.000 ЧакоРуб
2&#8419; Premium | 1499 ЧакоРуб
3&#8419; VIP | 1149 ЧакоРуб

📦 ➖ Кейсы
4&#8419; Донат-кейс | 150 ЧакоРуб

💰 ➖ Валюта
5&#8419; 150.000.000.000.000$ | 149 ЧакоРуб
6&#8419; 20.000.000.000.000$ | 299 ЧакоРуб
7&#8419; 2.000.000.000.000$ | 100 ЧакоРуб
8&#8419; 450.000.000.000$ | 20 ЧакоРуб
9&#8419; 150.000.000.000$ | 15 ЧакоРуб
1&#8419;0&#8419; 50.000.000.000$ | 10 ЧакоРуб
1&#8419;1&#8419; 15.000.000.000$ | 5 ЧакоРуб
1&#8419;2&#8419; 5.000.000.000$ | 3 ЧакоРуб

💬 ➖ Другое
1&#8419;3&#8419; Киностудия - 3.000.000.000.000$/час | 2999 ЧакоРуб
1&#8419;4&#8419; Длинный ник | 14 ЧакоРуб

🌟 ➖ Новинки
1&#8419;5&#8419; Донатный Гигант - 30 ЧакоРуб/час | 15000 ЧакоРуб
1&#8419;6&#8419; TITAN VIP | 25000 ЧакоРуб

📦 ➖ Посылки
1&#8419;7&#8419; Денежная посылка | 250 ЧакоРуб
1&#8419;8&#8419; Элитная посылка | 1000 ЧакоРуб
1&#8419;9&#8419; Премиум посылка | 5000 ЧакоРуб

💵 ➖ Баланс: ${utils.sp(message.user.rub)} ЧакоРуб

🛒 Для покупки введите "ЧакоРуб [номер]".`);
  }
});

cmd.hear(/^(?:ЧакоРуб 1)$/i, async (message, bot) => {
  if (message.chat.type === 0) {

    if (30000 > message.user.rub) return bot(`недостаточно донат-рублей. ⛔`);

    if (message.user.settings.adm > 0) return bot(`у вас уже имеется данный товар. ✅`);

    message.user.rub -= 30000;
    message.user.settings.adm = 1;
    message.user.bantop = true;
    message.user.stock.status = 'Администратор';

    return message.send(`▶️ Успешная покупка! -30.000 ЧакоРуб 💰\n🎉 Поздравляем, Вы приобрели администратора! 🎊\n\n✏️ Отпишите @eee_dev чтобы он Вас пригласил в админ-беседу 😸`);
  }
  });

cmd.hear(/^(?:ЧакоРуб 2)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (1499 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);

    if (message.user.settings.premium) return bot(`у вас уже имеется статус [Premium]. ✅`);

    if (message.user.settings.titan) {

      message.user.settings.premium = true;

      message.user.rub -= 1499;

      return message.send(`▶️ Успешная покупка! -1.499 ЧакоРуб 💰\n🎉 Поздравляем, Вы приобрели статус «PREMIUM»! 🎊\n\n💬 Ознакомиться со списком всех доступных команд можно по команде «Premium help» 🤗`);

    } else if (message.user.settings.premium <= message.user.rub) {

      message.user.rub -= 1499;

      message.user.settings.premium = true;

      message.user.stock.status = "Premium";

      message.user.limit.nicklimit = 32;

      message.user.opit += 5000;

      message.user.level += 35;

      message.user.bilet += 5;

      message.user.limit.banklimit = 200000000000000;

      message.user.limit.farmlimit = 5000;

      message.user.limit.videocardlimit = 75;

      message.user.limit.playerlimit = 200000000000000;

      message.user.limit.sent = 0;

      message.user.maxenergy = 30;



      return message.send(`▶️ Успешная покупка! -1.499 ЧакоРуб 💰\n🎉 Поздравляем, Вы приобрели статус «PREMIUM»! 🎊\n\n💬 Ознакомиться со списком всех доступных команд можно по команде «Premium help» 🤗`);

    }
  }

});



cmd.hear(/^(?:ЧакоРуб 3)$/i, async (message, bot) => {
  if (message.chat.type === 0) {


    if (1149 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);

    if (message.user.settings.vip > false) return bot(`у вас уже имеется статус [VIP]. ✅`);

    if (message.user.settings.premium || message.user.settings.titan) {

      message.user.settings.vip = true;

      message.user.rub -= 1149;

      return message.send(`▶️ Успешная покупка! -1.149 ЧакоРуб 💰\n🎉 Поздравляем, Вы приобрели статус «VIP»! 🎊\n\n💬 Ознакомиться со списком всех доступных команд можно по команде «VIP help» 🤗`);

    } else if (message.user.settings.vip <= message.user.rub) {

      message.user.rub -= 1149;

      message.user.settings.vip = true;

      message.user.stock.status = 'VIP';

      message.user.limit.nicklimit = 21;

      message.user.level += 5;

      message.user.bilet += 2;

      message.user.limit.banklimit = 100000000000000;

      message.user.limit.farmlimit = 3000;

      message.user.limit.videocardlimit = 50;

      message.user.limit.playerlimit = 100000000000000;

      message.user.limit.sent = 0;

      message.user.maxenergy = 20;



      return message.send(`▶️ Успешная покупка! -1.149 ЧакоРуб 💰\n🎉 Поздравляем, Вы приобрели статус «VIP»! 🎊\n\n💬 Ознакомиться со списком всех доступных команд можно по команде «VIP help» 🤗`);

    }
  }

});

cmd.hear(/^(?:ЧакоРуб 4)$/i, async (message, bot) => {
  if (message.chat.type === 0) {

    if (150 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);

    message.user.c3 += 1

    message.user.rub -= 150

    return message.send(`▶️ Успешная покупка! -150 ЧакоРуб 💰\n\n💬 Донат-кейс уже начислен на Ваш аккаунт. 📦`);
  }
});



cmd.hear(/^(?:ЧакоРуб 5)$/i, async (message, bot) => {

  if (message.chat.type === 0) {

    if (149 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);



    message.user.rub -= 149;

    message.user.balance += 150000000000000;



    return message.send(`▶️ Успешная покупка! -149 ЧакоРуб 💰\n\n💵 +150.000.000.000.000$ уже начислены на Ваш баланс! 🎉`);
  }
});

cmd.hear(/^(?:ЧакоРуб 6)$/i, async (message, bot) => {

  if (message.chat.type === 0) {

    if (299 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);



    message.user.rub -= 299;

    message.user.balance += 200000000000000;



    return message.send(`▶️ Успешная покупка! -299 ЧакоРуб 💰\n\n💵 +200.000.000.000.000$ уже начислены на Ваш баланс! 🎉`);
  }
});

cmd.hear(/^(?:ЧакоРуб 7)$/i, async (message, bot) => {
  if (message.chat.type === 0) {


    if (100 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);



    message.user.rub -= 100;

    message.user.balance += 200000000000;



    return message.send(`▶️ Успешная покупка! -100 ЧакоРуб 💰\n\n💵 +200.000.000.000$ уже начислены на Ваш баланс! 🎉`);
  }
});

cmd.hear(/^(?:ЧакоРуб 8)$/i, async (message, bot) => {
  if (message.chat.type === 0) {


    if (20 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);



    message.user.rub -= 20;

    message.user.balance += 450000000000;



    return message.send(`▶️ Успешная покупка! -20 ЧакоРуб 💰\n\n💵 +450.000.000.000$ уже начислены на Ваш баланс! 🎉`);
  }
});



cmd.hear(/^(?:ЧакоРуб 9)$/i, async (message, bot) => {
  if (message.chat.type === 0) {


    if (15 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);



    message.user.rub -= 15;

    message.user.balance += 150000000000;



    return message.send(`▶️ Успешная покупка! -15 ЧакоРуб 💰\n\n💵 +150.000.000.000$ уже начислены на Ваш баланс! 🎉`);
  }
});



cmd.hear(/^(?:ЧакоРуб 10)$/i, async (message, bot) => {
  if (message.chat.type === 0) {


    if (10 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);



    message.user.rub -= 10;

    message.user.balance += 50000000000;



    return message.send(`▶️ Успешная покупка! -10 ЧакоРуб 💰\n\n💵 +50.000.000.000$ уже начислены на Ваш баланс! 🎉`);
  }
});



cmd.hear(/^(?:ЧакоРуб 11)$/i, async (message, bot) => {
  if (message.chat.type === 0) {


    if (5 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);



    message.user.rub -= 5;

    message.user.balance += 15000000000;



    return message.send(`▶️ Успешная покупка! -5 ЧакоРуб 💰\n\n💵 +15.000.000.000$ уже начислены на Ваш баланс! 🎉`);
  }
});



cmd.hear(/^(?:ЧакоРуб 12)$/i, async (message, bot) => {
  if (message.chat.type === 0) {


    if (3 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);



    message.user.rub -= 3;

    message.user.balance += 5000000000;



    return message.send(`▶️ Успешная покупка! -3 ЧакоРуб 💰\n\n💵 +5.000.000.000$ уже начислены на Ваш баланс! 🎉`);
  }
});



cmd.hear(/^(?:ЧакоРуб 13)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (2999 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);

    if (message.user.business.length >= 3) return bot(`у вас уже есть 3 бизнеса`);



    message.user.rub -= 2999;

    message.user.business2.push({

      "id": 16,

      "upgrade": 1,

      "workers": 7500,

      "moneys": 0

    });



    return message.send(`▶️ Успешная покупка! -2999 ЧакоРуб 💰\n\n🎥 Бизнес «Киностудия по всему миру» выдана на Ваш аккаунт! 🎉`);
  }
});



cmd.hear(/^(?:ЧакоРуб 14)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (14 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);

    if (message.user.nicklimit > 31) return bot(`у вас уже имеется данный товар. ✅`);



    message.user.rub -= 14;

    message.user.nicklimit = 32;



    return message.send(`▶️ Успешная покупка! -14 ЧакоРуб 💰\n\n💬 Вы приобрели длинный ник-нейм, теперь его длина составляет 32 символа. 🔥`);
  }
});



cmd.hear(/^(?:ЧакоРуб 15)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.stars5) return bot(`Вы уже купили данную звезду ❌`);

    if (message.user.rub >= 15000) {

      message.user.stars5 = true;

      message.user.rub -= 15000;

      return message.send(`▶️ Успешная покупка! -15.000 ЧакоРуб 💰\n\n⭐ Звезда «Донатный гигант» выдана на Ваш аккаунт! 🎉`);

    } else {

      return bot(`недостаточно Чако-рублей. ⛔`);

    }


  }
});

cmd.hear(/^(?:ЧакоРуб 16)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (25000 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);



    message.user.rub -= 25000;

    message.user.settings.titan = true;

    message.user.limit.nicklimit = 48;

    message.user.level += 50;

    message.user.opit += 50000;

    message.user.limit.banklimit = 500000000000000;

    message.user.limit.farmlimit = 10000;

    message.user.limit.playerlimit = 300000000000000;

    message.user.limit.sent = 0;

    message.user.maxenergy = 100;



    return message.send(`▶️ Успешная покупка! -25.000 ЧакоРуб 💰\n🎉 Поздравляем, Вы приобрели статус «TITAN»! 🎊\n\n💬 Ознакомиться со списком всех доступных команд можно по команде «TITAN help» 🤗`);
  }
});

cmd.hear(/^(?:ЧакоРуб 17)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (250 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);

    message.user.possilka1 += 1;

    message.user.rub -= 250;

    return message.send(`▶️ Успешная покупка! -250 ЧакоРуб 💰\n\n📦 Денежная посылка уже выдана на Ваш аккаунт. Открыть: «посылка открыть 1» 🎉`);
  }
});

cmd.hear(/^(?:ЧакоРуб 18)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (1000 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);

    message.user.possilka2 += 1;

    message.user.rub -= 1000;

    return message.send(`▶️ Успешная покупка! -1000 ЧакоРуб 💰\n\n📦 Элитная посылка уже выдана на Ваш аккаунт. Открыть: «посылка открыть 2» 🎉`);
  }
});

cmd.hear(/^(?:ЧакоРуб 19)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (5000 > message.user.rub) return bot(`недостаточно Чако-рублей. ⛔`);

    message.user.possilka3 += 1;

    message.user.rub -= 5000;

    return message.send(`▶️ Успешная покупка! -5000 ЧакоРуб 💰\n\n📦 Премиум посылка уже выдана на Ваш аккаунт. Открыть: «посылка открыть 3» 🎉`);
  }
});
cmd.hear(/^(?:📈 Обмен|Обмен)$/i, async (message, bot) => {
  
  await bot(`💰 Обменник GB

💱 Валюта

1⃣ 80.000 GB ➜ 70.000.000.000.000 $
2⃣ 150.000 GB ➜ 150.000.000.000.000 $

🎁 Кейсы

3⃣ 50.000 GB ➜ 1 донат кейс
4⃣ 100.000 GB ➜ Случайный кейс
5⃣ 150.000 GB ➜ 5 премиум кейсов

💵 Донат – Рубли

6⃣ 100.000 GB ➜ 10 рублей
7⃣ 500.000 GB ➜ 60 рублей
8⃣ 1.000.000 GB ➜ 110 рублей

🌟 Статусы

9⃣ 700.000 GB ➜ Premium
1⃣0⃣ 1.500.000 GB ➜ TITAN

💳 Обмен на GB

1⃣1⃣ 25.000.000.000.000 $ ➜ 5.000 GB
1⃣2⃣ 100.000.000.000.000 $ ➜ 20.000 GB
1⃣3⃣ 1000 ЧакоРуб ➜ 10.000 GB
1⃣4⃣ 10 билетов ➜ 15.000 GB

📊 Ваш баланс валют:

💰 Баланс: ${utils.sp(message.user.balance)} $

💸 Баланс: ${utils.sp(message.user.rubli)} рублей

🎟️ Баланс: ${utils.sp(message.user.bilet)} билетов

💸 Баланс: ${utils.sp(message.user.rub)} ЧакоРубов

💾 Баланс: ${utils.sp(message.user.balance2)} GB

🛒 Для покупки введите "Обмен [номер]"`)
})

cmd.hear(/^(?:Обмен 1)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (80000 > message.user.balance2) return bot(`недостаточно GB. ⛔`);

    message.user.balance += 70000000000000;

    message.user.balance2 -= 80000;

    return message.send(`▶️ Успешная покупка! -80.000 GB 💰\n\n📦 70.000.000.000.000 $ уже выданы на Ваш аккаунт.🎉`);
  }
});

cmd.hear(/^(?:Обмен 2)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (150000 > message.user.balance2) return bot(`недостаточно GB. ⛔`);

    message.user.balance += 150000000000000;

    message.user.balance2 -= 150000;

    return message.send(`▶️ Успешная покупка! -150.000 GB 💰\n\n📦 150.000.000.000.000 $ уже выданы на Ваш аккаунт.🎉`);
  }
});

cmd.hear(/^(?:Обмен 3)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (50000 > message.user.balance2) return bot(`недостаточно GB. ⛔`);

    message.user.c3 += 1;

    message.user.balance2 -= 50000;

    return message.send(`▶️ Успешная покупка! -50.000 GB 💰\n\n📦 донат-кейс уже выдан на Ваш аккаунт.🎉`);
  }
});

cmd.hear(/^(?:Обмен 4)$/i, async (message, bot) => {
  if (message.chat.type === 0) {

    if (100000 > message.user.balance2) return bot(`Недостаточно GB. ⛔`);


    const cases = [
      { name: 'Обычный Кейс', id: 'c1' },
      { name: 'Золотой Кейс', id: 'c2' },
      { name: 'Донат Кейс', id: 'c3' },
      { name: 'Гоночный Кейс', id: 'c4' },
      { name: 'Halloween Кейс', id: 'c5' },
      { name: 'Секретный Кейс', id: 'c6' },
      { name: 'Автозвук Кейс', id: 'c7' },
      { name: 'Новогодний Кейс', id: 'c8' },
      { name: 'Премиум Кейс', id: 'c9' },
      { name: 'Ультра Кейс', id: 'c10' },
    ];


    const randomCase = cases[Math.floor(Math.random() * cases.length)];

    message.user.balance2 -= 100000; 

    if (randomCase.id === 'c1') {
      message.user.c1 += 1;
    } else if (randomCase.id === 'c2') {
      message.user.c2 += 1;
    } else if (randomCase.id === 'c3') {
      message.user.c3 += 1;
    } else if (randomCase.id === 'c4') {
      message.user.c4 += 1;
    } else if (randomCase.id === 'c5') {
      message.user.c5 += 1;
    } else if (randomCase.id === 'c6') {
      message.user.c6 += 1;
    } else if (randomCase.id === 'c7') {
      message.user.c7 += 1;
    } else if (randomCase.id === 'c8') {
      message.user.c8 += 1;
    } else if (randomCase.id === 'c9') {
      message.user.c9 += 1;
    } else if (randomCase.id === 'c10') {
      message.user.c10 += 1;
    }

    // Отправляем сообщение с информацией о кейсе
    return message.send(`▶️ Успешная покупка! -100.000 GB 💰\n\n📦 Вы получили: ${randomCase.name} уже выдан на Ваш аккаунт.🎉`);
  }
});

cmd.hear(/^(?:Обмен 5)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (150000 > message.user.balance2) return bot(`недостаточно GB. ⛔`);

    message.user.c9 += 5;

    message.user.balance2 -= 150000;

    return message.send(`▶️ Успешная покупка! -150.000 GB 💰\n\n📦 5 премиум-кейс уже выданы на Ваш аккаунт.🎉`);
  }
});

cmd.hear(/^(?:Обмен 6)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (100000 > message.user.balance2) return bot(`недостаточно GB. ⛔`);

    message.user.rubli += 10;

    message.user.balance2 -= 100000;

    return message.send(`▶️ Успешная покупка! -100.000 GB 💰\n\n📦 10 донат-рублей уже выданы на Ваш аккаунт.🎉`);
  }
});

cmd.hear(/^(?:Обмен 7)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (500000 > message.user.balance2) return bot(`недостаточно GB. ⛔`);

    message.user.rubli += 60;

    message.user.balance2 -= 500000;

    return message.send(`▶️ Успешная покупка! -500.000 GB 💰\n\n📦 60 донат-рублей уже выданы на Ваш аккаунт.🎉`);
  }
});

cmd.hear(/^(?:Обмен 8)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (1000000 > message.user.balance2) return bot(`недостаточно GB. ⛔`);

    message.user.rubli += 110;

    message.user.balance2 -= 1000000;

    return message.send(`▶️ Успешная покупка! -1.000.000 GB 💰\n\n📦 110 донат-рублей уже выданы на Ваш аккаунт.🎉`);
  }
});

cmd.hear(/^(?:Обмен 9)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.settings.vip) {
      return bot(`У вас уже есть VIP-привилегия. 🏆`);
    }

    if (700000 > message.user.balance2) {
      return bot(`Недостаточно GB. ⛔`);
    }

    message.user.settings.vip = true;
    message.user.balance2 -= 700000;

    return message.send(`▶️ Успешная покупка! -700.000 GB 💰\n\n📦 VIP уже выдан на Ваш аккаунт. 🎉`);
  }
});

cmd.hear(/^(?:Обмен 10)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (message.user.settings.titan) {
      return bot(`У вас уже есть TITAN-привилегия. 🏆`);
    }

    if (1500000 > message.user.balance2) {
      return bot(`Недостаточно GB. ⛔`);
    }

    message.user.settings.titan = true;
    message.user.balance2 -= 1500000;

    return message.send(`▶️ Успешная покупка! -1.500.000 GB 💰\n\n📦 TITAN уже выдан на Ваш аккаунт. 🎉`);
  }
});

cmd.hear(/^(?:Обмен 11)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (25000000000000> message.user.balance) return bot(`недостаточно $. ⛔`);

    message.user.balance2 += 5000;

    message.user.balance -= 25000000000000;

    return message.send(`▶️ Успешная покупка! -25.000.000.000.000 $ 💰\n\n📦 5.000 GB уже выданы на Ваш аккаунт.🎉`);
  }
});

cmd.hear(/^(?:Обмен 12)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (100000000000000 > message.user.balance) return bot(`недостаточно $. ⛔`);

    message.user.balance2 += 20000;

    message.user.balance -= 100000000000000;

    return message.send(`▶️ Успешная покупка! -100.000.000.000.000 $ 💰\n\n📦 20.000 GB уже выданы на Ваш аккаунт.🎉`);
  }
});

cmd.hear(/^(?:Обмен 13)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (1000 > message.user.rub) return bot(`недостаточно ЧакоРуб. ⛔`);

    message.user.balance2 += 10000;

    message.user.rub -= 1000;

    return message.send(`▶️ Успешная покупка! -1.000 ЧакоРуб 💰\n\n📦 10.000 GB уже выданы на Ваш аккаунт.🎉`);
  }
});

cmd.hear(/^(?:Обмен 14)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    if (10 > message.user.bilet) return bot(`недостаточно билетов. ⛔`);

    message.user.balance2 += 15000;

    message.user.bilet -= 10;

    return message.send(`▶️ Успешная покупка! -10 билетов 💰\n\n📦 15.000 GB уже выданы на Ваш аккаунт.🎉`);
  }
});


module.exports = commands;
