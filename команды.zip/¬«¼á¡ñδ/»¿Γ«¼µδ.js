let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

let pets = require('../spisok/питомцы.js')
let pets2 = require('../spisok/питомцы2.js')
let pets3 = require('../spisok/питомцы3.js')
let petsupd = require('../spisok/питомцыул.js')


function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });


cmd.hear(
  /^(?:питомцы|🦊 Питомцы|@club223500959 🦊 Питомцы)\s?([0-9]+)?$/i,
  async (message, bot) => {
    if (!message.args[1])
      return bot(`питомцы:
🐠 1. Рыбка (${utils.sp(pets.find((x) => x.id === Number(1)).cost)}$)
🐢 2. Черепашка (${utils.sp(pets.find((x) => x.id === Number(2)).cost)}$)
🦆 3. Утка (${utils.sp(pets.find((x) => x.id === Number(3)).cost)}$)
🐷 4. Свинья (${utils.sp(pets.find((x) => x.id === Number(4)).cost)}$)
🦘 5. Кенгуру (${utils.sp(pets.find((x) => x.id === Number(5)).cost)}$)
🐶 6. Собака (${utils.sp(pets.find((x) => x.id === Number(6)).cost)}$)
🐼 7. Панда (${utils.sp(pets.find((x) => x.id === Number(7)).cost)}$)
🦖 8. Динозавр (${utils.sp(pets.find((x) => x.id === Number(8)).cost)}$)
🐝 9. Пчелка (${utils.sp(
        pets.find((x) => x.id === Number(9)).cost
      )} SpringCoins ☣)
🐋 10. Кит (${utils.sp(
        pets.find((x) => x.id === Number(10)).cost
      )} SpringCoins ☣)

🛒 Для приобретения введите «Питомцы [номер]»`);

    const sell = pets.find((x) => x.id === Number(message.args[1]));

    if (!sell) return;

    if (message.user.misc.pet) return bot(`у Вас уже есть питомец.`);

    if (message.args[1] < 1 || message.args[1] > 10)
      return bot("Неверный номер питомца.");

    if (message.args[1] < 9) {
      if (message.user.balance < sell.cost)
        return bot(
          `у Вас недостаточно денег на балансе!\n\n🐶 Стоимость питомца: ${utils.sp(
            sell.cost
          )}$\n💰 Ваш баланс: ${utils.sp(message.user.balance)}$`
        );
      else if (message.user.balance >= sell.cost) {
        message.user.balance -= sell.cost;

        message.user.misc.pet = sell.id;

        message.user.pet.lvl += 1;
      }
    }

    if (message.args[1] > 8) {
      if (message.user.sprcoin < sell.cost)
        return bot(
          `вам нужно ${utils.sp(sell.cost)} SpringCoins☣ для покупки.`
        );
      else if (message.user.sprcoin >= sell.cost) {
        message.user.sprcoin -= sell.cost;

        message.user.misc.pet = sell.id;

        message.user.pet.lvl += 1;
      }
    }

    const pet = pets.find((x) => x.id === message.user.misc.pet);

    return bot(
      `вы приобрели питомца «${sell.name}» за ${utils.sp(
        sell.cost
      )}$ 💵\n\n〽️ Прокачивайте своего питомца и отправляйте на прогулку, чтобы он приносил ещё больше денег! ${pet.ico
      }`
    );
  }
);

cmd.hear(/^(?:питомец)$/i, async (message, bot) => {
  if (message.user.misc.pet < 1) return bot(`у Вас нет питомца.`);
  else {
    const pet = pets.find((x) => x.id === message.user.misc.pet);

    if (pets[message.user.misc.pet - 1].id > 19) {
      return bot(
        `информация:
${pet.ico} Питомец: «${pets[message.user.misc.pet - 1].name}»
💳 Стоимость улучшения: ${utils.sp(
          petsupd[message.user.misc.pet - 1].cost * message.user.pet.lvl
        )} SpringCoins ☣️
🌟 Уровень: ${message.user.pet.lvl}`,
        { attachment: pets[message.user.misc.pet - 1].photo }
      );
    }

    return bot(
      `информация о Вашем питомце: ❄️
${pet.ico} Питомец: «${pets[message.user.misc.pet - 1].name}» 🔥
➖➖➖➖➖
💵 Стоимость улучшения: ${utils.sp(
        petsupd[message.user.misc.pet - 1].cost * message.user.pet.lvl
      )}$
〽️ Уровень: ${utils.sp(message.user.pet.lvl)}`,
      { attachment: pets[message.user.misc.pet - 1].photo }
    );
  }
});

cmd.hear(/^(?:питомец 2)$/i, async (message, bot) => {
  if (message.user.misc.pet2 < 1) return bot(`у Вас нет питомца.`);
  else {
    const pet2 = pets2.find((x) => x.id === message.user.misc.pet2);

    return bot(
      `информация:

${pet2.ico} Питомец: «${pets2[message.user.misc.pet2 - 1].name}»

`,
      { attachment: pets2[message.user.misc.pet2 - 1].photo }
    );
  }
});

cmd.hear(/^(?:питомец 3)$/i, async (message, bot) => {
  if (message.user.misc.pet3 < 1) return bot(`у Вас нет питомца.`);
  else {
    const pet3 = pets3.find((x) => x.id === message.user.misc.pet3);

    return bot(
      `информация:

${pet3.ico} Питомец: «${pets3[message.user.misc.pet3 - 1].name}»

`,
      { attachment: pets3[message.user.misc.pet3 - 1].photo }
    );
  }
});

cmd.hear(/^(?:питомец улучшить)$/i, async (message, bot) => {
  let lvlpoupd;
  let priceupd;
  if (message.user.inf === true) return bot(`Выключите безлимитный баланс`);

  if (message.user.misc.pet < 1)
    return bot(
      `у Вас нет питомца! 😿\n\n▶️ Просмотреть список продаваемых питомцев можно написав команду «Питомцы» 🛒`
    );
  else {
    const pet = pets.find((x) => x.id === message.user.misc.pet);

    if (pets[message.user.misc.pet - 1].id === 20) {
      if (
        message.user.sprcoin <
        petsupd[message.user.misc.pet - 1].cost * message.user.pet.lvl
      )
        return bot(`недостаточно SpringCoins ☣️`);

      if (message.user.pet.lvl > 14)
        return bot(`ваш питомец максимально улучшен! ${pet.ico}`);

      priceupd = petsupd[message.user.misc.pet - 1].cost * message.user.pet.lvl;

      lvlpoupd = message.user.pet.lvl + 1;

      message.user.sprcoin -= priceupd;

      message.user.pet.lvl += 1;

      return bot(`питомец был прокачен до ${lvlpoupd} уровня за ${utils.sp(
        priceupd
      )} SpringCoins ☣️
	Баланс SpringCoins: ${utils.sp(message.user.sprcoin)} ☣️`);
    }

    if (
      message.user.balance <
      petsupd[message.user.misc.pet - 1].cost * message.user.pet.lvl
    )
      return bot(
        `у Вас недостаточно денег! ❌\n\n▶️ Стоимость улучшения: ${utils.sp(
          petsupd[message.user.misc.pet - 1].cost * message.user.pet.lvl
        )}$ 💵\n💰 Ваш баланс: ${utils.sp(message.user.balance)}$`
      );

    if (message.user.pet.lvl > 14)
      return bot(`ваш питомец максимально улучшен! 😸`);

    priceupd = petsupd[message.user.misc.pet - 1].cost * message.user.pet.lvl;

    lvlpoupd = message.user.pet.lvl + 1;

    message.user.balance -= priceupd;

    message.user.pet.lvl += 1;

    return bot(`питомец был прокачен до ${lvlpoupd} уровня за ${utils.sp(
      priceupd
    )}$ 💵
▶️ Ваш баланс: ${utils.sp(message.user.balance)}$ 💰`);
  }
});

cmd.hear(/^(?:питомец 2 поход)$/i, async (message, bot) => {
  const pet = pets2.find((x) => x.id === message.user.misc.pet2);

  const earn = utils.random(pet.min, pet.max);

  if (message.user.timers.poxod2 > Date.now())
    return bot(
      `вы сможете отправить питомца в поход через ${unixStampLefta(
        message.user.timers.poxod2 - Date.now()
      )} Ваш питомец довольно сильно устал!`
    );

  message.user.sprcoin += earn;

  message.user.timers.poxod2 = Date.now() + 300000;

  return bot(`ваш питомец нашёл в походе ${utils.sp(earn)} SpringCoins ☣.`);
});

cmd.hear(/^(?:питомец 3 поход)$/i, async (message, bot) => {
  const pet = pets3.find((x) => x.id === message.user.misc.pet3);

  const earn = utils.random(pet.min, pet.max);

  if (message.user.timers.poxod3 > Date.now())
    return bot(
      `вы сможете отправить питомца в поход через ${unixStampLefta(
        message.user.timers.poxod3 - Date.now()
      )} Ваш питомец довольно сильно устал!`
    );

  message.user.sprcoin += earn;

  message.user.timers.poxod3 = Date.now() + 300000;

  return bot(`ваш питомец нашёл в походе ${utils.sp(earn)} SpringCoins ☣.`);
});

cmd.hear(/^(?:питомец поход)$/i, async (message, bot) => {
  if (message.user.misc.pet < 1) return bot(`у Вас нет питомца.`);
  else {
    if (pets[message.user.misc.pet - 1].id === 20) {
      let prize = utils.pick([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);

      if (message.user.timers.poxod > Date.now())
        return bot(
          `вы сможете отправить питомца в поход через ${unixStampLefta(
            message.user.timers.poxod - Date.now()
          )} Ваш питомец довольно сильно устал!`
        );

      message.user.timers.poxod = Date.now() + 3600000;

      const pet = pets.find((x) => x.id === message.user.misc.pet);

      const earn = utils.random(pet.min, pet.max) * message.user.pet.lvl;

      if (prize === 1) {
        message.user.sprcoin += earn;

        return bot(
          `ваш питомец нашёл в походе ${utils.sp(
            earn
          )} SpringCoins ☣️. Улучшайте своего питомца!`
        );
      }

      if (prize === 2) {
        message.user.sprcoin += earn;

        return bot(
          `ваш питомец нашёл в походе ${utils.sp(
            earn
          )} SpringCoins ☣️. Улучшайте своего питомца!`
        );
      }

      if (prize === 3) {
        message.user.sprcoin += earn;

        return bot(
          `ваш питомец нашёл в походе ${utils.sp(
            earn
          )} SpringCoins ☣️. Улучшайте своего питомца!`
        );
      }

      if (prize === 4) {
        message.user.sprcoin += earn;

        return bot(
          `ваш питомец нашёл в походе ${utils.sp(
            earn
          )} SpringCoins ☣️. Улучшайте своего питомца!`
        );
      }

      if (prize === 5) {
        message.user.sprcoin += earn;

        return bot(
          `ваш питомец нашёл в походе ${utils.sp(
            earn
          )} SpringCoins ☣️. Улучшайте своего питомца!`
        );
      }

      if (prize === 6) {
        message.user.sprcoin += earn;

        return bot(`ваш питомец нашёл в походе ${utils.sp(
          earn
        )} SpringCoins ☣️. Улучшайте своего питомца!

		`);
      }

      if (prize === 7) {
        message.user.sprcoin += earn;

        return bot(
          `ваш питомец нашёл в походе ${utils.sp(
            earn
          )} SpringCoins ☣️. Улучшайте своего питомца!`
        );
      }

      if (prize === 8) {
        message.user.sprcoin += earn;

        return bot(
          `ваш питомец нашёл в походе ${utils.sp(
            earn
          )} SpringCoins ☣️. Улучшайте своего питомца!`
        );
      }

      if (prize === 9) {
        message.user.sprcoin += earn;

        return bot(
          `ваш питомец нашёл в походе ${utils.sp(
            earn
          )} SpringCoins ☣️. Улучшайте своего питомца!`
        );
      }

      if (prize === 10) {
        message.user.sprcoin += earn;

        return bot(
          `ваш питомец нашёл в походе ${utils.sp(
            earn
          )} SpringCoins ☣️. Улучшайте своего питомца!`
        );
      }
    }

    let prize = utils.pick([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);

    if (message.user.timers.poxod > Date.now())
      return bot(
        `вы сможете отправить питомца в поход через ${unixStampLefta(
          message.user.timers.poxod - Date.now()
        )} Ваш питомец довольно сильно устал!`
      );

    const pet = pets.find((x) => x.id === message.user.misc.pet);

    const earn = utils.random(pet.min, pet.max) * message.user.pet.lvl;

    message.user.timers.poxod = Date.now() + 3600000;

    if (prize === 1) {
      message.user.balance += earn;

      return bot(
        `ваш питомец нашёл в походе ${utils.sp(
          earn
        )}$. Улучшайте своего питомца!`
      );
    }

    if (prize === 2) {
      message.user.balance += earn;

      return bot(
        `ваш питомец нашёл в походе ${utils.sp(
          earn
        )}$. Улучшайте своего питомца!`
      );
    }

    if (prize === 3) {
      message.user.balance += earn;

      return bot(
        `ваш питомец нашёл в походе ${utils.sp(
          earn
        )}$. Улучшайте своего питомца!`
      );
    }

    if (prize === 4) {
      message.user.balance += earn;

      return bot(
        `ваш питомец нашёл в походе ${utils.sp(
          earn
        )}$. Улучшайте своего питомца!`
      );
    }

    if (prize === 5) {
      message.user.balance += earn;

      return bot(
        `ваш питомец нашёл в походе ${utils.sp(
          earn
        )}$. Улучшайте своего питомца!`
      );
    }

    if (prize === 6) {
      message.user.balance += earn;

      return bot(`ваш питомец нашёл в походе ${utils.sp(
        earn
      )}$. Улучшайте своего питомца!

		`);
    }

    if (prize === 7) {
      message.user.balance += earn;

      return bot(
        `ваш питомец нашёл в походе ${utils.sp(
          earn
        )}$. Улучшайте своего питомца!`
      );
    }

    if (prize === 8) {
      message.user.balance += earn;

      return bot(
        `ваш питомец нашёл в походе ${utils.sp(
          earn
        )}$. Улучшайте своего питомца!`
      );
    }

    if (prize === 9) {
      message.user.balance += earn;

      return bot(
        `ваш питомец нашёл в походе ${utils.sp(
          earn
        )}$. Улучшайте своего питомца!`
      );
    }

    if (prize === 10) {
      message.user.balance += earn;

      return bot(
        `ваш питомец нашёл в походе ${utils.sp(
          earn
        )}$. Улучшайте своего питомца!`
      );
    }
  }
});


module.exports = commands;
