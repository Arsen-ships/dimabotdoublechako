let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:VIP help)$/i, async (message, bot) => {
  if (message.user.settings.vip !== true) return;

 

  return bot(`Преимущества VIP игроков:

🔥 Увеличен лимит передачи до 100.000.000.000.000$.
💲 Максимальная сумма вклада в банке 100.000.000.000.000$.
👑 «VIP» отметка в профиле.
🔋 Увеличен лимит ферм до 3000.
⚡ Увеличена максимальная энергия до 20.
🔱 Увеличен ежедневный бонус (X2).
🔱 Ускорено получение новых работ.
⭐ Ежедневный VIP бонус [Бонус VIP].
⭐ Повышен шанс в казино.
✒ Возможность ставить ник на 5 символов длиннее.

▶️ При возникновении проблемы напишите в репорт.`);
});

cmd.hear(/^(?:Premium help)$/i, async (message, bot) => {
  if (message.user.settings.premium !== true) return;



  return bot(`Преимущества Premium игроков:



🔥 Увеличен лимит передачи до 200.000.000.000.000$.
💰 Максимальная сумма вклада в банке 200.000.000.000.000$.
👑 «PREMIUM» отметка в профиле.
💰 Ежедневная выдача валюты (150млрд$).
🔋 Увеличен лимит ферм до 5000.
⚡ Увеличена максимальная энергия до 30.
👤 Возможность просматривать чужие профили .
⭐ Ежедневный Premium бонус [Бонус Premium].
⭐ Повышен шанс в казино.
💎 Возможность копать алмазы.
✒ Возможность ставить длинный ник.

▶️ При возникновении проблемы напишите в репорт.`);
});

cmd.hear(/^(?:Titan help)$/i, async (message, bot) => {
  if (message.user.settings.titan !== true) return;



  return bot(`Преимущества TITAN игроков:

🔥 Увеличен лимит передачи до 300.000.000.000.000$.
💲 Максимальная сумма вклада в банке 500.000.000.000.000$.
⚙️ «TITAN» отметка в профиле.
🔋 Увеличен лимит ферм до 10000.
⚡ Увеличена максимальная энергия до 100.
⚡ Повышен уровень работы
👤 Возможность просматривать чужие профили .
⭐ Ежедневный Titan бонус [Бонус Titan].
⭐ Повышен шанс в казино
💎 Возможность открывать сразу до 10 кейсов(обычный,золотой,гоночный)
💎 Возможность копать материю.
✒ Возможность ставить длинный ник.

▶️ При возникновении проблемы напишите в репорт.`);
});
cmd.hear(/^(?:Imperator help)$/i, async (message, bot) => {
  if (message.user.settings.imperator !== true) return;



  return bot(`Преимущества Imperator игроков:

1️⃣ МЕГА-КРУТАЯ отметка в ПРОФИЛЕ.
2️⃣ Покупка титула бесплатно.
3️⃣ Безлимитный банк.
4️⃣ Кол-во ферм увеличено до 1.000.000.
5️⃣ Император бонус (падают даже донат-кейсы).
6️⃣ Увеличение кубков при победе в гонках, и т.п.
7️⃣ Уменьшение коммисии при продаже рейтинга
8️⃣ ФЕЙК АЙДИ!
9️⃣ Увеличены шансы в казино.

▶️ При возникновении проблемы напишите в репорт.`);
});
cmd.hear(/^(?:Бизнесмен помощь|Бизнесмен help)$/i, async (message, bot) => {
  if (message.user.settings.busi !== true) return;

  

  return bot(`🤵 Преимущества «БИЗНЕСМЕНА»:

• 🆙 Лимит БИЗНЕСОВ увеличен до 5!
• 🕳 Выдача ПРЕМИУМ'а игрокам НАВСЕГДА! [1 раз в неделю]
• 🔋 Лимит ферм увеличен до 150.000
• 🏦 Безлимитный банк

- Дополнительно:
📆 Вы получаете доступ к РАННЕМУ обновлению!
🦸‍♂ Вы получаете Анти-гет (его цена: 199₽, а в данной привилегии бесплатно)

▶️ При возникновении проблемы напишите в репорт.`);
});


module.exports = commands;
