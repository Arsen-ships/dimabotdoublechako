let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')
let chats = require('../database/chats.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};
const cars = require('../spisok/машины.js')
const autosounder = require('../spisok/autosounder.js')
const sound = require('../spisok/машина динамики.js')
const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:машины|🚗 Машины)\s?([0-9]+)?$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    let smileng = utils.pick([
      `🌷`,
      `🌸`,
      `🌹`,
      `🌺`,
      `🌼`,
      `💐`,
      `❤️`,
      `💓`,
      `💕`,
    ]);

    if (!message.args[1])
      return bot(`машины:

${message.user.transport.car === 1 ? "✔️" : "✖️"} 1. Самокат (${utils.sp(
        cars.find((x) => x.id === Number(1)).cost
      )}$)
${message.user.transport.car === 2 ? "✔️" : "✖️"} 2. Велосипед (${utils.sp(
        cars.find((x) => x.id === Number(2)).cost
      )}$)
${message.user.transport.car === 3 ? "✔️" : "✖️"} 3. Мопед (${utils.sp(
        cars.find((x) => x.id === Number(3)).cost
      )}$)
${message.user.transport.car === 4 ? "✔️" : "✖️"} 4. ВАЗ 2109 (${utils.sp(
        cars.find((x) => x.id === Number(4)).cost
      )}$)
${message.user.transport.car === 5 ? "✔️" : "✖️"} 5. Квадроцикл (${utils.sp(
        cars.find((x) => x.id === Number(5)).cost
      )}$)
${message.user.transport.car === 6 ? "✔️" : "✖️"} 6. Вездеход (${utils.sp(
        cars.find((x) => x.id === Number(6)).cost
      )}$)
${message.user.transport.car === 7 ? "✔️" : "✖️"} 7. Лада Xray (${utils.sp(
        cars.find((x) => x.id === Number(7)).cost
      )}$)
${message.user.transport.car === 8 ? "✔️" : "✖️"} 8. Toyota FT-HSi (${utils.sp(
        cars.find((x) => x.id === Number(8)).cost
      )}$)
${message.user.transport.car === 9 ? "✔️" : "✖️"} 9. Subaru WRX STI (${utils.sp(
        cars.find((x) => x.id === Number(9)).cost
      )}$)
${message.user.transport.car === 10 ? "✔️" : "✖️"
        } 10. Lamborghini Veneno (${utils.sp(
          cars.find((x) => x.id === Number(10)).cost
        )}$)
${message.user.transport.car === 11 ? "✔️" : "✖️"
        } 11. Yamaha YZF R6 (${utils.sp(cars.find((x) => x.id === Number(11)).cost)}$)
${message.user.transport.car === 12 ? "✔️" : "✖️"
        } 12. Ferrari LaFerrari (${utils.sp(
          cars.find((x) => x.id === Number(12)).cost
        )}$)
${message.user.transport.car === 13 ? "✔️" : "✖️"
        } 13. Koenigsegg Regera (${utils.sp(
          cars.find((x) => x.id === Number(13)).cost
        )}$)
${message.user.transport.car === 14 ? "✔️" : "✖️"} 14. Rolls-Royce (${utils.sp(
          cars.find((x) => x.id === Number(14)).cost
        )}$)
${message.user.transport.car === 15 ? "✔️" : "✖️"
        } 15. Tesla Cybertruck (${utils.sp(
          cars.find((x) => x.id === Number(15)).cost
        )}$)
${message.user.transport.car === 16 ? "✔️" : "✖️"
        } 16. Lamborghini Aventador SVJ (${utils.sp(
          cars.find((x) => x.id === Number(16)).cost
        )}$)
${message.user.transport.car === 17 ? "✔️" : "✖️"} 17. Портал (${utils.sp(
          cars.find((x) => x.id === Number(17)).cost
        )}$)
${message.user.transport.car === 18 ? "✔️" : "✖️"
        } 18. Bugatti La Voiture Noire [⭐ Экс.] (${utils.sp(
          cars.find((x) => x.id === Number(18)).cost
        )}$)

Для покупки введите "Машины [номер]"`);

    const sell = cars.find((x) => x.id === Number(message.args[1]));

    if (!sell) return;

    if (message.args[1] < 1 || message.args[1] >= 19)
      return bot("Неверный номер машины.");

    if (message.user.transport.car)
      return bot(
        `у вас уже есть машина (${cars[message.user.transport.car - 1].name
        }), введите "Продать машину"`
      );

    if (message.user.balance < sell.cost) return bot(`недостаточно денег`);
    else if (message.user.balance >= sell.cost) {
      message.user.balance -= sell.cost;

      message.user.transport.car = sell.id;

      return bot(
        `вы купили «${sell.name}» за ${utils.sp(sell.cost)}$ ${smileng}`
      );
    }
  }
});


cmd.hear(/^(?:автозвук)\s?([0-9]+)?$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    let smileng = utils.pick([
      `🌷`,
      `🌸`,
      `🌹`,
      `🌺`,
      `🌼`,
      `💐`,
      `❤️`,
      `💓`,
      `💕`,
    ]);

    if (!message.args[1])
      return bot(`Автозвук-Машины:

${message.user.autosound === 1 ? "✔️" : "✖️"} 1. ВАЗ-2112 (${utils.sp(
        autosounder.find((x) => x.id === Number(1)).cost
      )}$)
${message.user.autosound === 2 ? "✔️" : "✖️"} 2. ВАЗ-2114 (${utils.sp(
        autosounder.find((x) => x.id === Number(2)).cost
      )}$)
${message.user.autosound === 3 ? "✔️" : "✖️"} 3. VW-Golf 5 (${utils.sp(
        autosounder.find((x) => x.id === Number(3)).cost
      )}$)
${message.user.autosound === 4 ? "✔️" : "✖️"} 4. Ford-Focus 3 (${utils.sp(
        autosounder.find((x) => x.id === Number(4)).cost
      )}$)
${message.user.autosound === 5 ? "✔️" : "✖️"} 5. Opel-Astra GTS (${utils.sp(
        autosounder.find((x) => x.id === Number(5)).cost
      )}$)
${message.user.autosound === 6 ? "✔️" : "✖️"} 6. Audi Q7 (${utils.sp(
        autosounder.find((x) => x.id === Number(6)).cost
      )}$)
${message.user.autosound === 7 ? "✔️" : "✖️"
        } 7. Mercedes-Benz GLA 250 (${utils.sp(
          autosounder.find((x) => x.id === Number(7)).cost
        )}$)
${message.user.autosound === 8 ? "✔️" : "✖️"} 8. Volvo V60 (${utils.sp(
          autosounder.find((x) => x.id === Number(8)).cost
        )}$)
${message.user.autosound === 9 ? "✔️" : "✖️"} 9. Jaguar SportBrake (${utils.sp(
          autosounder.find((x) => x.id === Number(9)).cost
        )}$)
${message.user.autosound === 10 ? "✔️" : "✖️"} 10. Porshe Macan (${utils.sp(
          autosounder.find((x) => x.id === Number(10)).cost
        )}$)
${message.user.autosound === 11 ? "✔️" : "✖️"
        } 11. DeLorian Exclusive (${utils.sp(
          autosounder.find((x) => x.id === Number(11)).cost
        )}$)
${message.user.autosound === 12 ? "✔️" : "✖️"
        } 12. Cadillac Escalade 3 (${utils.sp(
          autosounder.find((x) => x.id === Number(12)).cost
        )}$)
${message.user.autosound === 13 ? "✔️" : "✖️"
        } 13. Mercedes-Benz G63 AMG (${utils.sp(
          autosounder.find((x) => x.id === Number(13)).cost
        )}$)
${message.user.autosound === 14 ? "✔️" : "✖️"
        } 14. Bentley Continental (${utils.sp(
          autosounder.find((x) => x.id === Number(14)).cost
        )}$)
${message.user.autosound === 15 ? "✔️" : "✖️"
        } 15. Mercedes-Benz Vision Gran Turismo (${utils.sp(
          autosounder.find((x) => x.id === Number(15)).cost
        )}$)

Для покупки введите "Автозвук [номер]"`);

    const sell = autosounder.find((x) => x.id === Number(message.args[1]));

    if (!sell) return;

    if (message.user.autosound)
      return bot(
        `у вас уже есть машина (${autosounder[message.user.autosound - 1].name
        }), введите "Продать автозвук" ${smileng}`
      );

    if (message.user.balance < sell.cost) return bot(`недостаточно денег`);
    else if (message.user.balance >= sell.cost) {
      message.user.balance -= sell.cost;

      message.user.autosound = sell.id;

      return bot(
        `вы купили «${sell.name}» за ${utils.sp(sell.cost)}$ ${smileng}`
      );
    }
  }
});

cmd.hear(/^(?:автозвук улучшить)\s?([0-9]+)?$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    let smileng = utils.pick([
      `🌷`,
      `🌸`,
      `🌹`,
      `🌺`,
      `🌼`,
      `💐`,
      `❤️`,
      `💓`,
      `💕`,
    ]);

    if (!message.args[1])
      return bot(`Автозвук-улучшения:

🔸 1. Батины динамики (5.000.000.000$) 10-20W
🔸 2. SWAT G410TS (25.000.000.000$) 20-40W
🔸 3. PionnerTX-302AS (50.000.000.000$) 40-80W
🔸 4. Alphard RTS-455T (100.000.000.000$) 80-160W
🔸 5. Bulava 250 HTS (250.000.000.000$) 160-320W
🔸 6. Machette RX-900 (500.000.000.000$) 320-640W
🔸 7. JBL EX-290 GLA 250 (1.000.000.000.000$) 640-960W
🔸 8. Bass Sound (5.000.000.000.000$) 960-1920W

Для покупки введите "Автозвук улучшить [номер]"

${smileng}`);

    const sell = sound.find((x) => x.id === Number(message.args[1]));

    if (!sell) return;

    if (message.user.balance < sell.cost) return bot(`недостаточно денег`);
    else if (message.user.balance >= sell.cost) {
      message.user.balance -= sell.cost;

      message.user.sound +=
        sell.id *
        utils.random(sell.min, sell.max) *
        autosounder[message.user.autosound - 1].bassmult;

      return bot(`вы купили «${sell.name}»за ${utils.sp(sell.cost)}$ ${smileng}`);
    }
  }
});

cmd.hear(/^(?:автозвук соревновани([eя]))$/i, async (message, bot) => {

  if (message.chat.type === 0) {
    if (!message.user.autosound)
      return bot(
        `у вас нет машины для участия в соревнованиях по автозвуку. Приобрести можно по команде «Автозвук [номер]»`
      )
    if (message.user.scar.gontime > Date.now())
      return bot(
        `передохните от автозвука ещё чуть-чуть! 😢\n\n⏳ Осталось ${unixStampLefta(
          message.user.scar.gontime - Date.now()
        )} до следующего использования автозвука. ❓`
      );

    if (message.user.sound <= 0)
      return bot(
        `у вас нет динамиков\n⏰ Приобретите в разделе "Автозвук улучшить"`
      );

    if (typeof message.user.questautosound === "number") {
      message.user.questautosound++;

      if (message.user.questautosound >= 5) {
        message.user.questautosound = true;

        await bot(
          `Поздравляем, Вы 5 раз поучаствовали в соревнованиях по автозвуку и получаете 📦 1 Донат-кейс.`
        );

        message.user.c3 += 1;
      }
    }

    if (
      typeof message.user.questautosound2 === "number" &&
      message.user.questallfucker === true
    ) {
      message.user.questautosound2++;

      if (message.user.questautosound2 >= 500) {
        message.user.questautosound2 = true;

        await bot(
          `Поздравляем, Вы 500 раз поучаствовали в соревнованиях по автозвуку и получаете 📦 2 Донат-кейса.`
        );

        message.user.c3 += 2;
      }
    }

    if (!message.isChat) {
      message.user.scar.gontime = Date.now() + 600000;
    } else {
      if (message.user.id >= 0) {
        message.user.scar.gontime = Date.now() + 480000;
      } else {
        message.user.scar.gontime = Date.now() + 600000;
      }
    }

    if (message.user.settings.topdon) {
      message.user.scar.gontime = Date.now() + 300000;
    }

    if (message.user.settings.king) {
      message.user.scar.gontime = Date.now() + 60000;
    }

    // if(utils.random(message.user.sound/2,message.user.sound*2)<= message.user.sound){

    const rand = utils.random(1, 4);

    if (rand === 1) {
      message.user.sound = Number(Math.floor(message.user.sound * 0.9 - 1));

      message.user.balance += 30000000000000;

      return bot(
        `Ух ты! 😨\n✅ Вы успешно заняли 1 место и заработали ЦЕЛЫХ 30.000.000.000.000$, но у вас сломалось 10% оборудования! ❓\n🏪 Приобретите новое в магазине`
      );
    }

    if (rand === 2) {
      const cases = utils.pick([0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0]);

      if (cases === 1) {
        message.user.c7++;

        message.user.sprcoin += 3;
      }

      if (cases === 1) {
        message.user.balance += 40000000000;

        message.user.soundrating += 1;

        return bot(
          `поздравляем, вы заняли первое место! 🥇\n\n💵 Заработано: 40.000.000.000$ 💰\n▫️Получен: Звуковой кубок 🏆\n🎶 +1 Автозвук кейс 📦\n+3 Spring Coin ☣️`
        );
      } else {
        message.user.balance += 50000000000;

        message.user.soundrating += 1;

        return bot(
          `поздравляем, вы заняли первое место! 🥇\n\n💵 Заработано: 50.000.000.000$ 💰\n▫️ Получен: Звуковой кубок 🏆`
        );
      }
    }

    if (rand === 3) {
      if (message.user.settings.imperator) {
        message.user.soundrating += 3;

        return bot(
          `поздравляем, вы заняли первое место! 🥇\n👑 Так как Вы император, Вы получили сразу 3 кубка`
        );
      } else {
        message.user.soundrating += 2;

        return bot(`поздравляем, вы заняли первое место и получили 2 кубка! 🥇`);
      }
    }

    if (rand === 4) {
      message.user.soundrating -= 1;

      return bot(`вы не пришли на соревнования и лишились одного кубка ❌😨`);
    }
  }
});

cmd.hear(/^(?:автозвук машина)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    let smileng = utils.pick([
      `🌷`,
      `🌸`,
      `🌹`,
      `🌺`,
      `🌼`,
      `💐`,
      `❤️`,
      `💓`,
      `💕`,
    ]);

    if (!message.user.autosound)
      return bot(
        `у вас нет машины для участвования в соревнаваниях по автозвуку. Приобрести по комманде "Автозвук [номер]" ${smileng}`
      );

    return bot(`ваш рейтинг: ${utils.sp(message.user.soundrating)}
🚗 ➖ Характеристики вашей машины:
™️ Название - «${autosounder[message.user.autosound - 1].name}»
🔊 Мощность - ${message.user.sound}W
${smileng}`);
  }
});

cmd.hear(/^(?:топ автозвук|🏆 топ автозвук)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    let top = [];

    double
      .filter((x) => x.bantop === false)
      .map((x) => {
        top.push({
          soundrating: x.soundrating,
          tag: x.tag,
          id: x.id,
          mention: x.mention,
        });
      });

    top.sort((a, b) => {
      return b.soundrating - a.soundrating;
    });

    let text = ``;

    const find = () => {
      let pos = 100;

      for (let i = 0; i < top.length; i++) {
        if (top[i].id === message.senderId) return (pos = i);
      }

      return pos;
    };

    for (let i = 0; i < 10; i++) {
      if (!top[i])
        return message.send(
          "👥 В боте должно зарегистрировано не менее 10 игроков!"
        );

      const user = top[i];

      text += `\n${i === 9 ? `&#128287;` : `${i + 1}&#8419;`} ${user.mention ? `@id${user.id} (${user.tag})` : `${user.tag}`
        } — 🏆${utils.sp(user.soundrating)}`;
    }

    return bot(
      `топ автозвука:${text}
➖➖➖➖➖➖➖➖
➡${utils.gi(find() + 1)} ${message.user.tag} — 🏆${utils.sp(
        message.user.soundrating
      )}`,

      {
        keyboard: JSON.stringify({
          inline: true,

          buttons: [
            [
              {
                action: {
                  type: "text",

                  payload: "{}",

                  label: "🏆 Топ игроков",
                },

                color: "positive",
              },

              {
                action: {
                  type: "text",

                  payload: "{}",

                  label: "🏆 Босс топ",
                },

                color: "negative",
              },
            ],
          ],
        }),
      }
    );
  }
});

cmd.hear(/^(?:🎫 машина госномер|машина госномер)$/i, async (message, bot) => {
  if (!message.user.transport.car) return bot(`у вас нет машины`);

  let n_1 = utils.pick([
    "А",
    "В",
    "Е",
    "К",
    "М",
    "Н",
    "О",
    "Р",
    "С",
    "Т",
    "У",
    "Х",
  ]);

  let n_2 = utils.random(0, 9);

  let n_3 = utils.random(0, 9);

  let n_4 = utils.random(0, 9);

  let n_5 = utils.pick([
    "А",
    "В",
    "Е",
    "К",
    "М",
    "Н",
    "О",
    "Р",
    "С",
    "Т",
    "У",
    "Х",
  ]);

  let n_6 = utils.pick([
    "А",
    "В",
    "Е",
    "К",
    "М",
    "Н",
    "О",
    "Р",
    "С",
    "Т",
    "У",
    "Х",
  ]);

  let n_7 = utils.pick(["777"]);

  if (message.user.balance < 30000000)
    return bot(`вам нужно 30.000.000$ для смены госномера.`);

  message.user.balance -= 30000000;

  message.user.scar.gosnomer = `${n_1}${n_2}${n_3}${n_4}${n_5}${n_6} ${n_7}`;

  let res = `${n_1}${n_2}${n_3}${n_4}${n_5}${n_6} ${n_7}`;

  return bot(
    `Вы поставили новый гос. номер на машину! ☃️
🚥 Номер: «${res}» 🎫
▶️ Стоимость обошлась в ${utils.sp(30000000)}$ 💵
🚗 Теперь эта машина будет ездить с такими номерами! 🚥`,

    {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",
                payload: "{}",
                label: "🎫 Машина госномер",
              },

              color: "default",
            },
          ],
        ],
      }),
    }
  );
});

cmd.hear(
  /^(?:сетномер)\s([0-9]+)\s([а-я])([0-9])([0-9])([0-9])([а-я])([а-я])$/i,
  async (message, bot) => {


    let res = `${message.args[2]}${message.args[3]}${message.args[4]}${message.args[5]}${message.args[6]}${message.args[7]} 777`;

    let text = res.toLowerCase();

    const b =
      /(й|ц|г|ш|щ|з|ъ|ф|ы|п|л|д|ж|э|я|ч|и|ь|б|ю|q|w|e|r|t|y|u|i|o|p|a|s|d|f|g|h|j|k|l|z|x|c|v|b|n|m:)/;

    if (b.test(text) === true)
      return bot(`некорректный номер!

✅Напишите номер по шаблону, например: «A123BC», используя только русские буквы.
➕ Примеры: А777АА, А123МР, Р777РР и др.

🔤 Список разрешенных букв: А, В, Е, К, М, Н, О, Р, С, Т, У, Х`);

    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока! ❌`);

    for (i in users) {
      if (users[i].scar.gosnomer.toLowerCase() === res.toLowerCase())
        return bot(`номер «${res}» уже занят игроком @id${users[i].id} (${users[i].tag}) ❌



▶️ Укажите другой номер.`);
    }

    user.scar.gosnomer = res;

    return bot(`Вы поставили новый гос. номер на машину! ☃️
🚥 Номер: «${res}» 🎫
🚗 Теперь эта машина будет ездить с такими номерами! 🚥`);
  }
);

cmd.hear(/^(?:машина)$/i, async (message, bot) => {
  let smileng = `❄️`;

  if (!message.user.transport.car) return bot(`у вас нет машины`);

  // Улучшения »

  let g1 = message.user.scar.prok_1;

  let g2 = message.user.scar.prok_2;

  let g3 = message.user.scar.prok_3;

  let g4 = message.user.scar.prok_4;

  let g5 = message.user.scar.prok_5;

  let g6 = message.user.scar.prok_6;

  // Информация о машине »

  let carsk = cars[message.user.transport.car - 1].carsk;

  let maxsk = cars[message.user.transport.car - 1].maxsk;

  let m_sk = eval(
    `(${g1} + ${g2} + ${g3} + ${g4} + ${g5} + ${g6}) * 3 + ${carsk}`
  );

  let max_sk = eval(
    `(${g1} + ${g2} + ${g3} + ${g4} + ${g5} + ${g6}) * 5 + ${maxsk}`
  );

  // Разгон до 100км/ч » [!] Не смог .__.

  let razgon = cars[message.user.transport.car - 1].razgon;

  {
    if (message.chatId) {
      await vk.api.messages.send({
        chat_id: message.chatId,
        attachment: `${cars[message.user.transport.car - 1].photo}`,
        message:
          `

@id${message.user.id}(${message.user.tag}), информация о Вашей машине! 🚘
🚗 Название: «${message.user.astats.car === false
            ? `${cars[message.user.transport.car - 1].name}`
            : `${message.user.astats.car}`
          }» ${smileng}
🛣️ Максимальная скорость: ${max_sk}
🚗 Мощность: ${m_sk} л/с.
⏱ Разгон до 100км/час: ${razgon} секунд.
➖➖➖➖➖➖
🏆 Ваш рейтинг гонщика: ${message.user.gon}
🎫 Госномер: ` +
          (message.user.scar.gosnomer === "undefined"
            ? `Отсуствует`
            : `${message.user.scar.gosnomer}`) +
          ``,

        keyboard: JSON.stringify({
          inline: true,

          buttons: [
            [
              {
                action: {
                  type: "text",
                  payload: "{}",
                  label: "🏎️ Топ гонщиков",
                },

                color: "primary",
              },
            ],

            [
              {
                action: { type: "text", payload: "{}", label: "🏁 Гонка" },

                color: "positive",
              },
            ],

            [
              {
                action: {
                  type: "text",

                  payload: '{"button": "1"}',

                  label: "⏫ Улучшения",
                },
                color: "secondary",
              },
            ],
          ],
        }),
        random_id: 0,
      });
    }

    if (!message.isChat) {
      await vk.api.messages.send({
        user_id: message.user.id,
        attachment: `${cars[message.user.transport.car - 1].photo}`,
        message:
          `

@id${message.user.id}(${message.user.tag
          }), информация о Вашей машине! 🚘${smileng}

🚗 Название: «${message.user.astats.car === false
            ? `${cars[message.user.transport.car - 1].name}`
            : `${message.user.astats.car}`
          }» ${smileng}
🛣️ Максимальная скорость: ${max_sk}
🚗 Мощность: ${m_sk} л/с.
⏱ Разгон до 100км/час: ${razgon} секунд.
➖➖➖➖➖➖
🏆 Ваш рейтинг гонщика: ${message.user.gon}
🎫 Госномер: ` +
          (message.user.scar.gosnomer === "undefined"
            ? `Отсуствует`
            : `${message.user.scar.gosnomer}`) +
          ``,

        keyboard: JSON.stringify({
          inline: true,

          buttons: [
            [
              {
                action: {
                  type: "text",
                  payload: "{}",
                  label: "🏎️ Топ гонщиков",
                },

                color: "primary",
              },
            ],

            [
              {
                action: { type: "text", payload: "{}", label: "🏁 Гонка" },

                color: "positive",
              },
            ],

            [
              {
                action: {
                  type: "text",

                  payload: '{"button": "1"}',

                  label: "⏫ Улучшения",
                },
                color: "secondary",
              },
            ],
          ],
        }),
        random_id: 0,
      });
    }
  }
});

cmd.hear(/^(?:машина улучшить|⏫ Улучшения)$/i, async (message, bot) => {
  if (!message.user.transport.car) return bot(`у вас нет машины`);

  let g1 = message.user.scar.prok_1;

  let g2 = message.user.scar.prok_2;

  let g3 = message.user.scar.prok_3;

  let g4 = message.user.scar.prok_4;

  let g5 = message.user.scar.prok_5;

  let g6 = message.user.scar.prok_6;

  return bot(
    `улучшения авто:



🌑 Шины [${g1}/3]
⬆️ Улучшить: «машина улучшить шины»

🔧 Диски [${g2}/5]
⬆️ Улучшить: «машина улучшить диски»

⚙ Двигатель [${g3}/5]
⬆️ Улучшить: «машина улучшить двигатель»

🧨 Тормоза [${g4}/3]
⬆️ Улучшить: «машина улучшить тормоза»

🕹 Управление [${g5}/5]
⬆️ Улучшить: «машина улучшить управление»

🔑 Чип тюнинг [${g6}/1]
⬆️ Улучшить: «машина улучшить чип»


🎫 Госномер [` +
    (message.user.scar.gosnomer === "undefined"
      ? `Отсуствует`
      : `${message.user.scar.gosnomer}`) +
    `]

1⃣ Установить: "машина госномер" (30.000.000$)

💰 ➖ Стоимость улучшения: ${utils.sp(
      cars[message.user.transport.car - 1].upgrade
    )}$`
  );
});

cmd.hear(/^(?:машина улучшить шины)$/i, async (message, bot) => {
  if (!message.user.transport.car)
    return bot(
      `у Вас нет транспортного средства! 🚗❌\n\n▶️ Просмотреть список продаваемых автомобилей: «Машины» 🛒`
    );

  if (message.user.scar.prok_1 > 2) return bot(`шины максимально улучшены. ⚒`);

  if (cars[message.user.transport.car - 1].upgrade > message.user.balance)
    return bot(
      `для улучшения Вам нужно ${cars[message.user.transport.car - 1].upgrade
      }$ 💰`
    );

  message.user.balance -= cars[message.user.transport.car - 1].upgrade;

  message.user.scar.prok_1 += 1;

  return bot(`шины были улучшены [${message.user.scar.prok_1}/3] ⚒`);
});

cmd.hear(/^(?:машина улучшить диски)$/i, async (message, bot) => {
  if (!message.user.transport.car)
    return bot(
      `у Вас нет транспортного средства! 🚗❌\n\n▶️ Просмотреть список продаваемых автомобилей: «Машины» 🛒`
    );

  if (message.user.scar.prok_2 > 4) return bot(`диски максимально улучшены. ⚒`);

  if (cars[message.user.transport.car - 1].upgrade > message.user.balance)
    return bot(
      `для улучшения Вам нужно ${cars[message.user.transport.car - 1].upgrade
      }$ 💰`
    );

  message.user.balance -= cars[message.user.transport.car - 1].upgrade;

  message.user.scar.prok_2 += 1;

  return bot(`диски были улучшены [${message.user.scar.prok_2}/5] ⚒`);
});

cmd.hear(/^(?:машина улучшить двигатель)$/i, async (message, bot) => {
  if (!message.user.transport.car)
    return bot(
      `у Вас нет транспортного средства! 🚗❌\n\n▶️ Просмотреть список продаваемых автомобилей: «Машины» 🛒`
    );

  if (message.user.scar.prok_3 > 4)
    return bot(`двигатель максимально улучшен. ⚒`);

  if (cars[message.user.transport.car - 1].upgrade > message.user.balance)
    return bot(
      `для улучшения Вам нужно ${cars[message.user.transport.car - 1].upgrade
      }$ 💰`
    );

  message.user.balance -= cars[message.user.transport.car - 1].upgrade;

  message.user.scar.prok_3 += 1;

  return bot(`двигатель был улучшен [${message.user.scar.prok_3}/5] ⚒`);
});

cmd.hear(/^(?:машина улучшить тормоза)$/i, async (message, bot) => {
  if (!message.user.transport.car)
    return bot(
      `у Вас нет транспортного средства! 🚗❌\n\n▶️ Просмотреть список продаваемых автомобилей: «Машины» 🛒`
    );

  if (message.user.scar.prok_4 > 2)
    return bot(`тормоза максимально улучшены. ⚒`);

  if (cars[message.user.transport.car - 1].upgrade > message.user.balance)
    return bot(
      `для улучшения Вам нужно ${cars[message.user.transport.car - 1].upgrade
      }$ 💰`
    );

  message.user.balance -= cars[message.user.transport.car - 1].upgrade;

  message.user.scar.prok_4 += 1;

  return bot(`тормоща были улучшены [${message.user.scar.prok_4}/3] ⚒`);
});

cmd.hear(/^(?:машина улучшить управление)$/i, async (message, bot) => {
  if (!message.user.transport.car)
    return bot(
      `у Вас нет транспортного средства! 🚗❌\n\n▶️ Просмотреть список продаваемых автомобилей: «Машины» 🛒`
    );

  if (message.user.scar.prok_5 > 4)
    return bot(`управление максимально улучшено. ⚒`);

  if (cars[message.user.transport.car - 1].upgrade > message.user.balance)
    return bot(
      `для улучшения Вам нужно ${cars[message.user.transport.car - 1].upgrade
      }$ 💰`
    );

  message.user.balance -= cars[message.user.transport.car - 1].upgrade;

  message.user.scar.prok_5 += 1;

  return bot(`управление было улучшено [${message.user.scar.prok_5}/5] ⚒`);
});

cmd.hear(/^(?:машина улучшить чип)$/i, async (message, bot) => {
  if (!message.user.transport.car)
    return bot(
      `у Вас нет транспортного средства! 🚗❌\n\n▶️ Просмотреть список продаваемых автомобилей: «Машины» 🛒`
    );

  if (message.user.scar.prok_6 > 0) return bot(`чип максимально улучшен. ⚒`);

  return bot(`${text}`);
});

function addZero(i) {
  return i < 10 ? "0" + i : i;
}

function unixStampLefta(stampa) {
  stampa = stampa / 1000;
  let s = stampa % 60;
  stampa = (stampa - s) / 60;
  let m = stampa % 60;
  let text = ``;
  if (m > 0) text += addZero(Math.floor(m)) + " мин. ";
  if (s > 0) text += addZero(Math.floor(s)) + " сек.";
  return text;
}

cmd.hear(/^(?:гонка|🏁 Гонка)$/i, async (message, bot) => {

  if (message.user.scar.gontime >= Date.now()) return bot(`Ваша машина в ремонте! 🔩 🚙 
		
🏁 Поехать на гонки Вы сможете через ${unixStampLefta(message.user.scar.gontime - Date.now())} ❄️`)

  if (!message.user.transport.car) return bot(`у Вас нет транспортного средства! 🚗❌\n\n▶️ Просмотреть список продаваемых автомобилей: «Машины» 🛒`)


  if (message.user.captcha.vid !== false) {

    if (message.user.captcha.vid == 1) return bot(`подозрительная активность! ❌

Введите «капча ${message.user.captcha.otvet}», чтобы пройти проверку на робота!`)

    if (message.user.captcha.vid == 2) return bot(`подозрительная активность! ❌

Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2}» и введите "капча [ответ]"`)

  }

  let captcha = utils.random(1, 100)

  if (captcha == 44) {

    let t = utils.pick([1, 2])

    if (t == 1) {

      let otv = utils.random(100, 500)

      message.user.captcha.vid = 1

      message.user.captcha.otvet = otv

      return bot(`подозрительная активность! ❌

Введите «капча ${otv}», чтобы пройти проверку на робота!`)

    }

    if (t == 2) {

      let pr1 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20])

      let pr2 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20])

      message.user.captcha.vid = 2

      message.user.captcha.otvet = pr1 + pr2

      message.user.captcha.primer = pr1 + pr2

      return bot(`подозрительная активность! ❌

Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2}» и введите "капча [ответ]"`)

    }

  }



  if (typeof message.user.questracer === "number") {

    message.user.questracer++;

    if (message.user.questracer >= 5) {

      message.user.questracer = true;

      await bot(`Поздравляем, Вы 5 раз поучаствовали в гонке и получаете 📦 1 Донат-кейс.`);

      message.user.c3 += 1;

    }

  }



  if (typeof message.user.questracer2 === "number" && message.user.questallfucker == true) {

    message.user.questracer2++;

    if (message.user.questracer2 >= 500) {

      message.user.questracer2 = true;

      await bot(`Поздравляем, Вы 500 раз поучаствовали в гонке и получаете 📦 2 Донат-кейсa.`);

      message.user.c3 += 2;

    }

  }



  let g1 = message.user.scar.prok_1;

  let g2 = message.user.scar.prok_2;

  let g3 = message.user.scar.prok_3;

  let g4 = message.user.scar.prok_4;

  let g5 = message.user.scar.prok_5;

  let g6 = message.user.scar.prok_6;

  // Информация о машине »

  let carsk = cars[message.user.transport.car - 1].carsk;

  let mymaxsk = cars[message.user.transport.car - 1].maxsk;

  let m_sk = eval(`(${g1} + ${g2} + ${g3} + ${g4} + ${g5} + ${g6}) * 3 + ${carsk}`)

  let mymax_sk = eval(`(${g1} + ${g2} + ${g3} + ${g4} + ${g5} + ${g6}) * 5 + ${mymaxsk}`)



  let s = utils.random(1, 16);

  let skorost = utils.random(5, 63); // Не знаю зачем это.

  let max_sk = eval(`${cars[s - 1].maxsk} + ${skorost}`);

  let p_sk = eval(`${cars[s - 1].carsk} + ${skorost}`);

  let razgon = cars[s - 1].razgon;



  // Подбор Номера »

  let n_one = utils.pick(['А', 'В', 'Е', 'К', 'М', 'Н', 'О', 'Р', 'С', 'Т', 'У', 'Х']);

  let n_two = utils.random(0, 9);

  let n_three = utils.random(0, 9);

  let n_four = utils.random(0, 9);

  let n_five = utils.pick(['А', 'В', 'Е', 'К', 'М', 'Н', 'О', 'Р', 'С', 'Т', 'У', 'Х']);

  let n_six = utils.pick(['А', 'В', 'Е', 'К', 'М', 'Н', 'О', 'Р', 'С', 'Т', 'У', 'Х']);

  let n_seven = utils.pick(['777']);

  rgn = `${n_one}${n_two}${n_three}${n_four}${n_five}${n_six} ${n_seven}`;

  let w_km = mymax_sk - max_sk;

  let p_km = max_sk - mymax_sk;

  // Подбор Номера «

  var cases = utils.pick([0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0]);

  if (cases == 1) {

    message.user.c4++;

    message.user.sprcoin += 3;

  }

  bot(`Начался заезд против «${cars[s - 1].name}»

🏎 Ожидаем прибытие машин к финишу..`, { attachment: `${cars[message.user.transport.car - 1].photo},${cars[s - 1].photo}` })

  let w_reit = utils.random(5, 9)

  message.user.scar.gontime = Date.now() + 900000;

  let p_reit = utils.random(2, 4)

  if (message.user.settings.imperator) {

    w_reit += 3;

    p_reit -= 1;

  }



  message.user.scar.gontime = true



  if (!message.isChat) {

    message.user.scar.gontime = Date.now() + 900000;

    setTimeout(() => {

      if (message.isChat) {

        vk.api.messages.send({
          chat_id: message.chatId, random_id: 0, message: `🏎️ @id${message.user.id} (${message.user.tag}), погоняешь на своей тачке? 😎



▶️ Скорее пиши «Гонка» и начинай всех разносить на гонке! 🤯` });

        message.send({ sticker_id: 74276 })

      }

      if (!message.isChat) {

        vk.api.messages.send({
          user_id: message.user.id, random_id: 0, message: `🏎️ @id${message.user.id} (${message.user.tag}), погоняешь на своей тачке? 😎



▶️ Скорее пиши «Гонка» и начинай всех разносить на гонке! 🤯` });

        message.send({ sticker_id: 74276 })

      }

    }, 900000);

  } else {

    if (message.user.id >= 0) {

        message.user.scar.gontime = Date.now() + 600000;

        setTimeout(() => {

          if (message.isChat) {

            vk.api.messages.send({
              chat_id: message.chatId, random_id: 0, message: `🏎️ @id${message.user.id} (${message.user.tag}), погоняешь на своей тачке? 😎



▶️ Скорее пиши «Гонка» и начинай всех разносить на гонке! 🤯` });

            message.send({ sticker_id: 74276 })

          }

          if (!message.isChat) {

            vk.api.messages.send({
              user_id: message.user.id, random_id: 0, message: `🏎️ @id${message.user.id} (${message.user.tag}), погоняешь на своей тачке? 😎



▶️ Скорее пиши «Гонка» и начинай всех разносить на гонке! 🤯` });

            message.send({ sticker_id: 74276 })

          }

        }, 600000);

    

    } else {

      message.user.scar.gontime = Date.now() + 900000;

      setTimeout(() => {

        if (message.isChat) {

          vk.api.messages.send({
            chat_id: message.chatId, random_id: 0, message: `🏎️ @id${message.user.id} (${message.user.tag}), погоняешь на своей тачке? 😎



▶️ Скорее пиши «Гонка» и начинай всех разносить на гонке! 🤯` });

          message.send({ sticker_id: 74276 })

        }

        if (!message.isChat) {

          vk.api.messages.send({
            user_id: message.user.id, random_id: 0, message: `🏎️ @id${message.user.id} (${message.user.tag}), погоняешь на своей тачке? 😎



▶️ Скорее пиши «Гонка» и начинай всех разносить на гонке! 🤯` });

          message.send({ sticker_id: 74276 })

        }

      }, 900000);

    }
  }
  

  if (message.user.settings.topdon) {

    message.user.scar.gontime = Date.now() + 300000;

    setTimeout(() => {

      if (message.isChat) {

        vk.api.messages.send({
          chat_id: message.chatId, random_id: 0, message: `🏎️ @id${message.user.id} (${message.user.tag}), погоняешь на своей тачке? 😎



▶️ Скорее пиши «Гонка» и начинай всех разносить на гонке! 🤯` });

        message.send({ sticker_id: 74276 })

      }

      if (!message.isChat) {

        vk.api.messages.send({
          user_id: message.user.id, random_id: 0, message: `🏎️ @id${message.user.id} (${message.user.tag}), погоняешь на своей тачке? 😎



▶️ Скорее пиши «Гонка» и начинай всех разносить на гонке! 🤯` });

        message.send({ sticker_id: 74276 })

      }

    }, 300000);

  }

  let smileng = utils.pick([`🌷`, `🌸`, `🌹`, `🌺`, `🌼`, `💐`, `❤️`, `💓`, `💕`]) //utils.pick([`☃️`,`🎄`,`❄️`,`🎅`]);

  if (m_sk == p_sk) setTimeout(() => {
    return message.send(`Ничья! 😟

		

▶️ Улучшайте свой автомобиль, чтобы стать быстрее! 🏁`, { attachment: utils.pick([`${cars[message.user.transport.car - 1].photo}, ${cars[s - 1].photo}`]) }).catch((error) => {

      console.log(` Ошибка.`);

    })
  }, 5000);

  if (m_sk > p_sk && cases == 1) {

    message.user.c4 += 1;

    message.user.gon += w_reit

    message.user.balance += 7500000000



    setTimeout(() => {
      return message.send(`😈 Выигрыш! Ваша машина оказалсь быстрее противника! 🚗



⚙️ Характеристики машин:



🚗 Ваш автомобиль: «${cars[message.user.transport.car - 1].name}» ${smileng}

🚘 Скорость: ${mymax_sk}км/ч



🚙 Автомобиль противника: «${cars[s - 1].name}»

🚘 Скорость: ${max_sk}км/ч

🎫 Госномер: ${rgn}

➖➖➖➖➖➖➖

🏁 Получено рейтинга: +${w_reit}

🏆 Ваш рейтинг: ${utils.sp(message.user.gon)} 🏆

💵 Выигрыш: +7.500.000.000$ 🤑

📦 Кейсы: +1 Гоночный кейс`, { attachment: utils.pick([`${cars[message.user.transport.car - 1].photo}`]) }).catch((error) => {

        console.log(` Ошибка.`);

      })
    }, 5000);

  }

  if (m_sk > p_sk) {

    message.user.gon += w_reit

    message.user.balance += 7500000000

    setTimeout(() => {
      return message.send(`😈 Выигрыш! Ваша машина оказалсь быстрее противника! 🚗

⚙️ Характеристики машин:
🚗 Ваш автомобиль: «${cars[message.user.transport.car - 1].name}» ${smileng}
🚘 Скорость: ${mymax_sk}км/ч

🚙 Автомобиль противника: «${cars[s - 1].name}»
🚘 Скорость: ${max_sk}км/ч
🎫 Госномер: ${rgn}
➖➖➖➖➖➖➖
🏁 Получено рейтинга: +${w_reit}
🏆 Ваш рейтинг: ${utils.sp(message.user.gon)} 🏆
💵 Выигрыш: +7.500.000.000$ 🤑`, { attachment: utils.pick([`${cars[message.user.transport.car - 1].photo}`]) }).catch((error) => {

        console.log(` Ошибка.`);

      })
    }, 5000);

  }

  if (m_sk < p_sk) {

    message.user.gon -= p_reit

    setTimeout(() => {
      return message.send(`👿 Проигрыш! Ваша машина оказалсь медленее противника! 🚗

⚙️ Характеристики машин:
🚗 Ваш автомобиль: «${cars[message.user.transport.car - 1].name}» ${smileng}
🚘 Скорость: ${mymax_sk}км/ч

🚙 Автомобиль противника: «${cars[s - 1].name}»
🚘 Скорость: ${max_sk}км/ч
🎫 Госномер: ${rgn}
➖➖➖➖➖➖➖
🏁 Рейтинг гонщика: -${p_reit} 🏆
🏆 Ваш рейтинг: ${message.user.gon} 🏆

⚙ Улучшайте свой автомобиль, чтобы стать быстрее!`, { attachment: utils.pick([`${cars[s - 1].photo}`]) }).catch((error) => {

        console.log(` Ошибка.`);

      })
    }, 5000);

  }

});

cmd.hear(/^(?:топ гонщиков|🏎️ Топ гонщиков)$/i, async (message, bot) => {
  let top = [];

  double
    .filter((x) => x.bantop === false)
    .map((x) => {
      top.push({ gon: x.gon, tag: x.tag, id: x.id, mention: x.mention });
    });

  top.sort((a, b) => {
    return b.gon - a.gon;
  });

  let text = ``;

  const find = () => {
    let pos = 100;

    for (let i = 0; i < top.length; i++) {
      if (top[i].id === message.senderId) return (pos = i);
    }

    return pos;
  };

  for (let i = 0; i < 10; i++) {
    if (!top[i])
      return message.send(
        "👥 В боте должно зарегистрировано не менее 10 игроков!"
      );

    const user = top[i];

    text += `\n${i === 9 ? `&#128287;` : `${i + 1}&#8419;`} ${user.mention ? `@id${user.id} (${user.tag})` : `${user.tag}`
      } — 🏆${utils.sp(user.gon)}`;
  }

  return bot(
    `топ гонщиков:${text}
		➖➖➖➖➖➖➖➖
➡${utils.gi(find() + 1)} ${message.user.tag} — 🏆${utils.sp(message.user.gon)}`,

    {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "🔅 Топ реферал",
              },

              color: "default",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "😈 Босс топ",
              },

              color: "default",
            },

            {
              action: {
                type: "text",

                payload: "{}",

                label: "🏆 Топ рейтинг",
              },

              color: "default",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "👥 Топ игроков",
              },

              color: "default",
            },

            {
              action: {
                type: "text",

                payload: "{}",

                label: "🌐 Топ биткоины",
              },

              color: "default",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "〽️ Топ опыт",
              },

              color: "default",
            },

            {
              action: {
                type: "text",

                payload: "{}",

                label: "🏎️ Топ гонщиков",
              },

              color: "default",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "💰 Топ баланс",
              },

              color: "default",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "💌 Топ сообщения",
              },

              color: "default",
            },
          ],
        ],
      }),
    }
  );
});

module.exports = commands;
