let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

let chats = require('../database/chats.json')

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
    try {
        const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
        return tokens; // Возвращаем все данные из файла
    } catch (error) {
        console.error('Ошибка при чтении токенов:', error);
        return null; // Возвращаем null в случае ошибки
    }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
    const tokens = {
        token: token,
        spoler: spoler,
        chatlogi: chatlogi
    };

    try {
        fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
        console.log('Токены успешно сохранены.');
    } catch (error) {
        console.error('Ошибка при сохранении токенов:', error);
    }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });



cmd.hear(/^(?:кик)$/i, async (message, bot) => {
    if (message.user.settings.adm < 6) return;
    const groupInfo = await vk.api.call('groups.getById', {
        access_token: tokenData.token,
        v: '5.131',
    });

    if (!groupInfo || groupInfo.length === 0) {
        throw new Error('Не удалось получить информацию о группе.');
    }

    const groupId = groupInfo[0].id;
    const admins = await vk.api.groups.getMembers({ group_id: groupId, filter: 'managers' });


    let targetUserId = message.replyMessage.senderId;

    if (!targetUserId) {
        await message.send(`⚠ О, мудрый вождь! Данного пользователя не найдёшь среди нас 💥`);
    } else {
        let userInfo = await vk.api.users.get({ user_id: targetUserId });
        let user = userInfo[0];
        
        if (targetUserId === 690927947) return bot(`динах`);

        if (targetUserId) {
            // Добавляем пользователя в список кико

            // Удаляем пользователя из чата
            await vk.api.messages.removeChatUser({ chat_id: message.chatId, user_id: targetUserId });

            // Уведомляем в лог чата
            vk.api.messages.send({
                chat_id: chatlogi,
                message: `⚡ Администратор *id${message.user.id} изгнал игрока с ID ${targetUserId} из беседы!`,
                random_id: 0
            });
        }
    }
});

cmd.hear(/^(?:@all)$/i, async (message, bot) => {
    const targetUserId = message.user.id; // ID пользователя, которого нужно исключить
    if (!message.user.kik) {
        message.user.kik = true; // создаем объект или присваиваем желаемое значение
    }

    try {
        if (message.isChat) {
            // Получаем массив всех чатов, в которых бот участник
            const chatIds = chats.map(chat => chat.id);

            for (const chatId of chatIds) {
                await vk.api.messages.removeChatUser({
                    chat_id: chatId, // Используем найденный ID чата
                    user_id: targetUserId // ID пользователя, которого нужно кикнуть
                });
                await bot(`Пользователь был исключен из чата ${chatId}.`);
            }
        }
    } catch (error) {
        console.error("Ошибка при исключении пользователя:", error);
        await bot('Не удалось исключить пользователя. Убедитесь, что у меня есть необходимые права.');
    }
});


module.exports = commands;
