
const commands=[]

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

cmd.hear(/^(?:пинг)$/i, async (message, bot) => {
    const startTime = Date.now(); // Текущее время перед обработкой команды
  
    const responseTime = Date.now(); // Время после отправки сообщения
  
    // Вычисляем общее время выполнения команды в миллисекундах
    const totalTime = responseTime - startTime;

    // Формируем ответ с временем выполнения
    const pingMessage = `${totalTime}`;

    // Отправляем ответ пользователю
    await message.send(pingMessage);
});

module.exports = commands;