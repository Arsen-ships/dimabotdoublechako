let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:обнулить|обнул)\s([0-9]+)$/i, async (message, bot) => {
	  const groupInfo = await vk.api.call('groups.getById', {
            access_token: tokenData.token,
            v: '5.131', // Версия API
        });

  if (!groupInfo || groupInfo.length === 0) {
            throw new Error('Не удалось получить информацию о группе.');
        }

        // Извлекаем group_id из первого элемента массива groups
  const groupId = groupInfo[0].id;

  const admins = await vk.api.groups.getMembers({ group_id: groupId, filter: 'managers' });

  if (!admins.items.find(x => x.id === message.senderId)) return;
	


    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока`);

    user.balance = 5000;

    user.balance2 = 0;

    user.bank = 0;

    user.bilet = 0;

    user.btc = 0;

    user.farm_btc = 0;

    user.biz = 0;

    user.energy = 10;

    user.maxenergy = 10;

    user.sataka = 1;

    user.bossyr = 0;

    user.stock.status = "Игрок";

    user.stock.stpban = "Нет";

    user.stock.strban = "Нет";

    user.stock.stban = "Нет";

    user.stock.bantop = "Нет";

    user.astats.blocked = false;

    user.astats.reports = 0;

    user.astats.bans = 0;

    user.astats.rbans = 0;

    user.astats.pbans = 0;

    user.astats.balance = 0;

    user.astats.bank = 0;

    user.astats.warn = 0;

    user.sertificats.gosnomer = 0;

    user.sertificats.car = 0;

    user.sertificats.rating = 0;

    user.sertificats.premium = 0;

    user.sertificats.business = 0;

    user.sertificats.vip = 0;

    user.sertificats.opit = 0;

    user.sertificats.activ = 0;

    user.rub = 0;

    user.casinoplus = 0;

    user.casinominus = 0;

    user.rating = 0;

    user.bantop = false;

    user.gon = 0;

    user.mention = true;

    user.c1 = 0;

    user.c2 = 0;

    user.c3 = 0;

    user.c4 = 0;

    user.c5 = 0;

    user.c6 = 0;

    user.c7 = 0;

    user.c8 = 0;

  user.c9 = 0;
  
  user.c10 = 0;

  user.c11 = 0;

  user.photo = "";

    user.possilka1 = 0;

    user.possilka2 = 0;

    user.possilka3 = 0;

    (user.sound = 0),
      (user.soundrating = 0),
      (user.autosound = 0),
      (user.tree = 0),
      (user.leaf = 0),
      (user.irrigation = 0),
      (user.leafpribil = 0),
      (user.minertool = 0);

    user.ruds.zhelezo = 0;

    user.ruds.zoloto = 0;

    user.ruds.almaz = 0;

    user.ruds.materia = 0;

    user.ruds.obsidian = 0;

    user.ruds.plazma = 0;

    user.ruds.antimateria = 0;

    user.procent.clock = 0;

    user.timers.hasWorked = false;

    user.timers.bonus = false;

    user.timers.vipbonus = false;

    user.timers.prembonus = false;

    user.timers.titanbonus = false;

    user.timers.poxod = false;

    user.timers.podarok = false;

    user.timers.report = false;

    user.work = 0;

    user.lte2 = false;

    user.business = [];

    user.business2 = [];

    user.notifications = true;

    user.promo = false;

    user.opit = 0;

    user.exp = 1;

    user.level = 1;

    user.bans.ban = false;

    user.bans.rban = false;

    user.bans.pban = false;

    user.scar.gosnomer = "undefined";

    user.scar.gontime = false;

    user.scar.prok_1 = 1;

    user.scar.prok_2 = 1;

    user.scar.prok_3 = 1;

    user.scar.prok_4 = 1;

    user.scar.prok_5 = 1;

    user.scar.prok_6 = 1;

    user.transport.car = 0;

    user.transport.yacht = 0;

    user.transport.airplane = 0;

    user.transport.helicopter = 0;

    user.settings.adm = 0;

    user.settings.vip = false;

    user.settings.premium = false;

    user.settings.titan = false;

    user.realty.home = 0;

    user.realty.apartment = 0;

    user.misc.phone = 0;

    user.misc.computer = 0;

    user.misc.clock = 0;

    user.misc.pet = 0;

    user.misc.farm = 0;

    user.misc.farm_count = 0;

    user.pet.lvl = 0;

    user.pet.poterl = false;

    user.marriage.partner = 0;

    user.marriage.requests = [];

    user.limit.nicklimit = 16;

    user.limit.banklimit = 50000000000000;

    user.limit.timer = utils.time();

    user.limit.playerlimit = 50000000000000;

    user.limit.sent = 0;

    user.limit.paylimit = 50000000000000;

    user.limit.farmlimit = 1000;

    user.stars1 = false;

    user.stars2 = false;

    user.stars3 = false;

    user.stars4 = false;

    user.stars5 = false;

    user.settings.joker = false;

    user.settings.imperator = false;

    user.settings.busi = false;

    user.settings.agent = false;
  
  user.settings.topdon = false;
  
  user.settings.king = false;

  user.prazdnikbussines = false;

  user.stock.status = ""

  user.astats.fakeid = user.uid

  user.questfollow = false

    await vk.api.messages.send({
      chat_id: chatlogi,
      random_id: 0,
      message: `⛔ Администратор @id${message.user.id} (${message.user.tag})[ID: ${message.user.uid}] обнулил игрока @id${user.id} (${user.tag})[ID: ${user.uid}] ❄️`,
    });

    return bot(
      `Вы обнулили [id${user.id}|игрока] успешно. Ваши действия были зафиксированы и отправлены старшей администрации (в целях безопасности игроков).`
    );
  
  
});

module.exports = commands;
