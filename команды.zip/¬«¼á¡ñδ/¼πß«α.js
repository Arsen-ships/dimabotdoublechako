let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

let chats = require('../database/chats.json')


let botinfo = require('../database/botinfo.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });


function addZero(i) {
  return i < 10 ? "0" + i : i.toString();
}

function unixStampLefta(stampa) {
  stampa = stampa / 1000;
  let s = stampa % 60;
  stampa = (stampa - s) / 60;
  let m = stampa % 60;
  let text = ``;
  if (m > 0) text += addZero(Math.floor(m)) + " мин. ";
  if (s > 0) text += addZero(Math.floor(s)) + " сек.";
  return text;
}



cmd.hear(/^(?:билеты)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    return bot(`у вас всего ${utils.sp(message.user.bilet)} билетов 🎟`);
  }
});


cmd.hear(/^(?:опыт)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    return bot(`у вас всего ${utils.sp(message.user.opit)} опыта 🎟`);
  }
});

cmd.hear(/^(?:Купить титул)\s(.*)$/i, async (message, bot) => {
  if (
    message.args[1] === "Администратор" ||
    message.args[1] === "Гл. Администратор" ||
    message.args[1] === "Админ" ||
    message.args[1] === "Джокер" ||
    message.args[1] === "Бизнесмен"
  )
    return;

  if (message.args[1].length > 20)
    return bot(`титул не должен превышать 20-ти символов! 😥`);

  if (message.args[1].length < 3)
    return bot(`титул не должен быть меньше 3-х символов! 😥`);

  if (!message.user.settings.imperator) {
    if (message.user.balance <= 500000000000000)
      return bot(
        `Для покупки титула нужно иметь 500.000.000.000.000$ ❌\n\n💰 Ваш баланс: ${utils.sp(
          message.user.balance
        )}$ 💵`
      );

    message.user.balance -= 500000000000000;
  }

  message.user.stock.status = `${message.args[1]}`;

  return bot(
    `Вы успешно купили титул «${message.args[1]}» 😃\n🚫 Внимание! Титулы на подобии "Администратор", "Дауны" (оскорбительные) строго запрещены! За нарушение — удаление титула.`
  );
});


cmd.hear(/^(?:энергия)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    return bot(`ваша энергия: ${utils.sp(message.user.energy)} ⚡`);
  }
});

cmd.hear(/^(?:биткоин|биткоины|битки)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    return bot(`ваши биткоины: ${utils.sp(message.user.btc)} ⚡`);
  }
});

cmd.hear(/^(?:стату(я|и))\s(денег|мажора)$/i, async (message, bot) => {

  const chatss = chats.find(chat => chat.id === message.chatId);
  if (chatss) {
    if (chatss.statuemoneylvl === 0) {
      return bot(
        `Статуя денег:

✨ Текущий уровень: 0
🏆 Прогресс: ${utils.sp(
          chatss.statuemoney
        )}/1.000.000.000.000.000$
🏅 Бонусы: отсутствуют`,
        { attachment: "photo-197579361_457262064" }
      )
      {


        if (chatss.statuemoneylvl == 1)
return bot(
  `Статуя денег:

✨ Текущий уровень: 1
🏆 Прогресс: ${utils.sp(
    chatss.statuemoney
  )}/50.000.000.000.000.000$
🏅 Бонусы:

🏢 -1% налогов`,
  { attachment: "photo-197579361_457262064" })
      

        if (chatss.statuemoneylvl == 2)
          return bot(
            `Статуя денег:

✨ Текущий уровень: 2
🏆 Прогресс: ${utils.sp(
              chats.statuemoney
            )}/500.000.000.000.000.000$
🏅 Бонусы:

🏢 -3% налогов`,
            { attachment: "photo-197579361_457262064" }
          )

        if (chatss.statuemoneylvl == 3)
          return bot(
            `Статуя денег:

✨Текущий уровень: 3
🏆 Прогресс: Максимальное улучшение
🏅Бонусы:

	🏢✅ Убран весь налог с казино`,
            { attachment: "photo-197579361_457262064" }
          );
      }
    }
  }
});
cmd.hear(/^(?:стату(я|и))\s(актива|сообщений)$/i, async (message, bot) => {

  if (message.isChat) {

    const chatss = chats.find(chat => chat.id === message.chatId);
    if (chatss) {
      if (chatss.statuemsglvl == 0)

        return bot(`Статуя актива:

				

✨ Текущий уровень: 0

🏆 Прогресс: ${utils.sp(chatss.statuemsg)}/10.000

🏅 Бонусы: отсутствуют`, { attachment: 'photo-197579361_457262061' });

      if (chatss.statuemsglvl == 1)

        return bot(`Статуя актива:

				

✨ Текущий уровень: 1

🏆 Прогресс: ${utils.sp(chatss.statuemsg)}/100.000

🏅 Бонусы:  

	⏰ Уменьшение кулдауна гонки/автозвук/дайвинг/охота на 2 минуты`, { attachment: 'photo-197579361_457262061' });

      if (chatss.statuemsglvl == 2)

        return bot(`Статуя актива:

				

✨ Текущий уровень: 2

🏆 Прогресс: ${utils.sp(chatss.statuemsg)}/500.000

🏅 Бонусы:   

	⏰ Уменьшение кулдауна гонки/автозвук/дайвинг/охота на 2 минуты

	💎 Увеличение количества добываемых ресурсов в 1.5 раза`, { attachment: 'photo-197579361_457262061' });

      if (chatss.statuemsglvl == 3)

        return bot(`Статуя актива:

				

✨ Текущий уровень: 3

🏆 Прогресс: Максимальное улучшение

🏅 Бонусы:   

	⏰ Уменьшение кулдауна гонки/автозвук/дайвинг/охота на 2 минуты

	💎 Увеличение количества добываемых ресурсов в 1.5 раза

	⚡ Атака на босса тратит 1 энергию

	⛏️ Копание Материи/обсидиана требует 1 энергию, плазмы - 3 энергии`, { attachment: 'photo-197579361_457262061' });

    }
  }

});

cmd.hear(/^(?:стату(я|и))\s(людей|участников)$/i, async (message, bot) => {

  if (message.isChat) {
    let pear = 2000000000 + message.chatId;
    const chat_info = await vk.api.call("messages.getConversationMembers", { peer_id: pear });

    const chat = chats.find(chat => chat.id === message.chatId);
    if (chat) {


      chat.statuepeople = chat_info.count;


      if (chat.statuepeople < 10) {
        chat.statuepeoplelvl = 0;
      }

      if (chat.statuepeople >= 10) {
        chat.statuepeoplelvl = 1;
      }

      if (chat.statuepeople >= 25) {
        chat.statuepeoplelvl = 2;
      }

      if (chat.statuepeople >= 50) {
        chat.statuepeoplelvl = 3;
      }

      if (chat.statuepeople >= 60) {
        chat.statuepeoplelvl = 4;
      }

      if (chat.statuepeople >= 80) {
        chat.statuepeoplelvl = 5;
      }

      if (chat.statuepeople >= 100) {
        chat.statuepeoplelvl = 6;
      }



      if (chat.statuepeoplelvl == 0)

        return bot(`Статуя людей:

				

✨ Текущий уровень: 0

🏆 Прогресс: ${utils.sp(chat.statuepeople)}/10

🏅 Бонусы: отсутствуют`, { attachment: 'photo-197579361_457262062' });

      if (chat.statuepeoplelvl == 1)

        return bot(`Статуя людей:

				

✨ Текущий уровень: 1

🏆 Прогресс: ${utils.sp(chat.statuepeople)}/25

🏅 Бонусы:

	🎰 Добавлен коэффициент x3 в казино `, { attachment: 'photo-197579361_457262062' });

      if (chat.statuepeoplelvl == 2)

        return bot(`Статуя людей:

				

✨ Текущий уровень: 2

🏆 Прогресс: ${utils.sp(chat.statuepeople)}/50

🏅 Бонусы:

	🎰 Добавлен коэффициент x3 в казино

	🎰 Добавлен коэффициент x100 в казино`, { attachment: 'photo-197579361_457262062' });

      if (chat.statuepeoplelvl == 3)

        return bot(`Статуя людей:

				

✨ Текущий уровень: 3

🏆 Прогресс: ${utils.sp(chat.statuepeople)}/60

🏅 Бонусы:

	🎰 Добавлен коэффициент x3 в казино

	🎰 Добавлен коэффициент x100 в казино

	🎰 Добавлен коэффициент x200 в казино`, { attachment: 'photo-197579361_457262062' });

      if (chat.statuepeoplelvl == 4)

        return bot(`Статуя людей:

				

✨ Текущий уровень: 4

🏆 Прогресс: ${utils.sp(chat.statuepeople)}/80

🏅 Бонусы:

	🎰 Добавлен коэффициент x3 в казино

	🎰 Добавлен коэффициент x100 в казино

	🎰 Добавлен коэффициент x200 в казино

	👊 Бонус к урону по боссу`, { attachment: 'photo-197579361_457262062' });

      if (chat.statuepeoplelvl == 5)

        return bot(`Статуя людей:

				

✨ Текущий уровень: 5

🏆 Прогресс: ${utils.sp(chat.statuepeople)}/100

🏅 Бонусы:

	🎰 Добавлен коэффициент x3 в казино

	🎰 Добавлен коэффициент x100 в казино

	🎰 Добавлен коэффициент x200 в казино

	👊 Бонус к урону по боссу

	🎁 Шанс выпадение дополнительных призов во время игры в казино`, { attachment: 'photo-197579361_457262062' });

      if (chat.statuepeoplelvl == 6)

        return bot(`Статуя людей:

				

✨ Текущий уровень: 6

🏆 Прогресс: Максимальное улучшение

🏅 Бонусы:

	🎰 Добавлен коэффициент x3 в казино

	🎰 Добавлен коэффициент x100 в казино

	🎰 Добавлен коэффициент x200 в казино

	👊 Бонус к урону по боссу

	🎁 Шанс выпадение дополнительных призов во время игры в казино

	⛏️ Возможность копать плазму`, { attachment: 'photo-197579361_457262062' });

    }
  }

});


cmd.hear(/^(?:магазин|shop|👛 магазин)$/i, async (message, bot) => {
  return bot(
    `разделы магазина:
🚙 Транспорт
🏘 Недвижимость
📺 Техника
📌 Остальное

💠 Для перехода по разделам используйте кнопки ниже.`,

    {
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "🚙 Транспорт",
              },

              color: "default",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "🏘️ Недвижимость",
              },

              color: "default",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "📺 Техника",
              },

              color: "default",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "📌 Остальное",
              },

              color: "default",
            },
          ],
        ],
      }),
    }
  );
});

cmd.hear(/^(?:🚙 Транспорт)$/i, async (message, bot) => {
  return bot(`раздел «Транспорт» 🚙
🚗 Машины
🛥 Яхты
🛩 Самолеты
🚁 Вертолеты`);
});

cmd.hear(/^(?:🏘️ Недвижимость)$/i, async (message, bot) => {
  return bot(`раздел «Недвижимость» 🏘️
🏠 Дома [Подвал]
🌇 Квартиры`);
});

cmd.hear(/^(?:📌 Остальное)$/i, async (message, bot) => {
  return bot(`раздел «Остальное» 📌
🌳 Деревья
☕ Напитки
🔧 Инструменты
☀ Звезды
🦊 Питомцы
💼 Бизнесы
🔋 Фермы
📦 Кейсы
🌐 Биткоин [кол-во]
👑 Рейтинг [кол-во] - 700 млн$`);
});

cmd.hear(/^(?:📺 Техника)$/i, async (message, bot) => {
  return bot(`раздел «Техника» 📺
📱 Компьютеры
📱 Телефоны
⌚ Часы`);
});

cmd.hear(
  /^(?:Правила|⚠️ Правила \(1 ч.\) ◀️|⏪ Правила №1)$/i,
  async (message, bot) => {
    return bot(
      `Общие:

* 1.1 Незнание правил не освобождает от ответственности.
* 1.2 Начав использовать бота Вы подтверждаете свое согласие с данными правилами.
* 1.3 Администрация не несет ответственности за временную или постоянную невозможность игры в бота конкретным лицом или группой лиц.
* 1.4 Ответственность несет владелец аккаунта, независимо от того, кто совершал действия под данным аккаунтом.
* 1.5 Написав боту, вы автоматически соглашаетесь на получение рассылок от бота.
* — означает то, что Вы при регистрации аккаунта уже соглашены с этими правилами.

Действия с аккаунтом:
2.1 Запрещена любая автоматизация действий в боте
⛔ Наказание: блокировка на 7 дней + частичное/полное обнуление

2.2 Запрещено предоставлять игрокам услуги, такие как продажа игровой валюты, обмен валюты между ботами, «буст» аккаунта и т.п.
⛔ Наказание: вечная блокировка,полное обнуление.

2.3 Запрещена покупка (или попытка покупки) валюты/статусов/внутриигровых предметов/«буста» аккаунта у игроков.
⛔ Наказание: вечная блокировка,полное обнуление.

2.4 Запрещен обман игроков и/или администрации.
⛔ Наказание: блокировка аккаунта на 7 дней.

2.5 Запрещено выдавать себя за администрацию проекта.
⛔ Наказание: блокировка аккаунта на 3 дня.

2.6 Запрещена продажа/покупка/передача аккаунтов (исключение: на аккаунт зашел близкий родственник).
⛔ Наказание: вечная блокировка, полное обнуление.

2.7 Запрещены махинации (попытки) оплатами.
⛔ Наказание: блокировка навсегда, полное обнуление.

2.8 Запрещено ставить титул на подобии "Администратор", "Основатель", а также в оскорбительной и рекламной форме.
⛔ Наказание: удаление титула (Повторное нарушение = блокировка на 7 дней).

2.9 Запрещено ставить оскорбительные ники, используя ненормативную лексику, или вызвать агрессию с помощью ника.
⛔ Наказание: блокировка на 7 дней.

Комментарии и беседы бота:
3.1 Запрещено оскорбление других участников и/или родителей.
⛔ Наказание: бан на 7 дней.

3.2 Запрещено рекламировать, оставлять ссылки (в том числе и гиперссылки) не относящихся к боту.
⛔ Наказание: занесение в чёрный список группы / черный список бота.

Общение:
4.1 Запрещено оскорбление/затрагивание родных.
⛔ Наказание: блокировка на 7 дней.

4.2 Запрещено оскорбление администрации.
⛔ Наказание: блокировка на 7 дней.

4.3 Запрещен флуд/спам в репорт.
⛔ Наказание: блокировка репорта на 3 дня.

4.4 Ввод в заблуждение игроков.
⛔ Наказание: блокировка (кол-во дней - по усмотрению администрации).

4.5 Склонения к самоубийству (Призывы к суициду или нанесению себе увечий)
⛔ Наказание: вечная блокировка аккаунта, занесение в ЧС группы.

4.6 Враждебные высказывания (Выражение нетерпимости к людям из-за расы, национальности, вероисповедания, гендера, сексуальной ориентации и других признаков)
⛔ Наказание: блокировка на 30 дней (Повторное нарушение = блокировка навсегда).

4.7 Призывы к травле (Призывы применять физическую силу и унижать конкретного человека)
⛔ Наказание: вечная блокировка аккаунта, занесение в ЧС группы.

4.8 Любое упоминание/пропагандирование наркотических вещ-в, сильного табака.
⛔ Наказание: блокировка на 7 дней (Повторное нарушение = блокировка на 30 дней).

Пожертвования
5.1 Оплачивая что-либо в разделе "товары", Вы помогаете проекту в развитии и обязательно получаете вознаграждение в виде ИГРОВОЙ валюты.
5.2 Администрация не возвращает пожертвования и не переносит полученное вознаграждение на другой аккаунт.
5.3 Игровая валюта не имеет никакой привязки к реальным деньгам, не имеет никакой реальной фактической стоимости и используется исключительно для использования в рамках игрового процесса.
5.4 Покупка доната только через команду "Пополнить"

⚠️ 2 часть правил по кнопке ниже! 🔜`,
      {
        keyboard: JSON.stringify({
          inline: true,
          buttons: [
            [
              {
                action: {
                  type: "text",
                  payload: "{}",
                  label: "⚠️ Правила (2 ч.)",
                },
                color: "default",
              },
            ],
          ],
        }),
      }
    );
  }
);

cmd.hear(
  /^(?:правила 2|правила (2ч.)|⚠️ Правила \(2 ч.\))$/i,
  async (message, bot) => {
    return bot(
      `Прочее

6.1 Запрещено преднамеренно использовать баги и недочеты бота.
⛔ Наказание: блокировка аккаунта, полное/частичное обнуление.

6.2 Запрещены попытки навредить боту или заблокировать его.
⛔ Наказание: вечная блокировка аккаунта, занесение в черный список группы.

6.3 Разжигание межнациональной розни (действия, направленные на возбуждение межнациональной или межрасовой вражды)
⛔ Наказание: вечная блокировка аккаунта, занесение в черный список группы.`,
      {
        keyboard: JSON.stringify({
          inline: true,
          buttons: [
            [
              {
                action: {
                  type: "text",
                  payload: "{}",
                  label: "⚠️ Правила (1 ч.) ◀️",
                },
                color: "default",
              },
            ],
          ],
        }),
      }
    );
  }
);

cmd.hear(/^(?:кн помощь|крестики нолики)$/i, async (message, bot) => {
  return bot(
    " помощь по игре крестики нолики:\n⚠Вы всегда ходите крестиком, бот ходит ноликом.\n⚠Кн начать - начать новую игру\n⚠Кн [1-9] - сделать ход (если игра не начата, она автоматически начнется)\n⚠ После каждой игры боту необходимо отдохнуть от 1 до 4 минут"
  );
});

cmd.hear(/^(?:кн начать)$/i, async (message, bot) => {
  if (message.user.timers.gamekn > Date.now())
    return bot(
      `Подождите ещё ${unixstampLefta(
        message.user.timers.gamekn - Date.now()
      )} для следующей игры! ⚠️`
    );

  let pole = [
    0, 0, 0,

    0, 0, 0,

    0, 0, 0,
  ];

  let txt;

  message.user.pole = pole;

  if (message.user.knbot === true) {
    message.user.knbot = false;

    txt = "Бот ходит первым! ( ⭕ )\n";

    let rn = utils.pick([4, 0, 2, 6, 8]);

    pole[rn] = 2;

    for (let i = 0; i < 9; i++) {
      if (pole[i] === 0) {
        txt += "⬛";
      } else if (pole[i] === 2) {
        txt += "⭕";
      }

      if (i === 2 || i === 5) {
        txt += "\n";
      }
    }

    return bot(txt);
  } else {
    message.user.knbot = true;

    txt += "игра в кн началась (❌)\n⬛⬛⬛\n⬛⬛⬛\n⬛⬛⬛";

    message.user.knbot = true;

    txt = "Игра в крестики-нолики началась, бот ходит первым ( ⭕ )\n";

    let rn = utils.pick([4, 0, 2, 6, 8]);

    pole[rn] = 2;

    for (let i = 0; i < 9; i++) {
      if (pole[i] === 0) {
        txt += "⬛";
      } else if (pole[i] === 2) {
        txt += "⭕";
      }

      if (i === 2 || i === 5) {
        txt += "\n";
      }
    }

    return bot(txt);
  }
});

cmd.hear(/^(?:кн)\s([1-9])$/i, async (message, bot) => {
  if (
    Number(message.args[1]) < 1 ||
    Number(message.args[1]) > 9 ||
    parseInt(message.args[1]) !== Number(message.args[1])
  ) {
    return bot("Использование: Кн [номер клетки]");
  }

  if (message.user.timers.gamekn > Date.now())
    return bot(
      `Подождите ещё ${unixstampLefta(
        message.user.timers.gamekn - Date.now()
      )} для следующей игры! ⚠️`
    );

  utils.pick([
    `🤘`,
    `💥`,
    `💣`,
    `😻`,
    `😏`,
    `🤒`,
    `🤔`,
    `💎`,
    `♻`,
    `🏆`,
    `🔥`,
    `🌚`,
    `👻`,
    `💀`,
    `🎄`,
    `🎃`,
    `🚀`,
    `🎱`,
    `🍼`,
    `🍺`,
    `🐔`,
    `🐉`,
    `🌝`,
  ]);

  let pole = [
    0, 0, 0,

    0, 0, 0,

    0, 0, 0,
  ];

  let txt = "";

  if (typeof message.user.pole != "object") {
    message.user.pole = pole;

    if (message.user.knbot === true) {
      message.user.knbot = false;

      txt = "Бот ходит первым ( ⭕ )\n";

      let rn = utils.pick([5, 0, 2, 6, 8]);

      pole[rn] = 2;

      for (let i = 0; i < 9; i++) {
        if (pole[i] === 0) {
          txt += "⬛";
        } else if (pole[i] === 2) {
          txt += "⭕";
        }

        if (i === 2 || i === 5) {
          txt += "\n";
        }
      }

      return bot(txt);
    } else {
      message.user.knbot = true;

      txt += "Игра в крестики-нолики началась! ( ❌ )\n⬛⬛⬛\n⬛⬛⬛\n⬛⬛⬛";

      return bot(txt);
    }
  } else {
    pole = message.user.pole;

    txt += "Ваш ход ( ❌ )";
  }

  if (pole[Number(message.args[1]) - 1] === 0) {
    pole[Number(message.args[1]) - 1] = 1;
  } else {
    txt = "клетка уже занята!!!\n";

    for (let i = 0; i < 9; i++) {
      if (pole[i] === 0) {
        txt += "⬛";
      } else if (pole[i] === 1) {
        txt += "❌";
      } else if (pole[i] === 2) {
        txt += "⭕";
      }

      if (i === 2 || i === 5) {
        txt += "\n";
      }
    }

    return bot(txt);
  }

  if (
    (pole[1] === 2 && pole[2] === 2 && pole[0] === 0) ||
    (pole[3] === 2 && pole[6] === 2 && pole[0] === 0) ||
    (pole[4] === 2 && pole[8] === 2 && pole[0] === 0)
  ) {
    pole[0] = 2;
  } else if (
    (pole[0] === 1 && pole[4] === 2 && pole[8] === 1 && pole[1] === 0) ||
    (pole[2] === 1 && pole[4] === 2 && pole[6] === 1 && pole[1] === 0) ||
    (pole[0] === 2 && pole[2] === 2 && pole[1] === 0) ||
    (pole[4] === 2 && pole[7] === 2 && pole[1] === 0)
  ) {
    pole[1] = 2;
  } else if (
    (pole[0] === 2 && pole[1] === 2 && pole[2] === 0) ||
    (pole[5] === 2 && pole[8] === 2 && pole[2] === 0) ||
    (pole[4] === 2 && pole[6] === 2 && pole[2] === 0)
  ) {
    pole[2] = 2;
  } else if (
    (pole[4] === 2 && pole[5] === 2 && pole[3] === 0) ||
    (pole[0] === 2 && pole[6] === 2 && pole[3] === 0)
  ) {
    pole[3] = 2;
  } else if (
    (pole[1] === 2 && pole[7] === 2 && pole[4] === 0) ||
    (pole[3] === 2 && pole[5] === 2 && pole[4] === 0) ||
    (pole[0] === 2 && pole[8] === 2 && pole[4] === 0) ||
    (pole[2] === 2 && pole[6] === 2 && pole[4] === 0)
  ) {
    pole[4] = 2;
  } else if (
    (pole[2] === 2 && pole[8] === 2 && pole[5] === 0) ||
    (pole[3] === 2 && pole[4] === 2 && pole[5] === 0)
  ) {
    pole[5] = 2;
  } else if (
    (pole[4] === 2 && pole[2] === 2 && pole[6] === 0) ||
    (pole[8] === 2 && pole[7] === 2 && pole[6] === 0)
  ) {
    pole[6] = 2;
  } else if (
    (pole[6] === 2 && pole[8] === 2 && pole[7] === 0) ||
    (pole[4] === 2 && pole[1] === 2 && pole[7] === 0)
  ) {
    pole[7] = 2;
  } else if (
    (pole[0] === 2 && pole[4] === 2 && pole[8] === 0) ||
    (pole[6] === 2 && pole[7] === 2 && pole[8] === 0) ||
    (pole[5] === 2 && pole[2] === 2 && pole[8] === 0)
  ) {
    pole[8] = 2;
  } else if (
    (pole[1] === 1 && pole[2] === 1 && pole[0] === 0) ||
    (pole[3] === 1 && pole[6] === 1 && pole[0] === 0) ||
    (pole[4] === 1 && pole[8] === 1 && pole[0] === 0)
  ) {
    pole[0] = 2;
  } else if (
    (pole[0] === 1 && pole[2] === 1 && pole[1] === 0) ||
    (pole[4] === 1 && pole[7] === 1 && pole[1] === 0)
  ) {
    pole[1] = 2;
  } else if (
    (pole[0] === 1 && pole[1] === 1 && pole[2] === 0) ||
    (pole[5] === 1 && pole[8] === 1 && pole[2] === 0) ||
    (pole[4] === 1 && pole[6] === 1 && pole[2] === 0)
  ) {
    pole[2] = 2;
  } else if (
    (pole[4] === 1 && pole[5] === 1 && pole[3] === 0) ||
    (pole[0] === 1 && pole[6] === 1 && pole[3] === 0)
  ) {
    pole[3] = 2;
  } else if (
    (pole[1] === 1 && pole[7] === 1 && pole[4] === 0) ||
    (pole[3] === 1 && pole[5] === 1 && pole[4] === 0) ||
    (pole[0] === 1 && pole[8] === 1 && pole[4] === 0) ||
    (pole[2] === 1 && pole[6] === 1 && pole[4] === 0)
  ) {
    pole[4] = 2;
  } else if (
    (pole[2] === 1 && pole[8] === 1 && pole[5] === 0) ||
    (pole[3] === 1 && pole[4] === 1 && pole[5] === 0)
  ) {
    pole[5] = 2;
  } else if (
    (pole[0] === 1 && pole[3] === 1 && pole[6] === 0) ||
    (pole[7] === 1 && pole[8] === 1 && pole[6] === 0) ||
    (pole[4] === 1 && pole[2] === 1 && pole[6] === 0)
  ) {
    pole[6] = 2;
  } else if (
    (pole[6] === 1 && pole[8] === 1 && pole[7] === 0) ||
    (pole[4] === 1 && pole[1] === 1 && pole[7] === 0)
  ) {
    pole[7] = 2;
  } else if (
    (pole[0] === 1 && pole[4] === 1 && pole[8] === 0) ||
    (pole[6] === 1 && pole[7] === 1 && pole[8] === 0) ||
    (pole[5] === 1 && pole[2] === 1 && pole[8] === 0)
  ) {
    pole[8] = 2;
  } else if (pole[1] === 1 && pole[3] === 1 && pole[0] === 0) {
    pole[0] = 2;
  } else if (pole[1] === 1 && pole[5] === 1 && pole[2] === 0) {
    pole[2] = 2;
  } else if (pole[3] === 1 && pole[7] === 1 && pole[6] === 0) {
    pole[6] = 2;
  } else if (pole[5] === 1 && pole[7] === 1 && pole[8] === 0) {
    pole[8] = 2;
  } else {
    if (pole[4] === 0) {
      pole[4] = 2;
    } else if (pole[0] === 0) {
      pole[0] = 2;
    } else if (pole[2] === 0) {
      pole[2] = 2;
    } else if (pole[6] === 0) {
      pole[6] = 2;
    } else if (pole[8] === 0) {
      pole[8] = 2;
    } else if (pole[1] === 0) {
      pole[1] = 2;
    } else if (pole[3] === 0) {
      pole[3] = 2;
    } else if (pole[5] === 0) {
      pole[5] = 2;
    } else if (pole[7] === 0) {
      pole[7] = 2;
    }
  }

  message.user.pole = pole;

  txt += "\n";

  if (
    (pole[0] === 1 && pole[1] === 1 && pole[2] === 1) ||
    (pole[3] === 1 && pole[4] === 1 && pole[5] === 1) ||
    (pole[6] === 1 && pole[7] === 1 && pole[8] === 1) ||
    (pole[0] === 1 && pole[3] === 1 && pole[6] === 1) ||
    (pole[1] === 1 && pole[4] === 1 && pole[7] === 1) ||
    (pole[2] === 1 && pole[5] === 1 && pole[8] === 1) ||
    (pole[0] === 1 && pole[4] === 1 && pole[8] === 1) ||
    (pole[2] === 1 && pole[4] === 1 && pole[6] === 1)
  ) {
    txt = `😃 Вы ВЫИГРАЛИ!\n\n💰 На Ваш баланс зачисленно 1.000.000.000.000$\n`;

    message.user.balance += 1000000000000;

    message.user.timers.gamekn = Date.now() + 240000;

    if (
      message.user.questallfucker &&
      typeof message.user.questtictactoe2 === "number"
    )
      message.user.questtictactoe2 += 1;

    message.user.pole = false;

    if (typeof message.user.questtictactoe === "number") {
      message.user.questtictactoe = true;

      message.user.questtictactoe = true;

      await bot(
        `Поздравляем, Вы выиграли в крестики нолики и получили 📦 1 Донат-кейс.`
      );

      message.user.c3 += 1;
    }

    if (
      typeof message.user.questtictactoe2 === "number" &&
      message.user.questtictactoe2 === 150
    ) {
      message.user.questtictactoe2 = true;

      message.user.questtictactoe2 = true;

      await bot(
        `Поздравляем, Вы выиграли в крестики нолики и получили 📦 2 Донат-кейса.`
      );

      message.user.c3 += 2;
    }
  } else if (
    (pole[0] === 2 && pole[1] === 2 && pole[2] === 2) ||
    (pole[3] === 2 && pole[4] === 2 && pole[5] === 2) ||
    (pole[6] === 2 && pole[7] === 2 && pole[8] === 2) ||
    (pole[0] === 2 && pole[3] === 2 && pole[6] === 2) ||
    (pole[1] === 2 && pole[4] === 2 && pole[7] === 2) ||
    (pole[2] === 2 && pole[5] === 2 && pole[8] === 2) ||
    (pole[0] === 2 && pole[4] === 2 && pole[8] === 2) ||
    (pole[2] === 2 && pole[4] === 2 && pole[6] === 2)
  ) {
    txt = `😕 К сожалению, Вы проиграли! Бот победил. 🥺\n`;

    message.user.timers.gamekn = Date.now() + 60000;

    message.user.pole = false;
  } else if (
    pole[0] !== 0 &&
    pole[1] !== 0 &&
    pole[2] !== 0 &&
    pole[3] !== 0 &&
    pole[4] !== 0 &&
    pole[5] !== 0 &&
    pole[6] !== 0 &&
    pole[7] !== 0 &&
    pole[8] !== 0
  ) {
    txt = "ничья\n";

    message.user.timers.gamekn = Date.now() + 60000;

    message.user.pole = false;
  }

  for (let i = 0; i < 9; i++) {
    if (pole[i] === 0) {
      txt += "⬛";
    } else if (pole[i] === 1) {
      txt += "❌";
    } else if (pole[i] === 2) {
      txt += "⭕";
    }

    if (i === 2 || i === 5) {
      txt += "\n";
    }
  }

  return bot(txt);
});

cmd.hear(
  /^(?:дайвинг|плавать|🎏 дайвинг|🎣 плавать|🎣 дайвинг|🐠 Дайвинг|🐠 Дайвинг!)$/i,
  async (message, bot) => {
    if (message.user.timers.daiving > Date.now())
      return bot(
        `отправиться на дайвинг можно будет через ${unixStampLefta(
          message.user.timers.daiving - Date.now()
        )} 🙂`
      );

    if (message.isChat) {
      if (chats) {
        if (chats.statuemsglvl >= 1) {
          message.user.timers.daiving = Date.now() + 480000;
        } else {
          message.user.timers.daiving = Date.now() + 600000;
        }
      }
    } else {
      message.user.timers.daiving = Date.now() + 600000;
    }

    if (message.user.settings.topdon) {
      message.user.timers.daiving = Date.now() + 120000;
    }

    if (message.user.settings.king) {
      message.user.timers.daiving = Date.now() + 60000;
    }

    let prize = utils.pick([1, 2, 2, 3, 4]);

    let denyushka = 0;

    denyushka += utils.pick([
      2500000000000, 25000000000, 50000000000, 250000000000,
    ]);

    if (prize === 1) {
      message.user.balance += denyushka;

      bot(
        `вы отправились в плавание на 150 метров 🐬, и Вам удалось сделать неплохие снимки разных рыб.

💰 За снимки Вам заплатили ${utils.sp(denyushka)}$`,
        { attachment: "photo-192023992_467239154" }
      );
    }

    if (prize === 2) {
      message.user.balance += denyushka;

      bot(
        `вам удалось заплыть довольно далеко 🐋, Вы успели поймать редкий вид рыбы.

💰 За находку Вам заплатили: ${utils.sp(denyushka)}$`,
        { attachment: "photo-192023992_467239155" }
      );
    }

    if (prize === 3) {
      message.user.balance -= 1000000;

      bot(
        `вы попытались заплытить поглубже, но Вам повстречалась акула 🦈.

❤ За лечение Вы заплатили 1.000.000$`,
        { attachment: "photo-192023992_467239156" }
      );
    }

    if (prize === 4) {
      message.user.balance += 10000000000;

      bot(
        `Вы заплыли очень далеко, и поймали очень редкий вид рыбы.

💰 За находку Вам заплатили: 10.000.000.000$`,
        { attachment: "photo-183294592_457239281" }
      );
    }

    if (prize === 5) {
      bot(
        `Вы решили поверить в себя, и поплыли не в ту сторону.\n\n🦑 Медуза ужалила вас в ногу и вы ничего не получили.`,
        { attachment: "photo-192023992_467239157" }
      );
    }
  }
);

cmd.hear(
  /^(?:охота|🏹 Охота|охотиться|сходить поохотиться|🏹 Охотиться|🏹 Охотиться!|🏹 Охота!)$/i,
  async (message, bot) => {
    if (message.user.timers.ohota > Date.now())
      return bot(
        `отправиться на дайвинг можно будет через ${unixStampLefta(
          message.user.timers.ohota - Date.now()
        )} 🏹 🦌`
      );

    if (message.isChat) {
      if (chats) {
        if (chats.statuemsglvl >= 1) {
          message.user.timers.ohota = Date.now() + 480000;
        } else {
          message.user.timers.ohota = Date.now() + 600000;
        }
      }
    } else {
      message.user.timers.ohota = Date.now() + 600000;
    }

    if (message.user.settings.topdon) {
      message.user.timers.daiving = Date.now() + 120000;
    }

    if (message.user.settings.king) {
      message.user.timers.ohota = Date.now() + 60000;
    }

    let prize = utils.pick([1, 1, 2, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6]);

    if (prize === 1) {
      message.user.balance += 30000000000;

      return bot(
        `вы сходили на охоту в лес, и Вам удалось застрелить местного медведя 🐻

💰 За шкуру Вам заплатили 30.000.000.000$`,
        { attachment: "photo-192023992_467239161" }
      );
    }

    if (prize === 2) {
      message.user.balance += 100000000000;

      return bot(
        `пока Вы блуждали по лесу, Вы неожиданно встретили лису 🦊

💰 За хороший мех лисы Вам заплатили 100.000.000.000$`,
        { attachment: "photo-192023992_467239162" }
      );
    }

    if (prize === 3) {
      message.user.balance += 120000000000;

      return bot(
        `Вы зашли далеко в лес, и нашли очень дорогого зверька.

🦇 Вам заплатили за его снимки 120.000.000.000$`,
        { attachment: "photo-183294592_457239280" }
      );
    }

    if (prize === 4) {
      return bot(
        `вы решили пойти не в ту сторону леса, и наткнулись на дикого кабана. Вы выстрелили всю обойму, но кабан успел убежать 🏹

💰 Вам ничего не заплатили.`,
        { attachment: "photo-192023992_467239163" }
      );
    }

    if (prize === 5) {
      message.user.balance -= 25000000;

      return bot(
        `пока Вы болтали со своим партнёром по охоте, на Вас внезапно набросился свирепый волк 🐺

🧰 За лечение Вы заплатили 25.000.000$`,
        { attachment: "photo-192023992_467239164" }
      );
    }

    if (prize === 6) {
      message.user.balance -= 5000000;

      return bot(
        `Вы блуждали по лесу в поисках животины, но Вас неожиданно поймала лесная полиция за ловлю животных в не предназначенном для этого места 🚨

🆘 Вам пришлось заплатить штраф 5.000.000$ 🚨`,
        { attachment: "photo-192023992_467239165" }
      );
    }
  }
);

cmd.hear(/^(?:квесты|квест)$/i, async (message, bot) => {
  if (message.user.sataka >= 5000 && message.user.questbosspower2 == false) {

    await bot(`Ваша сила больше 5000, вы получаете бонус за свою силу в виде 500трлн$`)

    message.user.balance += 500000000000000;

    message.user.questbosspower2 = true;

  }



  if (message.user.questcasino == true && message.user.questcup == true && message.user.questrussion == true && message.user.questracer == true && message.user.questdonat == true && message.user.questminer == true && message.user.questhack == true && message.user.questclan == true && message.user.questautosound == true && message.user.questfollow == true && message.user.questdamagedealer == true && message.user.questbosspower == true && message.user.questallfucker == false) {

    await bot(`Вы выполнили все квесты и получаете секретный кейс`);

    message.user.c6 += 1;

    message.user.questallfucker = true;

  }

  if (message.user.questbasket == true && message.user.questcup2 == true && message.user.questrussion2 == true && message.user.questracer2 == true && message.user.questdonat2 == true && message.user.questminer2 == true && message.user.questpremcase == true && message.user.questhack2 == true && message.user.questtrade == true && message.user.questautosound2 == true && message.user.questtictactoe2 == true && message.user.questtaxi == true && message.user.questdamagedealer2 == true && message.user.questbosspower2 == true && message.user.questallfucker == true && message.user.questallfucker2 == false) {

    await bot(`Вы выполнили все квесты второй линии и получаете премиум посылку`);

    message.user.possilka3 += 1;

    message.user.questallfucker2 = true;

  }

  let text = ``;

  if (!message.user.questallfucker) {

    text += message.user.questcasino === true ? `✅` : `❌`;

    text += ` 1. 5 раз подряд выиграть в казино\n🎁 Приз: 1 донат кейс\n\n`;

    text += message.user.questcup === true ? `✅` : `❌`;

    text += ` 2. 3 раза подряд отгадать стаканчик\n🎁 Приз: 50трлн$\n\n`;

    text += message.user.questrussion === true ? `✅` : `❌️`;

    text += ` 3. 4 раза подряд выиграть в русскую рулетку\n🎁 Приз: 2 донат кейса\n\n`;

    text += message.user.questracer === true ? `✅` : `❌`;

    text += ` 4. 5 раз участвовать в гонке\n🎁 Приз: 1 донат-кейс\n\n`;

    text += message.user.questdonat === true ? `✅` : `❌`;

    text += ` 5. открыть 5 донат-кейсов\n🎁 Приз: 1 донат-кейс\n\n`;

    text += message.user.questminer === true ? `✅` : `❌️`;

    text += ` 6. 50 раз копать руду\n🎁 Приз: 1 донат-кейс\n\n`;

    // text += message.user.questbrak === true ? `✅` : `❌`;

    // text += ` 7. Вступить в брак\n🎁 Приз: 1 донат-кейс\n\n`;

    text += message.user.questhack === true ? `✅` : `❌️`;

    text += ` 8. открыть 2 сейфа\n🎁 Приз: 1 донат-кейс\n\n`;

    text += message.user.questclan === true ? `✅` : `❌`;

    text += ` 9. Вступить в клан\n🎁 Приз: 50трлн$\n\n`;

    text += message.user.questautosound === true ? `✅` : `❌`;

    text += ` 10. Учавствовать в соревнованиях по автозвуку 5 раз\n🎁 Приз: 1 донат-кейс\n\n`;

    text += message.user.questfollow === true ? `✅` : `❌️`;

    text += ` 11. Подписаться на группу\n🎁 Приз: 25трлн$\n\n`;

    text += message.user.questdamagedealer === true ? `✅` : `❌️`;

    text += ` 12. Нанести 250тыс. урона боссу\n🎁 Приз: 50трлн$\n\n`;

    text += message.user.questbosspower === true ? `✅` : `❌`;

    text += ` 13. Прокачать силу удара (босса) до 700\n🎁 Приз: 250трлн$\n\n`;

    text += message.user.questallfucker === true ? `✅` : `❌`;

    text += ` 14. Пройти все квесты\n🎁 Приз: 1 секретный кейс\n `;

    return bot(`одноразовые квесты:\n${text}`);

  } else {

    text += message.user.questbasket === true ? `✅` : `❌`;

    if (typeof message.user.questbasket === "number") text += ` 1. 100 раз сыграть в баскетбол\n🎁 Приз: 2 донат кейса\n🤖Прогресс: [${message.user.questbasket}/100]\n`; //+

    if (typeof message.user.questbasket != "number") text += ` 1. 100 раз сыграть в баскетбол\n🎁 Приз: 2 донат кейса\n`; //+

    text += message.user.questcup2 === true ? `✅` : `❌️`;

    if (typeof message.user.questcup2 === "number") text += ` 2. 50 раз отгадать стаканчик\n🎁 Приз: 100трлн$\n🤖Прогресс: [${message.user.questcup2}/50]\n`; // +

    if (typeof message.user.questcup2 != "number") text += ` 2. 50 раз отгадать стаканчик\n🎁 Приз: 100трлн$\n`;

    text += message.user.questrussion2 === true ? `✅` : `❌`;

    if (typeof message.user.questrussion2 === "number") text += ` 3. 100 раз сыграть в русскую рулетку\n🎁 Приз: 4 донат кейса\n🤖Прогресс: [${message.user.questrussion2}/100]\n`; // +

    if (typeof message.user.questrussion2 != "number") text += ` 3. 100 раз сыграть в русскую рулетку\n🎁 Приз: 4 донат кейса\n`;

    text += message.user.questracer2 === true ? `✅` : `❌`;

    if (typeof message.user.questracer2 === "number") text += ` 4. 500 раз участвовать в гонке\n🎁 Приз: 2 донат кейса\n🤖Прогресс: [${message.user.questracer2}/500]\n`; // +

    if (typeof message.user.questracer2 != "number") text += ` 4. 500 раз участвовать в гонке\n🎁 Приз: 2 донат кейса\n`; // +

    text += message.user.questdonat2 === true ? `✅️` : `❌`;

    if (typeof message.user.questdonat2 === "number") text += ` 5. открыть 50 донат-кейсов\n🎁 Приз: 2 донат кейса\n🤖Прогресс: [${message.user.questdonat2}/50]\n`; // +

    if (typeof message.user.questdonat2 != "number") text += ` 5. открыть 50 донат-кейсов\n🎁 Приз: 2 донат кейса\n`;

    text += message.user.questminer2 === true ? `✅` : `❌️`;

    if (typeof message.user.questminer2 === "number") text += ` 6. 5000 раз копать руду\n🎁 Приз: 2 донат кейса\n🤖Прогресс: [${message.user.questminer2}/5000]\n`; //+

    if (typeof message.user.questminer2 != "number") text += ` 6. 5000 раз копать руду\n🎁 Приз: 2 донат кейса\n`;

    text += message.user.questtrade === true ? `✅` : `❌`;

    if (typeof message.user.questtrade === "number") text += ` 7. 50 раз сыграть в трейд\n🎁 Приз: 2 донат кейса\n🤖Прогресс: [${message.user.questtrade}/50]\n`;

    if (typeof message.user.questtrade != "number") text += ` 7. 50 раз сыграть в трейд\n🎁 Приз: 2 донат кейса\n`;

    text += message.user.questhack2 === true ? `✅️` : `❌`;

    if (typeof message.user.questhack2 === "number") text += ` 8. открыть 20 сейфов\n🎁 Приз: 2 донат кейса\n🤖Прогресс: [${message.user.questhack2}/20]\n`;

    if (typeof message.user.questhack2 != "number") text += ` 8. открыть 20 сейфов\n🎁 Приз: 2 донат кейса\n`;

    text += message.user.questtaxi === true ? `✅` : `❌`;

    if (typeof message.user.questtaxi === "number") text += ` 9. 500 раз попрошайничать\n🎁 Приз: 100трлн$\n🤖Прогресс: [${message.user.questtaxi}/500]\n`; // +

    if (typeof message.user.questtaxi != "number") text += ` 9. 500 раз попрошайничать\n🎁 Приз: 100трлн$\n`;

    text += message.user.questautosound2 === true ? `✅` : `❌️`;

    if (typeof message.user.questautosound2 === "number") text += ` 10. Учавствовать в соревнованиях по автозвуку 500 раз\n🎁 Приз: 2 донат кейса\n🤖Прогресс: [${message.user.questautosound2}/500]\n`;// +

    if (typeof message.user.questautosound2 != "number") text += ` 10. Учавствовать в соревнованиях по автозвуку 500 раз\n🎁 Приз: 2 донат кейса\n`;

    text += message.user.questtictactoe2 === true ? `✅` : `❌`;

    if (typeof message.user.questtictactoe2 === "number") text += ` 11. Выиграть в крестики нолики 150 раз\n🎁 Приз: 2 донат кейса\n🤖Прогресс: [${message.user.questtictactoe2}/150]\n`;// +

    if (typeof message.user.questtictactoe2 != "number") text += ` 11. Выиграть в крестики нолики 150 раз\n🎁 Приз: 2 донат кейса\n`;

    text += message.user.questpremcase === true ? `✅` : `❌️`;

    text += ` 12. Открыть премиум кейс\n  приз: 50трлн$\n`; // +

    text += message.user.questdamagedealer2 === true ? `✅️` : `❌`;

    if (typeof message.user.questdamagedealer2 === "number") text += ` 13. Нанести 1 млн урона боссу\n🎁 Приз: 100трлн$\n🤖Прогресс: [${message.user.questdamagedealer2}/1.000.000]\n`; // +

    if (typeof message.user.questdamagedealer2 != "number") text += ` 13. Нанести 1 млн урона боссу\n🎁 Приз: 100трлн$\n`;

    text += message.user.questbosspower2 === true ? `✅` : `❌`;

    text += ` 14. Прокачать силу удара (босса) до 5000 ед.\n🎁 Приз: 500трлн$\n`; // +

    text += message.user.questallfucker2 === true ? `✅️` : `❌`;

    text += ` 15. Пройти все квесты\n🎁 Приз: премиум посылка\n `; // +

    return bot(`Вторая линия квестов:\n${text}`);

  }
});

cmd.hear(/^(?:стаканчик)\s([1-3])\s(.*)$/i, async (message, bot) => {

  message.args[2] = message.args[2].replace(/(\.|\,)/ig, '');

  message.args[2] = message.args[2].replace(/(к|k)/ig, '000');

  message.args[2] = message.args[2].replace(/(м|m)/ig, '000000');

  message.args[2] = message.args[2].replace(/(вабанк|вобанк|все|всё)/ig, message.user.balance);



  const smileos = utils.pick(['😇']);

  const smileyes = utils.pick(['🙂', '😃', '😄', '🤑', '☺']);

  const smileno = utils.pick(['😕', '😔', '😫']);



  if (!Number(message.args[2])) return;

  message.args[2] = Math.floor(Number(message.args[2]));



  if (message.args[2] <= 0) return;



  if (message.args[2] > message.user.balance) return bot(`у Вас недостаточно денег! 💰❌



💵 Ваш баланс: ${utils.sp(message.user.balance)}$ ❄️`);

  else if (message.args[2] <= message.user.balance) {

    message.user.balance -= message.args[2];

    const multiply = utils.pick([1.95, 1.90, 1.85, 1.80, 1.75, 1.70, 1.65]);

    const cup = utils.random(1, 3);

    if (cup == message.args[1]) {

      if (typeof message.user.questcup === "number") {

        message.user.questcup++;

        if (message.user.questallfucker == true) message.user.questcup2++;

        if (message.user.questcup >= 3) {

          message.user.questcup = true;

          await bot(`Поздравляем, Вы 3 раза выиграли в стаканчике и получаете 5О.ООО.ООО.ООО.ООО$`);

          message.user.balance += 50000000000000;

        }

        if (message.user.questcup2 >= 50) {

          message.user.questcup2 = true;

          await bot(`Поздравляем, Вы 50 раз выиграли в стаканчике и получаете 1ОО.ООО.ООО.ООО.ООО$`);

          message.user.balance += 100000000000000;

        }

      }

      if (typeof message.user.questcup2 === "number") {

        if (message.user.questallfucker == true) message.user.questcup2++;

        if (message.user.questcup2 >= 50) {

          message.user.questcup2 = true;

          await bot(`Поздравляем, Вы 50 раз выиграли в стаканчике и получаете 1ОО.ООО.ООО.ООО.ООО$`);

          message.user.balance += 100000000000000;

        }

      }

      message.user.balance += Math.floor(message.args[2] * multiply);



      return bot(`вы угадали! 🎊\n✅ Приз ${utils.sp(Math.floor(message.args[2] * multiply))}$ 💵`);

    } else {

      if (typeof message.user.questcup === "number") {

        message.user.questcup = 0;

      }

      return bot(`НЕУСПЕШНО! ❌\n\n🥛 Это был ${cup}-ый стаканчик. 😡`);

    }

  }

});


cmd.hear(/^(?:стату(я|и))$/i, async (message, bot) => {
  return bot(
    `Список статуй:

💰 Статуя денег
💬 Статуя актива
👥 Статуя людей

🎁 При полной прокачки всех 3-х статуй, можно получить подарок «статуя подарок»`,
    {
      attachment: "photo-197579361_457262063",
      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",

                payload: '{"button": "1"}',

                label: "Статуя денег",
              },

              color: "default",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "Статуя актива",
              },

              color: "default",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "Статуя людей",
              },

              color: "default",
            },
          ],
        ],
      }),
    }
  );
});


cmd.hear(/^(?:адопмагазин)$/i, async (message, bot) => {
  if (message.user.settings.adm < 3) return bot(`Bad error.`);

  return bot(`дополнительный-админ-магазин:



Скоро...`);
});

cmd.hear(/^(?:амагазин)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1)
    return bot(`Ты не администратор лучшего бота!`);

  return bot(`донат-админ-магазин:

🏆 Товары »
1&#8419; lvlup 1 | 500 RUB
2&#8419; lvlup 2 | 1600 RUB
3&#8419; Лимит выдачи | 25 RUB/1кккк
4&#8419; Кейс | 50 RUB (падает: от 1.000.000.000 до 3.000.000.000.000$ к лим. выдачи)

💡 Для покупки введите "Амагазин [название]".\n✏️ Пример: "Амагазин lvlup 1"\n\n
💡 Для оптовой покупки лимита/кейсов введите "Амагазин [название] [количество]".\n✏️ Пример: "Амагазин лимит выдачи 4"`);
});

cmd.hear(/^(?:донат|☄️ Донат)$/i, async (message, bot) => {
  if (message.user.rubli === undefined) {
    message.user.rubli = 0;
  }
  let text = ``;
  if (botinfo.donx3) text += `\n✅ СЕЙЧАС ДЕЙСТВУЕТ Х2 ПОПОЛНЕНИЕ! 🤑`;
  if (botinfo.sell25) text += `\n😱 СЕЙЧАС ДЕЙСТВУЮТ СКИДКИ 25%`;
  if (!botinfo.sell25) {
    return bot(`донат-магазин:

👤 ➖ Привилегии:
1&#8419; Администратор | 1500 RUB
2&#8419; Titan | 700 RUB
3&#8419; Premium |500 RUB
4&#8419; VIP | 200 RUB

📦 ➖ Посылки:
5&#8419; Посылка1 | 15 RUB
6&#8419; Посылка2 | 30 RUB
7&#8419; Посылка3 | 100 RUB

📦 ➖ Кейсы:
8&#8419; Донат-кейс | 30 RUB
9&#8419; Секретный-кейс | 50 RUB

💬 ➖ Разное:
1&#8419;0&#8419; Киностудия - 3.000.000.000.000$/час | 200 RUB
1&#8419;1&#8419; Аэропорт - 5.000.000.000.000$/час | 250 RUB
1&#8419;2&#8419; Лимит ферм | 200 RUB
1&#8419;3&#8419; Донатный гигант | 1000 RUB

🔥 ➖ Новые привилегии:
1&#8419;4&#8419; Император | 900 RUB
1&#8419;5&#8419; Джокер | 1000 RUB
1&#8419;6&#8419; Бизнесмен | 600 RUB

🆕🔥 ➖ GB :
1&#8419;7&#8419; 15.000 GB | 15 RUB
1&#8419;8&#8419; 50.000 GB | 45 RUB
1&#8419;9&#8419; 100.000 GB | 90 RUB
2&#8419;0&#8419; 250.000 GB | 240 RUB
2&#8419;1&#8419; 500.000 GB | 470 RUB
2&#8419;2&#8419; 1.000.000 GB | 980 RUB
2&#8419;3&#8419; 1.500.000 GB | 1300 RUB
2&#8419;4&#8419; 2.500.000 GB | 2400 RUB
2&#8419;5&#8419; 5.000.000 GB | 4900 RUB

💡 Покупка: Купить [номер]
💡 Покупка кейсов: Купить [8/9] [количество]
💡 Покупка посылок: Купить [5/6/7] [количество]

💰 Ваш баланс: ${utils.sp(message.user.rubli)} руб. 💵
✅ Пополнить баланс ➤ Пополнить [число].${text}`);
  } else {
    return bot(`донат-магазин:

👤 ➖ Привилегии:
1&#8419; Администратор | 🆘 1125 RUB ВМЕСТО 1500 RUB
2&#8419; Titan | 🆘 525 RUB ВМЕСТО 700 RUB
3&#8419; Premium | 🆘 375 RUB ВМЕСТО 500 RUB
4&#8419; VIP | 🆘 150 RUB ВМЕСТО 200 RUB

📦 ➖ Посылки:
5&#8419; Посылка1 | 🆘 11 RUB ВМЕСТО 15 RUB
6&#8419; Посылка2 | 🆘 22 RUB ВМЕСТО 30 RUB
7&#8419; Посылка3 | 🆘 75 RUB ВМЕСТО 100 RUB

📦 ➖ Кейсы:
8&#8419; Донат-кейс | 🆘 22 RUB ВМЕСТО 30 RUB
9&#8419; Секретный-кейс | 🆘 38 RUB ВМЕСТО 50 RUB

💬 ➖ Разное:
1&#8419;0&#8419; Киностудия - 3.000.000.000.000$/час | 🆘 150 RUB ВМЕСТО 200 RUB
1&#8419;1&#8419; Аэропорт - 5.000.000.000.000$/час | 🆘 188 RUB ВМЕСТО 250 RUB
1&#8419;2&#8419; Лимит ферм | 🆘 150 RUB ВМЕСТО 200 RUB
1&#8419;3&#8419; Донатный гигант | 🆘 750 RUB ВМЕСТО 1000 RUB

🔥 ➖ Новые привилегии:
1&#8419;4&#8419; Император | 🆘 675 RUB ВМЕСТО 900 RUB
1&#8419;5&#8419; Джокер | 🆘 750 RUB ВМЕСТО 1000 RUB
1&#8419;6&#8419; Бизнесмен | 🆘 450 RUB ВМЕСТО 600 RUB

🆕🔥 ➖ GB :
1&#8419;7&#8419; 15.000 GB | 🆘 11 RUB ВМЕСТО 15 RUB
1&#8419;8&#8419; 50.000 GB | 🆘 34 RUB ВМЕСТО 45 RUB
1&#8419;9&#8419; 100.000 GB | 🆘 68 RUB ВМЕСТО 90 RUB
2&#8419;0&#8419; 250.000 GB | 🆘 180 RUB ВМЕСТО 240 RUB
2&#8419;1&#8419; 500.000 GB | 🆘 353 RUB ВМЕСТО 470 RUB
2&#8419;2&#8419; 1.000.000 GB | 🆘 735 RUB ВМЕСТО 980 RUB
2&#8419;3&#8419; 1.500.000 GB | 🆘 975 RUB ВМЕСТО 1300 RUB
2&#8419;4&#8419; 2.500.000 GB | 🆘 1800 RUB ВМЕСТО 2400 RUB
2&#8419;5&#8419; 5.000.000 GB | 🆘 3675 RUB ВМЕСТО 4900 RUB

💡 Покупка: Купить [номер]
💡 Покупка кейсов: Купить [8/9] [количество]
💡 Покупка посылок: Купить [5/6/7] [количество]

💰 Ваш баланс: ${utils.sp(message.user.rubli)} руб. 💵
✅ Пополнить баланс ➤ Пополнить [число].${text}`);
  }
});

cmd.hear(/^(?:купить)\s([\d]*)\s?([\d]*)$/i, async (message, bot) => {
  if (message.user.rubli === undefined) {
    message.user.rubli = 0;
  }

  if (Number(message.args[1]) === 1) {
    if (botinfo.sell25) {
      if (1500 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (1500 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    if (message.user.settings.adm > 0)
      return bot(`у вас уже есть статус администратор`);

    if (botinfo.sell25) {
      message.user.rubli -= 1500 * 0.75;
    } else {
      message.user.rubli -= 1500;
    }

    message.user.settings.adm = 1;

    message.user.bantop = true;

    message.user.stock.status = "Администратор";

    await vk.api.messages.send({
      user_id: message.senderId,

      message: `[УВЕДОМЛЕНИЕ]\n🛍 Админка выдана на аккаунт!\n🔥Ссылка на админ беседу: https://vk.me/join/GVuXcYgsUEZ3xbKiYi7suu1U5ucxy1sFRlM= `,

      random_id: 0,
    });

    return bot(`вы приобрели [Администратор] за 1500 рублей. 💥`);
  }

  if (Number(message.args[1]) === 2) {
    if (botinfo.sell25) {
      if (700 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (700 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    if (message.user.settings.adm >= 1)
      return bot(`Администраторам запрещено! ⛔`);

    if (botinfo.sell25) {
      message.user.rubli -= 700 * 0.75;
    } else {
      message.user.rubli -= 700;
    }

    message.user.settings.titan = true;

    message.user.limit.nicklimit = 48;

    message.user.level += 50;

    message.user.opit += 50000;

    message.user.limit.banklimit = 500000000000000;

    message.user.limit.farmlimit = 10000;

    message.user.limit.videocardlimit = 100;

    message.user.limit.playerlimit = 300000000000000;

    message.user.limit.sent = 0;

    message.user.maxenergy = 100;

    return bot(
      `вы приобрели [TITAN] за 700 рублей. 💥\n🔱 Помощь по командам - "TITAN help" `
    );
  }

  if (Number(message.args[1]) === 3) {
    if (500 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (500 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (500 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }
    if (message.user.settings.premium)
      return bot(`у вас уже имеется статус [Premium]. ✅`);

    if (message.user.settings.titan) {
      message.user.settings.premium = true;

      return bot(
        `вы приобрели [Premium] за 139 рублей. 💥\n🔱 Помощь по командам - "Premium help". `
      );
    }
    if (botinfo.sell25) {
      message.user.rubli -= 500 * 0.75;
    } else {
      message.user.rubli -= 500;
    }

    message.user.settings.premium = true;

    message.user.stock.status = "Premium";

    message.user.limit.nicklimit = 32;

    message.user.opit += 5000;

    message.user.level += 35;

    message.user.bilet += 5;

    message.user.limit.banklimit = 200000000000000;

    message.user.limit.farmlimit = 5000;

    message.user.limit.videocardlimit = 75;

    message.user.limit.playerlimit = 200000000000000;

    message.user.limit.sent = 0;

    message.user.maxenergy = 30;

    return bot(
      `вы приобрели [Premium] за 500 рублей. 💥\n🔱 Помощь по командам - "Premium help". `
    );
  }

  if (Number(message.args[1]) === 4) {
    if (200 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (200 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (200 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }
    if (message.user.settings.vip > false)
      return bot(`у вас уже имеется статус [VIP]. ✅`);

    if (message.user.settings.premium || message.user.settings.titan) {
      message.user.settings.vip = true;

      return bot(
        `вы приобрели [VIP] за 200 рублей. 💥\n🔱 Помощь по командам - "VIP help". `
      );
    }

    if (botinfo.sell25) {
      message.user.rubli -= 200 * 0.75;
    } else {
      message.user.rubli -= 200;
    }

    message.user.settings.vip = true;

    message.user.stock.status = "VIP";

    message.user.limit.nicklimit = 21;

    message.user.level += 5;

    message.user.bilet += 2;

    message.user.limit.banklimit = 100000000000000;

    message.user.limit.farmlimit = 3000;

    message.user.limit.videocardlimit = 50;

    message.user.limit.playerlimit = 100000000000000;

    message.user.limit.sent = 0;

    message.user.maxenergy = 20;

    return bot(
      `вы приобрели [VIP] за 200 рублей. 💥\n🔱 Помощь по командам - "VIP help". `
    );
  }

  if (Number(message.args[1]) === 5) {
    if (message.args[2]) cont = Number(message.args[2]);

    if (!message.args[2]) cont = 1;

    let sum = Math.floor(cont * 15);
    if (botinfo.sell25) {
      if (sum * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (sum > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }
    if (sum > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);

    message.user.possilka1 += cont;
    if (botinfo.sell25) {
      message.user.rubli -= sum * 0.75;
    } else {
      message.user.rubli -= sum;
    }

    // sum = sum * 0.75;
    // message.user.rubli -= sum;

    return bot(
      `вы приобрели [ДЕНЕЖНУЮ ПОСЫЛКУ] за ${sum} рублей, в количестве ${cont} шт. 💥\n🔱 Открыть: Посылка открыть 1. `
    );
  }

  if (Number(message.args[1]) === 6) {
    if (message.args[2]) cont = Number(message.args[2]);

    if (!message.args[2]) cont = 1;

    let sum = Math.floor(cont * 30);

    if (sum > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (sum * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (sum > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    message.user.possilka2 += cont;

    if (botinfo.sell25) {
      message.user.rubli -= sum * 0.75;
    } else {
      message.user.rubli -= sum;
    }

    // message.user.rubli -= sum;
    // sum = sum * 0.75;

    return bot(
      `вы приобрели [ЭЛИТНУЮ ПОСЫЛКУ] за ${sum} рублей, в количестве ${cont} шт. 💥\n🔱 Открыть: Посылка открыть 2. `
    );
  }

  if (Number(message.args[1]) === 7) {
    if (message.args[2]) cont = Number(message.args[2]);

    if (!message.args[2]) cont = 1;

    let sum = Math.floor(cont * 100);

    if (sum > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (sum * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (sum > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    message.user.possilka3 += cont;

    if (botinfo.sell25) {
      message.user.rubli -= sum * 0.75;
    } else {
      message.user.rubli -= sum;
    }

    // sum = sum * 0.75;

    return bot(
      `вы приобрели [ПРЕМИУМ ПОСЫЛКУ] за ${sum} рублей, в количестве ${cont} шт. 💥\n🔱 Открыть: Посылка открыть 3. `
    );
  }

  if (Number(message.args[1]) === 8) {
    if (message.args[2]) cont = Number(message.args[2]);

    if (!message.args[2]) cont = 1;

    let sum = Math.floor(cont * 30);
    if (botinfo.sell25) {
      sum = sum * 0.75;
    } else {
      sum = sum;
    }
    if (botinfo.sell25) {
      if (sum > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (sum > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }
    if (sum > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);

    message.user.c3 += cont;

    if (botinfo.sell25) {
      message.user.rubli -= sum;
    } else {
      message.user.rubli -= sum;
    }

    // message.user.rubli -= sum;

    return bot(
      `вы приобрели «Донат Кейс» за ${sum} рублей, в количестве ${cont} шт. 💥\n🔱 Открыть: Кейс открыть 3. `
    );
  }

  if (Number(message.args[1]) === 9) {
    if (message.args[2]) cont = Number(message.args[2]);

    if (!message.args[2]) cont = 1;

    let sum = Math.floor(cont * 50);
    if (botinfo.sell25) {
      sum = sum * 0.75;
    } else {
      sum = sum;
    }
    if (botinfo.sell25) {
      if (sum > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (sum > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }
    if (sum > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);

    message.user.c6 += cont;

    if (botinfo.sell25) {
      message.user.rubli -= sum;
    } else {
      message.user.rubli -= sum;
    }
    // message.user.rubli -= sum;

    return bot(
      `вы приобрели «Секретный Кейс» за ${sum} рублей, в количестве ${cont} шт. 💥\n🔱 Открыть: Кейс открыть 6. `
    );
  }

  if (Number(message.args[1]) === 10) {
    if (200 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (200 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (200 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }
    if (message.user.business.length >= 4)
      return bot(`у вас уже есть 4 бизнеса`);

    if (botinfo.sell25) {
      message.user.rubli -= 200 * 0.75;
    } else {
      message.user.rubli -= 200;
    }

    // message.user.rubli -= 200;

    message.user.business2.push({
      id: 16,

      upgrade: 1,

      workers: 7500,

      moneys: 0,
    });

    return bot(
      `вы приобрели Бизнес -- <<Киностудии по всему миру>>.\n🔱 Прибыль: 3.000.000.000.000$/час.`
    );
  }

  if (Number(message.args[1]) === 11) {
    if (250 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (250 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (250 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }
    if (message.user.business.length >= 4)
      return bot(`у вас уже есть 4 бизнеса`);

    if (botinfo.sell25) {
      message.user.rubli -= 250 * 0.75;
    } else {
      message.user.rubli -= 250;
    }
    // message.user.rubli -= 169;

    message.user.business2.push({
      id: 34,

      upgrade: 1,

      workers: 40000,

      moneys: 0,
    });

    return bot(
      `вы приобрели Бизнес -- <<Аэропорт>>.\n🔱 Прибыль: 5.000.000.000.000$/час.`
    );
  }

  if (Number(message.args[1]) === 12) {
    if (200 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (200 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (200 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    let sum = 0;
    // message.user.rubli -= 129;
    if (botinfo.sell25) {
      message.user.rubli -= 200 * 0.75;
      sum = 200 * 0.75;
    } else {
      message.user.rubli -= 200;
      sum = 200;
    }

    message.user.limit.farmlimit += 10000;

    return bot(
      `вы приобрели [ЛИМИТ ФЕРМ] за ${sum} рублей. 💥\n ✅ Ваш лимит: ${utils.sp(
        message.user.limit.farmlimit
      )}`
    );
  }

  if (Number(message.args[1]) === 13) {
    if (1000 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (1000 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (1000 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }
    if (message.user.stars5) return bot(`Вы уже купили данную звезду`);

    message.user.stars5 = true;

    // message.user.rubli -= 300;

    let sum = 0;
    if (botinfo.sell25) {
      message.user.rubli -= 1000 * 0.75;
      sum = 1000 * 0.75;
    } else {
      message.user.rubli -= 1000;
      sum = 1000;
    }

    return bot(`вы приобрели [ДОНАТНЫЙ ГИГАНТ] за ${sum} рублей. 💥`);
  }

  if (Number(message.args[1]) === 14) {
    if (900 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (900 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (900 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }
    if (message.user.settings.imperator) return bot(`Вы уже купили императора`);

    message.user.settings.imperator = true;
    message.user.limit.farmlimit = 1000000;
    message.user.limit.banklimit = 999999999999999999999999999999999999;
    // message.user.rubli -= 900;
    let sum = 0;
    if (botinfo.sell25) {
      message.user.rubli -= 900 * 0.75;
      sum = 900 * 0.75;
    } else {
      message.user.rubli -= 900;
      sum = 900;
    }

    return bot(`вы приобрели [ИМПЕРАТОР] за ${sum} рублей. 💥`);
  }

  if (Number(message.args[1]) === 15) {
    if (1000 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (1000 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (1000 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }
    if (message.user.settings.joker) return bot(`Вы уже купили джокера`);

    message.user.settings.joker = true;
    // message.user.rubli -= 1000;
    let sum = 0;
    if (botinfo.sell25) {
      message.user.rubli -= 1000 * 0.75;
      sum = 1000 * 0.75;
    } else {
      message.user.rubli -= 1000;
      sum = 1000;
    }
    return bot(`вы приобрели [ДЖОКЕР] за ${sum} рублей. 💥`);
  }

  if (Number(message.args[1]) === 16) {
    if (600 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (600 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (600 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }
    if (message.user.settings.busi) return bot(`Вы уже купили бизнесмена`);

    message.user.settings.busi = true;
    message.user.limit.banklimit = 999999999999999999999999999999999999;
    message.user.limit.farmlimit = 150000;
    // message.user.rubli -= 449;
    let sum = 0;
    if (botinfo.sell25) {
      message.user.rubli -= 600 * 0.75;
      sum = 600 * 0.75;
    } else {
      message.user.rubli -= 600;
      sum = 600;
    }

    return bot(`вы приобрели [БИЗНЕСМЕН] за ${sum} рублей. 💥`);
  }
  if (Number(message.args[1]) === 17) {
    // if (15 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (15 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (15 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    let sum = 0;
    // message.user.rubli -= 129;
    if (botinfo.sell25) {
      message.user.rubli -= 15 * 0.75;
      sum = 15 * 0.75;
    } else {
      message.user.rubli -= 15;
      sum = 15;
    }

    message.user.balance2 += 15000;

    return bot(
      `вы приобрели 15.000 GB за ${sum} рублей. 💥\n ✅ Ваш баланс: ${utils.sp(
        message.user.balance2
      )}`
    );
  }
  if (Number(message.args[1]) === 18) {
    // if (15 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (45 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (45 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    let sum = 0;
    // message.user.rubli -= 129;
    if (botinfo.sell25) {
      message.user.rubli -= 45 * 0.75;
      sum = 45 * 0.75;
    } else {
      message.user.rubli -= 45;
      sum = 45;
    }

    message.user.balance2 += 50000;

    return bot(
      `вы приобрели 50.000 GB за ${sum} рублей. 💥\n ✅ Ваш баланс: ${utils.sp(
        message.user.balance2
      )}`
    );
  }
  if (Number(message.args[1]) === 19) {
    // if (15 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (90 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (90 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    let sum = 0;
    // message.user.rubli -= 129;
    if (botinfo.sell25) {
      message.user.rubli -= 90 * 0.75;
      sum = 90 * 0.75;
    } else {
      message.user.rubli -= 90;
      sum = 90;
    }

    message.user.balance2 += 100000;

    return bot(
      `вы приобрели 100.000 GB за ${sum} рублей. 💥\n ✅ Ваш баланс: ${utils.sp(
        message.user.balance2
      )}`
    );
  }
  if (Number(message.args[1]) === 20) {
    // if (15 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (240 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (240 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    let sum = 0;
    // message.user.rubli -= 129;
    if (botinfo.sell25) {
      message.user.rubli -= 240 * 0.75;
      sum = 240 * 0.75;
    } else {
      message.user.rubli -= 240;
      sum = 240;
    }

    message.user.balance2 += 250000;

    return bot(
      `вы приобрели 250.000 GB за ${sum} рублей. 💥\n ✅ Ваш баланс: ${utils.sp(
        message.user.balance2
      )}`
    );
  }
  if (Number(message.args[1]) === 21) {
    // if (15 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (470 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (470 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    let sum = 0;
    // message.user.rubli -= 129;
    if (botinfo.sell25) {
      message.user.rubli -= 470 * 0.75;
      sum = 470 * 0.75;
    } else {
      message.user.rubli -= 470;
      sum = 470;
    }

    message.user.balance2 += 15000;

    return bot(
      `вы приобрели 500.000 GB за ${sum} рублей. 💥\n ✅ Ваш баланс: ${utils.sp(
        message.user.balance2
      )}`
    );
  }

  if (Number(message.args[1]) === 22) {
    // if (15 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (980 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (980 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    let sum = 0;
    // message.user.rubli -= 129;
    if (botinfo.sell25) {
      message.user.rubli -= 980 * 0.75;
      sum = 980 * 0.75;
    } else {
      message.user.rubli -= 980;
      sum = 980;
    }

    message.user.balance2 += 1000000;

    return bot(
      `вы приобрели 1.000.000 GB за ${sum} рублей. 💥\n ✅ Ваш баланс: ${utils.sp(
        message.user.balance2
      )}`
    );
  }

  if (Number(message.args[1]) === 17) {
    // if (15 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (1300 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (1300 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    let sum = 0;
    // message.user.rubli -= 129;
    if (botinfo.sell25) {
      message.user.rubli -= 1300 * 0.75;
      sum = 1300 * 0.75;
    } else {
      message.user.rubli -= 1300;
      sum = 1300;
    }

    message.user.balance2 += 1500000;

    return bot(
      `вы приобрели 1.500.000 GB за ${sum} рублей. 💥\n ✅ Ваш баланс: ${utils.sp(
        message.user.balance2
      )}`
    );
  }

  if (Number(message.args[1]) === 24) {
    // if (15 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (2400 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (2400 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    let sum = 0;
    // message.user.rubli -= 129;
    if (botinfo.sell25) {
      message.user.rubli -= 2400 * 0.75;
      sum = 2400 * 0.75;
    } else {
      message.user.rubli -= 2400;
      sum = 2400;
    }

    message.user.balance2 += 2500000;

    return bot(
      `вы приобрели 2.500.000 GB за ${sum} рублей. 💥\n ✅ Ваш баланс: ${utils.sp(
        message.user.balance2
      )}`
    );
  }
  if (Number(message.args[1]) === 25) {
    // if (15 > message.user.rubli) return bot(`недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`);
    if (botinfo.sell25) {
      if (4900 * 0.75 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    } else {
      if (4900 > message.user.rubli)
        return bot(
          `недостаточно рублей. \n 💡 У вас ${utils.sp(message.user.rubli)} руб`
        );
    }

    let sum = 0;
    // message.user.rubli -= 129;
    if (botinfo.sell25) {
      message.user.rubli -= 4900 * 0.75;
      sum = 4900 * 0.75;
    } else {
      message.user.rubli -= 4900;
      sum = 4900;
    }

    message.user.balance2 += 5000000;

    return bot(
      `вы приобрели 5.000.000 GB за ${sum} рублей. 💥\n ✅ Ваш баланс: ${utils.sp(
        message.user.balance2
      )}`
    );
  }


});



module.exports = commands;
