let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:svip)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 5) return;

  const user = await double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return;

  {
    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока`);

    if (user.settings.vip !== false) return bot("игрок уже является [VIP]. ⚠");

    if (user.settings.premium || user.settings.titan) {
      user.settings.vip = true;

      return bot(`Игрок назначен [VIP]💎`);
    }

    user.settings.vip = true;
    user.stock.status = "VIP";
    user.limit.nicklimit = 21;
    user.level += 5;
    user.limit.banklimit = 100000000000000;
    user.limit.farmlimit = 3000;
    user.limit.videocardlimit = 50;
    user.limit.playerlimit = 100000000000000;
    user.limit.sent = 0;
    user.maxenergy = 20;

    await bot(
      `Вы выдали привилегию «VIP» игроку @id${user.id} (${user.tag}) 😱`
    );

    if (user.notifications)
      await vk.api.messages.send({
        user_id: user.id,
        message: `▶️ Администратор @id${message.user.id} (${message.user.tag}) выдал Вам привилегию «VIP» 💎
〽 Чтобы просмотреть список доступных Вам команд и преимуществ, напишите «VIP help» ❄
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
        random_id: 0,
      });
  }
});

cmd.hear(/^(?:offvip)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 5) return;

  const user = await double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return;

  {
    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока`);

    if (user.settings.vip !== true)
      return bot("игрок не имеет [VIP] статуса. ⚠");

    user.settings.vip = false;

    user.stock.status = "Игрок";

    user.limit.nicklimit = 16;

    user.level -= 4;

    user.limit.banklimit = 50000000000000;

    user.limit.farmlimit = 1000;

    user.limit.videocardlimit = 30;

    user.limit.playerlimit = 50000000000000;

    user.limit.sent = 0;

    user.maxenergy = 10;

    await bot(
      `Вы забрали привилегию «VIP» у игрока @id${user.id} (${user.tag}) 😢`
    );

    if (user.notifications)
      await vk.api.messages.send({
        user_id: user.id,
        message: `▶️ Администратор @id${message.user.id} (${message.user.tag}) забрал Вашу привилегию «VIP» ❌
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
        random_id: 0,
      });
  }
});

cmd.hear(/^(?:бизнесмен прем)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.busi) {
    if (message.user.timers.busiprem >= Date.now())
      return bot(`👑 Премиум можно выдать раз в неделю.`);

    message.user.timers.busiprem = Date.now() + 604800000;

    const user = await double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return;

    {
      let user = double.find((x) => x.uid === Number(message.args[1]));

      if (!user) return bot(`неверный ID игрока`);

      if (user.settings.premium !== false)
        return bot("игрок уже является [Premium]. ⚠");

      user.settings.premium = true;

      user.stock.status = "Premium";

      user.limit.nicklimit = 32;

      user.level += 35;

      user.opit += 5000;

      user.limit.banklimit = 200000000000000;

      user.limit.farmlimit = 5000;

      user.limit.videocardlimit = 75;

      user.limit.playerlimit = 200000000000000;

      user.limit.sent = 0;

      user.maxenergy = 30;

      await bot(
        `Вы выдали привилегию «PREMIUM» игроку @id${user.id} (${user.tag}) 🤗`
      );

      if (user.notifications)
        await vk.api.messages.send({
          user_id: user.id,
          message: `▶️ Игрок @id${message.user.id} (${message.user.tag}) выдал Вам привилегию «PREMIUM» (команда бизнесмена) 🔥
〽️ Чтобы просмотреть список доступных Вам команд и преимуществ, напишите «Premium help» ❄️
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
          random_id: 0,
        });
    }
  }
});

cmd.hear(/^(?:sbusi)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 5) return;

  const user = await double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return;

  if (user.settings.busi) return bot(`игрок и так бизнесмен!`);

  user.settings.busi = true;

  user.balance += 9000000000000000;

  user.limit.banklimit = 10000000000000000000;

  user.limit.farmlimit = 150000;

  user.antiget = true;

  await bot(
    `Игрок (@id${user.id} (${user.tag})) получил привилегию «Бизнесмен» 🤗`
  );
});

cmd.hear(/^(?:sjoker)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 5) return;

  const user = await double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return;

  if (user.settings.joker) return bot(`игрок и так джокер!`);

  user.antiget = true;

  user.settings.joker = true;

  await bot(
    `Игрок (@id${user.id} (${user.tag})) получил привилегию «Джокер» 🤗`
  );
});

cmd.hear(/^(?:sprem)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 5) return;

  const user = await double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return;

  {
    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока`);

    if (user.settings.premium !== false)
      return bot(
        `Игрок [@id${user.id} (${user.tag})] уже имеет привилегию Premium 😸`
      );

    user.settings.premium = true;
    user.stock.status = "Premium";
    user.limit.nicklimit = 32;
    user.level += 35;
    user.opit += 5000;
    user.limit.banklimit = 200000000000000;
    user.limit.farmlimit = 5000;
    user.limit.videocardlimit = 75;
    user.limit.playerlimit = 200000000000000;
    user.limit.sent = 0;
    user.maxenergy = 30;

    await bot(`игрок назначен [Premium] 💎`);

    if (user.notifications)
      await vk.api.messages.send({
        user_id: user.id,
        message: `▶️ Администратор @id${message.user.id} (${message.user.tag}) выдал Вам привилегию «PREMIUM» 🔥
〽️ Чтобы просмотреть список доступных Вам команд и преимуществ, напишите «Premium help» ❄️
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
        random_id: 0,
      });
  }
});

cmd.hear(/^(?:offprem)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 5) return;

  const user = await double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return;

  {
    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока`);

    if (user.settings.premium !== true)
      return bot("игрок не имеет [Premium] статуса. ⚠");

    user.settings.premium = false;

    user.stock.status = "Игрок";

    user.level -= 19;

    user.opit -= 5000;

    user.limit.nicklimit = 16;

    user.limit.banklimit = 50000000000000;

    user.limit.farmlimit = 1000;

    user.limit.videocardlimit = 30;

    user.limit.playerlimit = 50000000000000;

    user.limit.sent = 0;

    user.maxenergy = 10;

    await bot(
      `Вы забрали статус «PREMIUM» у игрока @id${user.id} (${user.tag}) 😢`
    );

    if (user.notifications)
      await vk.api.messages.send({
        user_id: user.id,
        message: `▶️ Администратор @id${message.user.id} (${message.user.tag}) забрал Вашу привилегию «PREMIUM» ❌
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
        random_id: 0,
      });
  }
});

cmd.hear(/^(?:stitan)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 5) return;

  const user = await double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return;

  {
    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока`);

    if (user.settings.titan !== false)
      return bot("игрок уже является [TITAN]. ⚠");

    user.settings.titan = true;

    user.stock.status = "Titan";

    user.limit.nicklimit = 48;

    user.level += 50;

    user.opit += 50000;

    user.limit.banklimit = 500000000000000;

    user.limit.farmlimit = 10000;

    user.limit.playerlimit = 300000000000000;

    user.limit.sent = 0;

    user.limit.videocardlimit = 100;

    user.maxenergy = 100;

    await bot(
      `Вы выдали привилегию « TITAN » игроку @id${user.id} (${user.tag}) 😸`
    );

    if (user.notifications)
      await vk.api.messages.send({
        user_id: user.id,
        message: `▶️ Администратор @id${message.user.id} (${message.user.tag}) выдал Вам привилегию «TITAN» 😸
〽️ Чтобы просмотреть список доступных Вам команд и преимуществ, напишите «TITAN help» ❄️
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
        random_id: 0,
      });
  }
});

cmd.hear(/^(?:offtitan)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 5) return;

  const user = await double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return;

  {
    let user = double.find((x) => x.uid === Number(message.args[1]));

    if (!user) return bot(`неверный ID игрока`);

    if (user.settings.titan !== true)
      return bot("игрок не имеет [Titan] статуса. ⚠");

    user.settings.titan = false;

    user.stock.status = "Игрок";

    user.level -= 19;

    user.opit -= 5000;

    user.limit.nicklimit = 16;

    user.limit.banklimit = 50000000000000;

    user.limit.farmlimit = 1000;

    user.limit.videocardlimit = 30;

    user.limit.playerlimit = 50000000000000;

    user.limit.sent = 0;

    user.maxenergy = 10;

    await bot(`забрал у игрока TITAN-статус! ⛔`);

    if (user.notifications)
      await vk.api.messages.send({
        user_id: user.id,
        message: `▶️ Администратор @id${message.user.id} (${message.user.tag}) забрал Вашу привилегию «TITAN» ❌
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения`,
        random_id: 0,
      });
  }
});

cmd.hear(/^setadmin\s([0-9]+)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 5) return;

  if (!Number(message.args[1])) return;

  if (message.args[2] < 0) return;

  const user = await double.find((x) => x.uid === Number(message.args[1]));

  if (!user) return bot(`такого игрока нету в БД! ☹️`);

  user.limitadd.playerlimitadd = 1000000000000;

  user.settings.adm = message.args[2];

  user.bantop = true;

  await bot(
    `игрок [@id${user.id} (${user.tag})] был назначен на ${message.args[2]}ур. админки`
  );

  if (user.notifications)
    await vk.api.messages.send({
      user_id: user.id,
      message: `▶️ Владелец @id${message.user.id} (${message.user.tag}) назначил Вас на ${message.args[2]}ур. администратора! 😸

⚠️ До того, как Вы начнёте использовать администратора - ознакомьтесь с некоторыми важными частями ❗
📚 Все админ-команды использовать ТОЛЬКО в беседе администраторов или л/с (vk.me/club223500959)!
👉 Сразу ознакомьтесь со списком админ-правил по команде «аправила».
💾 Узнать список всех админ-команд можно по команде «акмд».
💬 Обязательно состоять в оф. беседе и админ беседе. `,
      random_id: 0,
    });

  await vk.api.messages.send({
    chat_id: chatlogi,
    random_id: 0,
    message: `⚠️ ADM-LOG:
▶️ Владелец @id${message.user.id} (${message.user.tag}) выдал ${message.args[2]}ур. администратора игроку @id${user.id} (${user.tag}) ❄️`,
  });
});



module.exports = commands;
