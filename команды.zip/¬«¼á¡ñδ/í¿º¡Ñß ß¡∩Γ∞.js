let utils = require('../utils.js')

const commands = [];

const fs = require('fs');


const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;

const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

let double = require('../database/users.json')

cmd.hear(/^(?:бизнес)\s(?:снять)\s(\d)\s(.*)$/i, async (message, bot) => {
  if (message.chat.type === 1) {
    if (!message.user.settings) {
      message.user.settings = {};
    }
    message.args[1] = Math.floor(Number(message.args[1]));

    if (message.user.settings.busi === true) {
      if (message.args[1] < 1 || message.args[1] > 5)
        return bot(`используйте: Бизнес снять [от 1 до 5] [количество]`);
    } else {
      if (message.args[1] < 1 || message.args[1] > 4)
        return bot(`используйте: Бизнес снять [от 1 до 4] [количество]`);
    }

    if (message.user.business.length < message.args[1])
      return bot(`у вас нет этого бизнеса`);

    message.args[1]--;

    message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

    message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

    message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

    message.args[2] = message.args[2].replace(
      /(вабанк|вобанк|все|всё)/gi,
      message.user.business[message.args[1]].moneys
    );

    if (!Number(message.args[2])) return;

    message.args[2] = Math.floor(Number(message.args[2]));

    if (message.args[2] <= 0)
      return bot(`вы не можете снять столько со счёта бизнеса`);

    if (message.args[2] > message.user.business[message.args[1]].moneys)
      return bot(
        `у вас нет столько денег на счёте этого бизнеса! ❌\n\n▶️ Баланс этого бизнеса: ${utils.sp(
          message.user.business[message.args[1]].moneys
        )} GB 💰`
      );

    message.user.balance2 += message.args[2];

    message.user.business[message.args[1]].moneys -= message.args[2];

    return bot(
      `вы сняли со счёта бизнеса ${utils.sp(
        message.args[2]
      )} GB 💵\n💰 Ваш баланс: ${utils.sp(message.user.balance2)} GB`
    );
  }
  if (message.chat.type === 0) {

    if (!message.user.settings) {
      message.user.settings = {};
    }
    message.args[1] = Math.floor(Number(message.args[1]));

    if (message.user.settings.busi === true) {
      if (message.args[1] < 1 || message.args[1] > 5)
        return bot(`используйте: Бизнес снять [от 1 до 5] [количество]`);
    } else {
      if (message.args[1] < 1 || message.args[1] > 4)
        return bot(`используйте: Бизнес снять [от 1 до 4] [количество]`);
    }

    if (message.user.business2.length < message.args[1])
      return bot(`у вас нет этого бизнеса`);

    message.args[1]--;

    message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

    message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

    message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

    message.args[2] = message.args[2].replace(
      /(вабанк|вобанк|все|всё)/gi,
      message.user.business2[message.args[1]].moneys
    );

    if (!Number(message.args[2])) return;

    message.args[2] = Math.floor(Number(message.args[2]));

    if (message.args[2] <= 0)
      return bot(`вы не можете снять столько со счёта бизнеса`);

    if (message.args[2] > message.user.business2[message.args[1]].moneys)
      return bot(
        `у вас нет столько денег на счёте этого бизнеса! ❌\n\n▶️ Баланс этого бизнеса: ${utils.sp(
          message.user.business2[message.args[1]].moneys
        )} $ 💰`
      );

    message.user.balance += message.args[2];

    message.user.business2[message.args[1]].moneys -= message.args[2];

    return bot(
      `вы сняли со счёта бизнеса ${utils.sp(
        message.args[2]
      )} $ 💵\n💰 Ваш баланс: ${utils.sp(message.user.balance)} $`
    );

  }
});

module.exports = commands;