const fs = require('fs');
const { VK } = require('vk-io');
let double = require('../database/users.json');
const commands = [];
let utils = require('../utils.js'); // добавлено


function getToken() {
  const tokens = JSON.parse(fs.readFileSync('./database/tokens.json', 'utf8'));
  return { token: tokens.token };
}

const tokenData = getToken();
const vk = new VK({ token: tokenData.token });

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

cmd.hear(/^(?:rass)\s([0-9]+)\s([^]+)/i, async (message, bot) => {

  const groupInfo = await vk.api.call('groups.getById', {
    access_token: tokenData.token,
    v: '5.131',
  });

  if (!groupInfo || groupInfo.length === 0) {
    throw new Error('Не удалось получить информацию о группе.');
  }

  const groupId = groupInfo[0].id;
  const admins = await vk.api.groups.getMembers({ group_id: groupId, filter: 'managers' });

  if (!admins.items.some(admin => admin.id === message.senderId)) {
    return
  }

  const count = Number(message.args[1]) || 0; 
  const messageText = message.args[2];
  const rs = new VK({ token: tokenData.token }); 

  let totalSent = 0;

  // Проверка на корректность данных в double
  if (!Array.isArray(double) || double.length === 0 || !double.every(user => user.id)) {
    console.error("Некорректные данные в файле users.json.  Проверьте формат.");
    return message.send("Ошибка: Некорректные данные пользователей.");
  }

  const filteredUsers = double.filter(user => user.notifications === true && !user.bans.ban);

  for (let i = 0; i < count && i < filteredUsers.length; i++) { // Цикл по отфильтрованным пользователям
    const user = filteredUsers[i];
    try {
      await rs.api.messages.send({
        user_id: user.id,
        message: messageText,
        attachment: `wall-${groupId}_${message.args[1]}`,
        random_id: Math.floor(Math.random() * 1e9),
      });
      totalSent++;
    } catch (error) {
      console.error(`Ошибка при отправке сообщения пользователю ${user.id}:`, error);
      // Можно добавить обработку ошибок, например, запись в лог или уведомление администратора
    }
  }

  return message.send(` 👤 Рассылку получило ${totalSent} людей`);
});

module.exports = commands;