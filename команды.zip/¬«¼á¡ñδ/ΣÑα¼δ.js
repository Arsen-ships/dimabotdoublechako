let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
let farms = require('../spisok/фермы.js')
const vk = new VK({ token: tokenData.token });
cmd.hear(/^(?:фермы|🔋 Фермы)\s?([0-9]+)?\s?(.*)?$/i, async (message, bot) => {
  if (!message.args[1]) {
    return bot(`🔋 Майнинг фермы:\n\n${message.user.misc.farm === 1 ? '✔️' : '✖️'} 1. 7U Nvidia 1₿/час (18.000.000.000$)\n${message.user.misc.farm === 2 ? '✔️' : '✖️'} 2. AntminerS9 10₿/час (140.000.000.000$)\n${message.user.misc.farm === 3 ? '✔️' : '✖️'} 3. FM2020-BT400 100₿/час (1.600.000.000.000$)\n${message.user.misc.farm === 4 ? '✔️' : '✖️'} 4. Gеnеsis Mining 3.000₿/час (22.000.000.000.000$)\n${message.user.misc.farm === 5 ? '✔️' : '✖️'} 5. GigaWatt 25.000₿/час (1.600.000.000.000.000$)\n${message.user.misc.farm === 6 ? '✔️' : '✖️'} 6. TerraEngine 105.000₿/час (4.000.000.000.000.000$)\n${message.user.misc.farm === 7 ? '✔️' : '✖️'} 7. YotaMiner 410.000₿/час (30.000.000.000.000.000$)\n\n🛒 Для покупки введите «Фермы [номер] [количество]»`);
  }
  if (message.user.inf) {
    return bot(`👁️ Выключите безлимитный баланс`);
  }

  const sell = farms.find(x => x.id === Number(message.args[1]));
  if (!sell) return;

  const count = Math.floor(message.args[2] ? Number(message.args[2]) : 1);
  if (count <= 0) return bot(`❌ Вы указали количество ферм меньше 1-го.`);

  if (message.args[1] < 1 || message.args[1] >= 8) return bot('😒 Неверный номер ферм.');

  if (!message.user.settings.imperator) {
    if (count + message.user.misc.farm_count > message.user.limit.farmlimit) {
      return bot(`❌ Вы не можете иметь больше ${message.user.limit.farmlimit} штук ферм одновременно.`);
    }
  } else {
    if (count + message.user.misc.farm_count > 1000000) {
      if (count + message.user.misc.farm_count > message.user.limit.farmlimit) {
        return bot(`❌ Вы не можете иметь больше ${message.user.limit.farmlimit} штук ферм одновременно.`);
      }
    }
  }

  if (message.user.misc.farm != 0 && message.user.misc.farm != message.args[1]) {
    return bot(`😨 Вы не можете купить ферму другого типа!`);
  }

  if (message.user.balance < sell.cost * count) {
    return bot(`💰 У Вас недостаточно денег! ❌\n\nВаш баланс: ${utils.sp(message.user.balance)}$ 💵`);
  } else {
    message.user.balance -= sell.cost * count;
    message.user.misc.farm = sell.id;
    message.user.misc.farm_count += count;

    return bot(`🎉 Вы купили «${sell.name}» (${count} шт.) за ${utils.sp(sell.cost * count)}$`);
  }
});
cmd.hear(/^(?:ферма)$/i, async (message, bot) => {
  if (!message.user.misc.farm) return bot(`у вас нет фермы`);

  if (!message.user.farm_btc)
    return bot(`на вашей ферме пусто, новые биткоины появятся скоро`);

  let btc_ = message.user.farm_btc * message.user.misc.farm_count;

  if (message.user.farm_count >= 10000000) Math.floor((btc_ /= 2));

  message.user.btc += btc_;

  message.user.farm_btc = 0;

  return bot(`вы собрали ${utils.sp(
    btc_
  )}₿, следующие биткоины появятся через час
💾 Биткоинов: ${utils.sp(message.user.btc)}฿`);
});

cmd.hear(/^(?:ферма инфо)$/i, async (message, bot) => {
  if (!message.user.misc.farm) return bot(`у вас нет фермы`);

  const btc_ = message.user.farm_btc * message.user.misc.farm_count;

  return bot(`На ваших фермах накопилось ${utils.sp(btc_)}₿ 🌐`);
});

module.exports = commands;
