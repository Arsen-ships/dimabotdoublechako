let utils = require('../utils.js')

const commands = [];

const fs = require('fs');
let works = require('../spisok/работники.js')
let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:работа)\s([0-9]+)$/i, async (message, bot) => {
  if (message.user.work)
    return bot(`ваша профессия - ${works[message.user.work - 1].name}

${message.user.timers.hasWorked ? `Вы уже работали в эту минуту` : ``}`);

  const work = works.find((x) => x.id === Number(message.args[1]));

  if (!work) return console.log(message.args[1]);

  if (work.requiredLevel > message.user.level)
    return bot(`вы не можете устроиться на эту работу!`);
  else if (work.requiredLevel <= message.user.level) {
    message.user.work = work.id;

    return bot(`вы устроились на работу — «${work.name}» 🛠️

💡 Чтобы начать работать введите «Работать»`);
  }
});

cmd.hear(/^(?:работы)$/i, async (message, bot) => {
  if (message.user.work)
    return bot(`ваша профессия - ${works[message.user.work - 1].name}

${message.user.timers.hasWorked ? `Вы уже работали в эту минуту` : ``}`);

  if (!message.args[1])
    //

    return bot(`Информация по работам:

🎀 Профессия | Необход. уровень | Зарплата
🔹 1. Дворник (1ур.), зарплата - 17.500$
🔸 2. Сантехник (2ур.), зарплата - 87.500$
🔹 3. Электрик (3ур.), зарплата - 437.500$
🔸 4. Слесарь (4ур.), зарплата - 2.175.000$
🔹 5. Юрист (5ур.), зарплата - 10.850.000$
🔸 6. Бухгалтер (7ур.), зарплата - 54.000.000$
🔹 7. Бармен (10ур.), зарплата - 252.000.000$
🔸 8. Администратор (15ур.), зарплата - 1.260.000.000$
🔹 9. Программист (20ур.), зарплата - 6.300.000.000$
🔸 10. Главный Программист (25ур.), зарплата - 31.500.000.000$
🔹 11. Директор (35ур.), зарплата - 160.000.000.000$
🔸 12. Президент (50ур.), зарплата - 750.000.000.000$
🔹 13. Мафиози (100ур.), зарплата - 1.500.000.000.000$
🔸 14. Шахтер (500ур.), зарплата - 2.500.000.000.000$
🔹 15. Создатель Чако (1000ур.), зарплата - 5.000.000.000.000$

〽️Для трудоустройства введите «Работа [номер]»`);
});

cmd.hear(/^(?:работать|⛏️ работать)$/i, async (message, bot) => {
  if (!message.user.work)
    return bot(`вы нигде не работаете 😢
▶️ Для просмотра всех работ введите «Работы»`);

  if (message.user.timers.hasWorked > Date.now())
    return bot(`рабочий день еще не начат! ❌
⏳ Вы сможете работать через ${unixStampLefta(
      message.user.timers.hasWorked - Date.now()
    )}`);

  if (message.user.captcha.vid !== false) {
    if (message.user.captcha.vid === 1)
      return bot(`подозрительная активность! ❌
Введите «капча ${message.user.captcha.otvet}», чтобы пройти проверку на робота!`);

    if (message.user.captcha.vid === 2)
      return bot(`подозрительная активность! ❌
Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2
        }» и введите "капча [ответ]"`);
  }

  let captcha = utils.random(1, 100);

  if (captcha === 44) {
    let t = utils.pick([1, 2]);

    if (t === 1) {
      let otv = utils.random(100, 500);

      message.user.captcha.vid = 1;

      message.user.captcha.otvet = otv;

      return bot(`подозрительная активность! ❌
Введите «капча ${otv}», чтобы пройти проверку на робота!`);
    }

    if (t === 2) {
      let pr1 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20]);

      let pr2 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20]);

      message.user.captcha.vid = 2;

      message.user.captcha.otvet = pr1 + pr2;

      message.user.captcha.primer = `${pr1 + pr2}`;

      return bot(`подозрительная активность! ❌
Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2
        }» и введите "капча [ответ]"`);
    }
  }
  const work = works.find((x) => x.id === message.user.work);
  const earn = utils.random(work.min, work.max);
  message.user.balance += earn;
  message.user.exp += 1;
  if (message.user.settings.king) {
    message.user.timers.hasWorked = Date.now() + 60000;
  }
  message.user.timers.hasWorked = Date.now() + 70000;
  if (message.user.settings.vip === true) message.user.exp += 1;
  if (message.user.settings.premium === true) message.user.exp += 2;
  let multiply = [0, 0, 1, 2, 1, 2, 0, 0, 0, 0, 1, 0, 0];
  multiply = utils.pick(multiply);
  message.user.sprcoin += multiply;
  if (multiply !== 0) {
    return bot(`вы успешно закончили рабочий день.
💵 Вы заработали: ${utils.sp(earn)} $
〰️ Премия: +${multiply} SpringCoin ☣️
🔅 Ваш уровень рабочего - ${message.user.level}
📶 Ваш текущий опыт - ${message.user.exp}/70`);
  } else {
    return bot(`вы успешно закончили рабочий день.
💵 Вы заработали: ${utils.sp(earn)} $
🔅 Ваш уровень рабочего - ${message.user.level}
📶 Ваш текущий опыт - ${message.user.exp}/70`);
  }
});

cmd.hear(/^(?:уволиться)$/i, async (message, bot) => {
  if (!message.user.work)
    return bot(`вы нигде не трудоустроены! ❓
🔹 Чтобы просмотреть список всех работ, напишите «работы» ❄️`);

  message.user.work = 0;

  let smileng = utils.pick([
    `🌷`,
    `🌸`,
    `🌹`,
    `🌺`,
    `🌼`,
    `💐`,
    `❤️`,
    `💓`,
    `💕`,
  ]); //utils.pick([`🎅`, `☃️`, `❄️`, `🎄`]);

  return bot(`вы успешно уволились со своей работы! 😢${smileng}`);
});


module.exports = commands;
