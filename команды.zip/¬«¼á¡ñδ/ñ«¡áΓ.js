let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });





cmd.hear(/^(?:пополнить)\s+(\d+)$/i, async (message, bot) => {

  const amount = parseFloat(message.args[1]);

  if (amount < 10) {
    await bot(`сумма не может быть меньше 10 рублей.`)
    return
  }

  if (isNaN(amount) || amount <= 0) {
    return message.send('👉 Пожалуйста, укажите корректную сумму для пополнения.');
  }


  const requestId = Math.floor(100000 + Math.random() * 900000);


  await message.send(`✅ Заявка на пополнение на сумму ${amount}₽ успешно создана! Номер заявки: ${requestId}.`);

  // Поиск пользователя 🕵️‍♂️
  let user = double.find(x => x.id === message.user.id);
  if (!user) {
    console.log('🚫 Не найден пользователь с ID:', message.user.id);
    return message.send('Не удалось найти информацию о пользователе.');
  }


  const userName = user ? user.tag : 'Пользователь';
  const userId = user ? user.id : '';

  const notificationMessage = `
    🎉 Уважаемый участник! 🎉
    
    ✅ Чек номер: ${requestId} 
    От: [id${userId}|${userName}] 
    Сумма: ${amount} ₽ 💰
`;


  if (user.notifications) {
    try {
      await vk.api.messages.send({
        user_id: 690927947, 
        message: notificationMessage,
        random_id: 0
      });
    } catch (error) {
      console.error('🚨 Ошибка при отправке уведомления: ', error);
      return message.send('😞 Произошла ошибка при отправке уведомления о пополнении.');
    }
  }
});


module.exports = commands;
