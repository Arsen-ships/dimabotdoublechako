let utils = require('../utils.js')

const commands =[];

const fs = require('fs'); 

let chats = require('../database/chats.json')

let double = require('../database/users.json')
let config = require('../database/settings.json');
const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; 
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; 
  }
}


function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}


const tokenData = getToken();

const chatlogi = tokenData.chatlogi; 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/@?dimamisarin/i, async (message, bot) => {
  if (message.user.uid === 1 || message.user.uid === 0)
    return bot(
      `вы находитесь в белом листе (W-L), поэтому Вам не было выдано предупреждение.`
    );

  if (message.user.warn === undefined) {
    message.user.warn = 0;
  }

  if (message.user.warn < 5) {
    message.user.warn += 1;

    return message.send(
      `👤 @id${message.user.uid} (${message.user.tag}), уважаемый игрок! Если Вы хотите что-то добиться от Дмитрия, то советую Вам написать в личные сообщения только по ВАЖНЫМ делам.\n\n⏳ У Вас ${message.user.warn}/5 предупреждений, если Вы достигнете 5-ти предупреждений Вы будете заморожены в боте на 1 час из-за массовых упоминаний.`,
      { attachment: `video-187572210_456239730` }
    );
  }

  if (message.user.warn >= 5) {
    message.user.warn = 0;

    message.user.bans.ban = true;

    message.user.timers.ban = Date.now() + 3600000;

    return bot(
      `Вы достигли лимита предупреждений. Выдан бан на 1 час в целях защиты от массовых упоминаний.`
    );
  }
});

cmd.hear(/(?:cid)/i, async (message, bot) => {
  if (!message.isChat) {
    return bot('Команда работает только в беседе с ботом!');
  }

  if (message.chatId){
    return message.send(`ID ${message.chatId}`);
  } else {
    return bot('Ошибка: Не удалось получить ID беседы.');
  }
});



cmd.hear(/^(?:постфортуна)$/i, async (message, bot) => {



  if (message.user.settings.adm < 6) return;
  const groupInfo = await vk.api.call('groups.getById', {
    access_token: tokenData.token,
    v: '5.131', // Версия API
  });

  if (!groupInfo || groupInfo.length === 0) {
    throw new Error('Не удалось получить информацию о группе.');
  }

  // Извлекаем group_id из первого элемента массива groups
  const groupId = groupInfo[0].id;

  vk.api.wall.post({

    owner_id: -groupId,

    message: `🎂 Акция — «ФОРТУНА»!

			

✅ В общем будет 100 призов в акции!

🛍️ Призы:

      • 1. Секретные кейсы

      • 2. Донат-кейсы

      • 3. Игровая валюта



⭐ Чтобы испытать свою удачу,напишите в комментариях «Фортуна»

❌ Если бот не отвечает - призы все равно придут.`,

    attachments: 'photo-197579361_457253129'

  }).then((response) => {

    config.fortuna = response.post_id;

    config.fortunacount = 10;

    vk.api.wall.openComments({

      owner_id: -groupId,

      post_id: response.post_id

    });

  });

  bot(`Пост Фортуна - успешно создан`);

});

module.exports = commands;
