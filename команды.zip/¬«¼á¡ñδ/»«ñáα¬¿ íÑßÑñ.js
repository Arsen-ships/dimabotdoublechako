let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let chats = require('../database/chats.json')

let double = require('../database/users.json')

let botinfo = require('../database/botinfo.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};



const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

function unixStampLeft(stamp) {
  stamp = stamp / 1000;
  let s = stamp % 60;
  stamp = (stamp - s) / 60;
  let m = stamp % 60;
  stamp = (stamp - m) / 60;
  let h = stamp % 24;
  let d = (stamp - h) / 24;

  let text = ``;

  if (d > 0) text += Math.floor(d) + " д. ";
  if (h > 0) text += Math.floor(h) + " ч. ";
  if (m > 0) text += Math.floor(m) + " м. ";
  if (s > 0) text += Math.floor(s) + " с.";
  return text;
}


cmd.hear(/^(?:стату(я|и))\s(подар(ок|ки))$/i, async (message, bot) => {
  if (message.user.settings.adm > 0) return bot(`администрации нельзя забирать подарки бесед.`)
  if (message.isChat) {
    const chat = chats.find(chat => chat.id === message.chatId);
    if (chat) {

      if (chat.statuepeoplelvl == 1 && chats.statuemoneylvl == 3 && chats.statuemsglvl == 3) {

        if (chats.gift > Date.now()) return bot(`Подарок можно получить раз в 15 минут, пожалуйста подождите 🎈`);

        chats.gift = Date.now() + 900000;

        let rand = utils.random(1, 7)

        if (rand == 1) {

          message.user.balance += 10000000000000

          bot(`Вы получили подарок статуи! ✅\n\n🤑 +10.000.000.000.000$ 💰`);

          message.send({ sticker_id: 74276 });

        }

        if (rand == 2) {

          let rands = utils.random(1, 3)

          message.user.c2 += rands;

          bot(`Вы получили подарок статуи! ✅\n\n🎊 Ваш подарок: ${rands} Золотых кейсов 📦`);

          message.send({ sticker_id: 74276 });

        }

        if (rand == 3) {

          let rands = utils.random(1, 10)

          message.user.c1 += rands;

          bot(`Вы получили подарок статуи! ✅\n\n🎊 Ваш подарок: ${rands} Обычных кейсов 📦`);

          message.send({ sticker_id: 74276 });

        }

        if (rand == 4) {

          let rands = utils.random(1, 10000000)

          message.user.btc += rands;

          bot(`Вы получили подарок статуи! ✅\n\n🎊Ваш подарок: ${utils.sp(rands)} BTC 🌐`);

          message.send({ sticker_id: 74276 });

        }

        if (rand == 5) {

          let rands = utils.random(1, 25)

          message.user.rub += rands;

          bot(`Вы получили подарок статуи! ✅\n\n🎊 Ваш подарок: ${rands} ЧакоРуб 💰`);

          message.send({ sticker_id: 74276 });

        }

        if (rand == 6) {

          let rands = utils.random(1, 100000)

          message.user.rating += rands;

          bot(`вы получили подарок статуи! ✅\n\n🎊 Ваш подарок: ${rands} Рейтинга 👑`);

          message.send({ sticker_id: 74276 });

        }

        if (rand == 7) {

          let rands = utils.random(1, 20)

          message.user.leaf += rands;

          bot(`вы получили подарок статуи! ✅\n\n🎊 Ваш подарок: ${rands} Листиков 🍃`);

          message.send({ sticker_id: 74276 });

        }

      } else {

        return bot(`Подарок можно получить полностью улучшив все 3 статуи! 😢`);

      }

    } else {

      return bot(`Команда доступна только в беседе`);

    }
  }

});

cmd.hear(
  /^(?:Подарок|🌟 Подарок|🎁 Забрать подарок|@club223500959 🌟 Подарок)$/i,

  async (message, bot) => {
    if (message.user.settings.adm > 0) return bot (`администрации нельзя забирать подарки бесед.`)
    const chat = chats.find(chat => chat.id === message.chatId);
    if (chat) {
      if (message.chatId !== 1)
        return message.send(`🎁 @id${message.user.id} (${message.user.tag}), подарок можно получить только в нашей официальной беседе!
📩 Беседа: https://vk.me/join/R6yYllA/jtfWNR_VirX4ITJu8DsyXgAiwZY=`);

      if (chat.podarok === undefined) {
        chat.podarok = 3600000;
      }

      let user = double.find((x) => x.uid === botinfo.podarok);

      if (!message.isChat)
        return message.send(`🎁 @id${message.user.id} (${message.user.tag}), подарок можно получить только в нашей официальной беседе!
📩 Беседа: https://vk.me/join/R6yYllA/jtfWNR_VirX4ITJu8DsyXgAiwZY=`);



      if (chat.podarok > Date.now())
        return bot(`Подождите немного! 💡

⌛ Следующий подарок через: ${unixStampLeft(chat.podarok - Date.now())}
📥 Предыдущий подарок забрал игрок ${user.mention ? `@id${user.id} (${user.tag})` : `${user.tag}`
          } (🆔: ${user.uid})`);

      chat.podarok = Date.now() + 1800000;

      botinfo.podarok = message.user.uid;

      if (message.isChat) {
        setTimeout(() => {
          message.send({ sticker_id: utils.pick([108219, 108230, 79421, 108246, 62796, 52982, 110710, 110670]), });

          vk.api.messages.send({
            chat_id: 1,
            random_id: 0,
            message: `@all
            ▶️ Подарок снова доступен для открытия!`,

            keyboard: JSON.stringify({
              inline: true,
              buttons: [
                [
                  {
                    action: {
                      type: "text",
                      payload: "{}",
                      label: "🎁 Забрать подарок",
                    },
                    color: "default",
                  },
                ],
              ],
            }),
          });
        }, 1800000);
      }

      let prize = utils.pick([1, 1, 2, 2, 3, 3, 4, 4, 5]);

      if (prize === 1) {
        let denga = utils.random(100000000000, 700000000000);

        message.user.balance += denga;

        return message.send(`🎁 @id${message.user.id} (${message.user.tag
          }), вы открыли подарок! С него Вам выпало ${utils.sp(denga)}$

💡 Узнать свой баланс: «баланс»`);
      }

      if (prize === 2) {
        let rate = utils.random(5000, 15000);

        message.user.rating += rate;

        return message.send(`🎁 @id${message.user.id} (${message.user.tag
          }), вы открыли подарок! С него Вам выпало ${utils.sp(rate)} 👑

💡 Узнать свой рейтинг: «рейтинг»`);
      }

      if (prize === 3) {
        let bitc = utils.random(1000000, 10000000);

        message.user.btc += bitc;

        return message.send(`🎁 @id${message.user.id} (${message.user.tag
          }), вы открыли подарок! С него Вам выпало ${utils.sp(bitc)} биткоинов 💾

💡 Узнать свои биткоины: «биткоины»`);
      }

      if (prize === 4) {
        let dc = utils.random(1, 3);

        message.user.c3 += dc;

        return message.send(`🎁 @id${message.user.id} (${message.user.tag
          }), вы открыли подарок! С него Вам выпало ${utils.sp(dc)} донат-кейсов 📦

💡 Открыть данные кейсы: «Кейс открыть 3»`);
      }

      if (prize === 5) {
        let rubl = utils.random(1, 5);

        message.user.rubli += rubl;

        return message.send(`🎁 @id${message.user.id} (${message.user.tag
          }), вы открыли подарок! С него Вам выпало ${utils.sp(
            rubl
          )} донат-рублей! 💸

💡 На рубли можно купить донат, по команде: «донат»`);
      }
    }
  }
);



module.exports = commands;
