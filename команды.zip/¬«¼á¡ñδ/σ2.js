let utils = require('../utils.js');

const commands = [];

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const promptBet = (message, bot) => {
    return bot('нажми кнопку ИЛИ введи команду: "2 [сумма ставки]"', {
        keyboard: JSON.stringify({
            "inline": true,
            "buttons": [
                [{
                    "action": {
                        "type": "text",
                        "payload": "{}",
                        "label": `x2 ${message.user.lastbet}`
                    },
                    "color": "default"
                },
                {
                    "action": {
                        "type": "text",
                        "payload": "{}",
                        "label": `x2 ${message.user.lastbet * 2}`
                    },
                    "color": "default"
                },
                {
                    "action": {
                        "type": "text",
                        "payload": "{}",
                        "label": `x2 ${message.user.balance2}`
                    },
                    "color": "default"
                }]
            ]
        })
    });
};

const processBetAmount = (input, userBalance) => {
    return input.replace(/(\.|\,)/ig, '')
        .replace(/(к|k)/ig, '000')
        .replace(/(м|m)/ig, '000000')
        .replace(/(вабанк|вобанк|все|всё)/ig, userBalance);
};

const updateGameStakes = (message, amount) => {
    const lastGame = message.chat.games[message.chat.games.length - 1];
    const existingStake = lastGame.stavki.find(x => x.id === message.senderId && x.type === 2);

    if (existingStake) {
        existingStake.amount += amount;
    } else {
        lastGame.stavki.push({
            uid: message.user.uid,
            id: message.user.id,
            type: 2,
            amount: amount
        });
    }
};

cmd.hear(/^(?:x2|2)$/i, async (message, bot) => {
    if (message.chat.type === 1) {
        if (message.chat.type === 0 || message.user.balance2 <= 0) return bot(`на твоем балансе нет коинов...`);
        if (!isFinite(message.user.balance2)) {
            message.user.balance2 = 0;
            return bot(`В твоем богатстве царило бесконечное изобилие, но увы, теперь оно обнулено.`);
        }
        return promptBet(message, bot);
    }
});

cmd.hear(/^(?:x2|2)\s(.*)$/i, async (message, bot) => {
    if (message.chat.type === 1) {
        if (message.chat.type === 0 || message.user.balance2 <= 0) return bot(`на твоем балансе нет коинов...`);
        if (!isFinite(message.user.balance2)) {
            message.user.balance2 = 0;
            return bot(`в твоем богатстве царило бесконечное изобилие, но увы, теперь оно обнулено.`);
        }
        if (message.chat.gametime < 6) return;

        const rawAmount = processBetAmount(message.args[1], message.user.balance2);
        const betAmount = Math.floor(Number(rawAmount));

        if (isNaN(betAmount) || betAmount <= 0 || betAmount > message.user.balance2) {
            return promptBet(message, bot);
        }

        message.user.balance2 -= betAmount;
        updateGameStakes(message, betAmount);
        message.user.lastbet = betAmount;

        return bot(`успешная ставка ${utils.sp(betAmount)} GB на x2`);
    }
});

module.exports = commands;
