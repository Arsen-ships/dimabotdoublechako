let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let botinfo = require('../database/botinfo.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });



function unixStampLefta(stampa) {
  stampa = stampa / 1000;
  let s = stampa % 60;
  stampa = (stampa - s) / 60;
  let m = stampa % 60;
  let text = ``;
  if (m > 0) text += addZero(Math.floor(m)) + " мин. ";
  if (s > 0) text += addZero(Math.floor(s)) + " сек.";
  return text;
}

function addZero(i) {
  return i < 10 ? "0" + i : i;
}

let kursrudtime = Date.now() + 301000;

cmd.hear(/^(?:Курс руды)$/i, async (message, bot) => {
  let text = `Курс руды:\n`;

  if (botinfo.kursplazma > 1200000000000)
    text += `🆙 Руду «Плазма» сейчас можно продать за дорого.\n`;

  if (botinfo.kursobsidian > 200000000000)
    text += `🆙 Руду «Обсидиан» сейчас можно продать за дорого.\n`;

  if (botinfo.kursmateria > 10000000000)
    text += `🆙 Руду «Материя» сейчас можно продать за дорого.\n`;

  if (botinfo.kursalmaz > 150000000)
    text += `🆙 Руду «Алмаз» сейчас можно продать за дорого.\n`;

  if (botinfo.kurszoloto > 3000000)
    text += `🆙 Руду «Золото» сейчас можно продать за дорого.\n`;

  if (botinfo.kurszoloto > 400000)
    text += `🆙 Руду «Железо» сейчас можно продать за дорого.\n`;

  text += `\n⚙️ 1 железо - ${utils.sp(botinfo.kurszhelezo)}$`;

  text += `\n🏵 1 золото - ${utils.sp(botinfo.kurszoloto)}$`;

  text += `\n💎 1 алмаз - ${utils.sp(botinfo.kursalmaz)}$`;

  text += `\n🌌 1 материя - ${utils.sp(botinfo.kursmateria)}$`;

  text += `\n🌌 1 обсидиан - ${utils.sp(botinfo.kursobsidian)}$`;

  text += `\n🌌 1 плазма - ${utils.sp(botinfo.kursplazma)}$`;

  text += `\n\n🔄 Курс руды обновится через ${unixStampLefta(
    kursrudtime - Date.now()
  )} ⏳`;

  return bot(text);
});

setInterval(() => {
  if (kursrudtime > Date.now()) {
    kursrudtime -= 1;
  }
  if (kursrudtime <= Date.now()) {
    kursrudtime = Date.now() + 301000;
  }
}, 1000);


module.exports = commands;
