let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

let trees = require('../spisok/деревья.js')

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^деревья\s?(\d+)?$/i, async (message, bot) => {
  if (message.chat.type === 0) {
  if (!message.args[1])
    return bot(`Деревья:

🌳 1. Одинокое дерево: 1 листик/час (1.000.000.000.000$)
🌳 2. Несколько деревьев: 3 листика/час (10.000.000.000.000$)
🌳 3. Лес: 5 листиков/час (100.000.000.000.000$)

🛒 Для покупки введите «Деревья [номер]»
`);

  if (message.args[1] < 1 || message.args[1] >= 4)
    return bot("Неверный номер дерева");

  const sell = trees.find((x) => x.id === Number(message.args[1]));

  if (!sell) return;

  if (message.user.tree !== 0)
    return bot(`у Вас уже есть Дерево (${trees[message.user.tree - 1].name})! 🙌
🛒 Чтобы его продать, напишите «Продать дерево»`);

  if (message.user.balance < sell.cost) return bot(`недостаточно денег!`);
  else if (message.user.balance >= message.args[1]) {
    message.user.balance -= sell.cost;

    message.user.irrigation = 100;

    message.user.tree = sell.id;

    return bot(`вы успешно купили «${sell.name}» за ${utils.sp(sell.cost)}$`);
  }
}
});

cmd.hear(/^дерево$/i, async (message, bot) => {
  if (message.chat.type === 0) {
  if (!message.user.tree)
    return bot(`у Вас нет дерева!

Для выбора дерева отправьте «Деревья»`);

  const biz = trees.find((x) => x.id === message.user.tree);

  const lvlcash = biz.earn; //листики pribil

  return bot(
    `информация о Вашем дереве «${biz.name}»:

🍂 Падает ${utils.sp(lvlcash)} лист./час
🍃 Упало ${utils.sp(message.user.leafpribil)}
💧 Осталось воды: ${utils.sp(message.user.irrigation)}%
`,
    {
      attachment: biz.photo,

      keyboard: JSON.stringify({
        inline: true,

        buttons: [
          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "🚿 Дерево полить",
              },

              color: "positive",
            },

            {
              action: {
                type: "text",

                payload: "{}",

                label: "▶️ Дерево собрать",
              },

              color: "positive",
            },
          ],

          [
            {
              action: {
                type: "text",

                payload: "{}",

                label: "🌲 Дерево помощь",
              },

              color: "positive",
            },
          ],
        ],
      }),
    }
  );
}
});
cmd.hear(
  /^(?:дерево помощь|деревья помощь|🌲 Дерево помощь)$/i,
  async (message) => {
    if (message.chat.type === 0) {
    return message.send(`помощь по дереву:

✅ Полить дерево, чтобы оно не засохло: Команда «Дерево полить»
🍃 Собрать листики с дерева: Команда «Дерево собрать»`);
  }
}
);

cmd.hear(/^(?:дерево|▶️ Дерево)\sсобрать$/i, async (message, bot) => {
  if (message.chat.type === 0) {
  utils.pick([`🌷`, `🌸`, `🌹`, `🌺`, `🌼`, `💐`, `❤️`, `💓`, `💕`]);

  if (!message.user.tree)
    return bot(
      `У вас нет дерева! Можно просмотреть список всех продаваемых деревьев, написав команду «Деревья» 🌲`
    );

  if (!message.user.leafpribil)
    return bot(`У этого дерева ещё нету опавших листиков! ❌😢`);

  const biz_balance = message.user.leafpribil;

  message.user.leaf += message.user.leafpribil;

  message.user.leafpribil = 0;

  return bot(
    `вы собрали со своего дерева ${utils.sp(biz_balance)} опавших листиков 🍃`
  );
}
});

cmd.hear(/^(?:дерево полить|🚿 Дерево полить)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
  if (message.user.tree < 1)
    return bot(`у вас нет дерева.
❓ Для покупки введите "Деревья"`);

  if (message.user.irrigation >= 100) return bot(`дереву не требуется полив!`);

  if (message.user.balance < 10000000) return bot(`недостаточно денег. ⁉️`);
  else {
    message.user.irrigation = 100;

    message.user.balance -= 10000000;

    bot(
      `дерево успешно было полито!\n\nВы полили дерево «${trees[message.user.tree - 1].name
      }» за 10.000.000$ 💧`
    );
  }
}
});

cmd.hear(/^(?:🍹 Напитки|Напитки)$/i, async (message, bot) => {
  if (message.chat.type === 0) {
    return bot(`Напитки:

🔸 1. Чай (2 листика)
🔸 2. Кофе (12 листиков)
🔸 3. Энергетик (26 листиков)
🔸 4. Отвар трав (56 листиков)
🔸 5. Черная жидкость (120 листиков)
🔸 6. Капля зелья энергии (150 листиков)
🔸 7. Истинное зелье энергии (2000 листиков)

🛒 Для покупки введите «Напитки [номер]»`);
  }
});

cmd.hear(/^(?:Напитки|🍹 напитки)\s?([0-9]+)?$/i, async (message, bot) => {
  const drinks = [
    { id: 1, name: 'Чай', cost: 2, energy: 1 },
    { id: 2, name: 'Кофе', cost: 12, energy: 5 },
    { id: 3, name: 'Энергетик', cost: 26, energy: 10 },
    { id: 4, name: 'Отвар трав', cost: 56, energy: 20 },
    { id: 5, name: 'Чёрная жидкость', cost: 120, energy: 40 },
    { id: 6, name: 'Капля зелья', cost: 150, energy: 50 },
    { id: 7, name: 'Зелье', cost: 2000, energy: 500 },
  ];

  const index = Number(message.args[1]) - 1;

  if (index < 0 || index >= drinks.length) {
    return bot('Неправильный номер напитка. 🍹');
  }

  const drink = drinks[index];

  if (message.user.leaf < drink.cost) {
    return bot(`Недостаточно листиков! 🍃`);
  }

  message.user.leaf -= drink.cost;
  message.user.energy += drink.energy;

  return bot(`Вы успешно купили напиток «${drink.name}» за ${drink.cost} листиков и восстановили ${drink.energy} энерг. ⚡`, {
    keyboard: JSON.stringify({
      "inline": true,
      "buttons": [[{
        "action": {
          "type": "text",
          "payload": "{\"button\": \"5\"}",
          "label": `🍹 Напитки ${drink.id}`
        },
        "color": "positive"
      }]]
    })
  });
});	


module.exports = commands;
