let utils = require('../utils.js')

const commands =[]

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};


let chats = require('../database/chats.json')


cmd.hear(/список|списки|чаты/i, async (message, bot) => {
  chats = chats.filter(chat => chat.id !== undefined);

  let chatList = chats.map(chat => {
    let type = chat.type === 0 ? "не дабл" : "дабл";

    return `ID Чата: ${chat.id} - ${type}`;
  }).join("\n");

  return bot(`Список чатов:\n${chatList}`);
});



module.exports = commands;
