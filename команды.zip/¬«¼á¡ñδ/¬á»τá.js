let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:вк|выдать капчу|капча выдать|выдача капчи)\s([^]+)$/i, async (message, bot) => {
  if (message.user.settings.adm < 1) return;

  // Определяем ID игрока из сообщения
  let idp;
  const isUrl = /^(?:https)\:\/\/(?:vk.com)\//i;

  if (!message.forwards[0] && !message.replyMessage && !message.args[1]) {
    return bot(`🔍 Укажите ID игрока в боте/ссылку/пуш/перешлите сообщение`);
  }

  if (message.args[1]) {
    if (!Number(message.args[1])) {
      if (!message.args[1].match(/\|/i)) {
        const mpq = message.args[1].replace(/(http|https):\/\/(vk.com|m.vk.com)\//ig, "");
        await vk.api.utils.resolveScreenName({ screen_name: mpq }).then(res => {
          idp = res.object_id;
        });
      } else {
        const arg = message.args[1].replace(/(\|[^]*)|(\[id)/ig, "");
        idp = Number(arg);
      }
    } else {
      idp = Number(message.args[1]);
    }
  } else {
    if (message.forwards[0]) idp = message.forwards[0].senderId;
    if (message.replyMessage) idp = message.replyMessage.senderId;
  }

  // Поиск пользователя по ID
  const user = double.find(x => x.uid === Number(idp) || x.id === idp);
  if (!user) return bot(`❌ Неверный URL игрока или ID!`);

  // Проверка наличия активной капчи
  if (user.captcha.vid !== false) return bot(`⚠️ Он уже имеет капчу, остановитесь!`);

  // Выбор вида капчи
  const captchaType = utils.pick([1, 2]);
  let answer;

  if (captchaType === 1) {
    answer = utils.random(100, 500);
    user.captcha.vid = 1;
    user.captcha.otvet = answer;

    await bot(`✅ Капча игроку №${utils.sp(user.uid)} успешно выдана!\n\n🔎 Вид капчи: №1\n🎲 Ответ капчи: ${user.captcha.otvet}\n❓ За бессмысленную выдачу капчи игроку вы можете получить выговор. Будьте аккуратнее!`);

    return vk.api.messages.send({ user_id: user.id, random_id: 0, message: `Подозрительная активность! ❌\nВведите "капча ${answer}", чтобы пройти проверку на робота!` });
  }

  if (captchaType === 2) {
    const pr1 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20]);
    const pr2 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20]);
    answer = pr1 + pr2;
    user.captcha.vid = 2;
    user.captcha.otvet = answer;

    await bot(`✅ Капча игроку №${utils.sp(user.uid)} успешно выдана!\n\n🔎 Вид капчи: №2\n🎲 Пример, выданный игроку: ${pr1} + ${pr2}\n❓ За бессмысленную выдачу капчи игроку вы можете получить выговор. Будьте аккуратнее!`);

    return vk.api.messages.send({ user_id: user.id, random_id: 0, message: `Подозрительная активность! ❌\nРешите пример «${pr1} + ${pr2}», и введите "капча [ответ]"` });
  }
});

cmd.hear(/^(?:капча)\s(.*)$/i, async (message, bot) => {

  if (message.user.captcha.vid == false) return bot(`у вас нету капчи, но я за вами слежу! 🤖`)

  if (message.args[1] == message.user.captcha.otvet) {

    message.user.captcha.vid = false

    message.user.captcha.otvet = false

    message.user.captcha.primer = false

    message.user.captcha.pred = 0

    return bot(`вы успешно прошли проверку на робота! ✅`)

  } else {

    if (message.user.captcha.vid == 1) return bot(`подозрительная активность! ❌

Введите "капча ${message.user.captcha.otvet}", чтобы пройти проверку на робота!`)

    if (message.user.captcha.vid == 2) return bot(`подозрительная активность! ❌

Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2}» и введите "капча [ответ]"`)

  }

})

module.exports = commands;
