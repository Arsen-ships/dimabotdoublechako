let utils = require('../utils.js')

const commands =[];

const fs = require('fs'); 

let double = require('../database/users.json')

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const tokensFilePath = './database/tokens.json';
const businesses2 = require("../spisok/бизнесы.js")

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    // console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;

const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

let fink=true

const businesses=require('../spisok/business spisok.js')

cmd.hear(/^(?:бизнес)\s(?:нанять)\s([0-9]+)\s([0-9]+)$/i, async (message, bot) => {

  if (message.chat.type === 1) {

    if (!message.user.settings) {
      message.user.settings = {};
    }
    message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

    message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

    message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

    message.args[2] = message.args[2].replace(/(вабанк|вобанк|все|всё)/gi, "1");

    message.args[1] = Math.floor(Number(message.args[1]));

    message.args[2] = Math.floor(Number(message.args[2]));

    if (message.user.settings.busi === true) {
      if (message.args[1] < 1 || message.args[1] > 5)
        return bot(
          `ошибка, данного бизнеса не существует. Используйте «Бизнес нанять [от 1 до 5] [кол-во работников]» ❓`
        );
    } else {
      if (message.args[1] < 1 || message.args[1] > 4)
        return bot(
          `ошибка, данного бизнеса не существует. Используйте «Бизнес нанять [от 1 до 4] [кол-во работников]» ❓`
        );
    }

    if (message.user.business.length < message.args[1])
      return bot(`у вас нет этого бизнеса! ❌`);

    message.args[1]--;

    if (
      message.user.business[message.args[1]].workers + message.args[2] >
      businesses[message.user.business[message.args[1]].id - 1][
        message.user.business[message.args[1]].upgrade - 1
      ].workers
    )
      return bot(
        `в вашем бизнесе не может поместится столько работников! ❌\n\n▶️ Попробуйте уменьшить кол-во.`
      );

    const cost = message.args[2] * 200;

    if (cost > message.user.balance2)
      return bot(`у вас недостаточно денег для покупки рабочих 1 работник - 200 GB`);

    message.user.balance2 -= cost;

    message.user.business[message.args[1]].workers += message.args[2];

    return bot(
      `вы наняли ${utils.sp(message.args[2])} рабочих 👷‍♂️ для бизнеса №${message.args[1] + 1
      } 🎉`
    );
  }
  if (message.chat.type === 0) {
    if (!message.user.settings) {
      message.user.settings = {};
    }
    message.args[2] = message.args[2].replace(/(\.|\,)/gi, "");

    message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

    message.args[2] = message.args[2].replace(/(м|m)/gi, "000000");

    message.args[2] = message.args[2].replace(/(вабанк|вобанк|все|всё)/gi, "1");

    message.args[1] = Math.floor(Number(message.args[1]));

    message.args[2] = Math.floor(Number(message.args[2]));

    if (message.user.settings.busi === true) {
      if (message.args[1] < 1 || message.args[1] > 5)
        return bot(
          `ошибка, данного бизнеса не существует. Используйте «Бизнес нанять [от 1 до 5] [кол-во работников]» ❓`
        );
    } else {
      if (message.args[1] < 1 || message.args[1] > 4)
        return bot(
          `ошибка, данного бизнеса не существует. Используйте «Бизнес нанять [от 1 до 4] [кол-во работников]» ❓`
        );
    }

    if (message.user.business2.length < message.args[1])
      return bot(`у вас нет этого бизнеса! ❌`);

    message.args[1]--;

    if (
      message.user.business2[message.args[1]].workers + message.args[2] >
      businesses2[message.user.business2[message.args[1]].id - 1][
        message.user.business2[message.args[1]].upgrade - 1
      ].workers
    )
      return bot(
        `в вашем бизнесе не может поместится столько работников! ❌\n\n▶️ Попробуйте уменьшить кол-во.`
      );

    const cost = message.args[2] * 20000000000;

    if (cost > message.user.balance)
      return bot(`у вас недостаточно денег для покупки рабочих 1 работник - 20.000.000.000 $`);

    message.user.balance -= cost;

    message.user.business2[message.args[1]].workers += message.args[2];

    return bot(
      `вы наняли ${utils.sp(message.args[2])} рабочих 👷‍♂️ для бизнеса №${message.args[1] + 1
      } 🎉`
    );
  }
});

module.exports = commands;