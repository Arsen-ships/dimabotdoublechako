let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });




function addZero(num) {
  return num < 10 ? '0' + num : num;
}

function unixStampLefta(stampa) {
  stampa = stampa / 1000; // Переводим миллисекунды в секунды
  let s = stampa % 60; // Получаем секунды
  stampa = (stampa - s) / 60; // Убираем секунды из времени
  let m = stampa % 60; // Получаем минуты
  let text = ``;

  if (m > 0) text += addZero(Math.floor(m)) + " мин. ";
  if (s > 0) text += addZero(Math.floor(s)) + " сек.";

  return text.trim(); // Удаляем лишние пробелы в конце
}

function convertTime(milliseconds) {
  const seconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(seconds / 60);
  
  return `${minutes > 0 ? `${minutes} минут ` : ""}${seconds % 60} секунд`;
}


function unixStampLeft(stamp) {
  stamp = stamp / 1000;
  let s = stamp % 60;
  stamp = (stamp - s) / 60;
  let m = stamp % 60;
  stamp = (stamp - m) / 60;
  let h = stamp % 24;
  let d = (stamp - h) / 24;

  let text = ``;

  if (d > 0) text += Math.floor(d) + " д. ";
  if (h > 0) text += Math.floor(h) + " ч. ";
  if (m > 0) text += Math.floor(m) + " м. ";
  if (s > 0) text += Math.floor(s) + " с.";
  return text;
}


cmd.hear(/^(?:бонус|🎁 Бонус)$/i, async (message, bot) => {
  if (message.user.bans.bonus) {
    return bot(`вам был отключен бонус. 🚫`)
  }

  if (message.chat.type === 1) {
    if (message.user.balance2 > 999999) {
      return bot("бонус не начислен, у вас большой баланс. 🚫");
    }

    if (message.user.timers.bonus2 > Date.now()) {
      let timeLeft = unixStampLefta(message.user.timers.bonus2 - Date.now())
      return bot(`до получения бонуса: ${timeLeft} ⏳`);
    }

    const bonusConfigs = [
      { condition: () => message.user.settings.vip, bonus: 200, name: 'VIP бонус' },
      { condition: () => message.user.settings.premium, bonus: 300, name: 'PREMIUM бонус' },
      { condition: () => message.user.settings.topdon, bonus: 1000, name: 'TOP DONATOR бонус' },
      { condition: () => message.user.settings.adm > 0, bonus: 500, name: 'ADMIN бонус' },
      { condition: () => true, bonus: 100, name: 'бонус' } 
    ];

    const validBonuses = bonusConfigs.filter(config => config.condition()); 

    const bestBonus = validBonuses.reduce((max, config) => config.bonus > max.bonus ? config : max, { bonus: 0, name: 'бонус' });

    bot(`${bestBonus.name} +${utils.sp(bestBonus.bonus)} GB 💵`);

    message.user.balance2 += bestBonus.bonus;
    message.user.timers.bonus2 = Date.now() + 1200000; // Устанавливаем новый таймер на 20 минут
    message.user.bonusCounter = (message.user.bonusCounter || 0) + 1;
    return;
  }
  if (message.chat.type === 0) {
    if (message.user.timers.bonus >= Date.now())
      return bot(
        `бонус можно будет получить через ${unixStampLefta(
          message.user.timers.bonus - Date.now()
        )} ☃️`
      );

    let randbal = utils.random(50000000, 50000000000);

    let randrating = utils.random(5, 1000);

    let randbank = utils.random(10000000, 5000000000);

    let randbtc = utils.random(10000, 1000000);

    let randbil = utils.random(1, 3);

    message.user.timers.bonus = Date.now() + 86400000;

    let prize = utils.random(1, 5);

    if (prize === 1) {
      message.user.balance += randbal;

      return bot(`вы выиграли ${utils.sp(randbal)}$ 💵`);
    }

    if (prize === 2) {
      message.user.rating += randrating;

      return bot(
        `вы выиграли ${utils.sp(randrating)}👑!\n👑 Рейтинг: ${utils.sp(
          message.user.rating
        )}`
      );
    }

    if (prize === 3) {
      message.user.bank += randbank;

      return bot(
        `вы выиграли ${utils.sp(
          randbank
        )}$ на свой банковский счёт!\n💳 Счёт в банке: ${utils.sp(
          message.user.bank
        )}$`
      );
    }

    if (prize === 4) {
      message.user.btc += randbtc;

      return bot(
        `вы выиграли ${utils.sp(randbtc)} биткоинов!\n🌐 Биткоинов: ${utils.sp(
          message.user.btc
        )}₿`
      );
    }

    if (prize === 5) {
      message.user.bilet += randbil;

      return bot(`вы выиграли ${utils.sp(randbil)} билетов! 🎟`);
    }
  }
});

    cmd.hear(
      /^(?:бонус император|бонус imperator|imperarot бонус|император бонус)$/i,
      async (message, bot) => {
        if (!message.user.settings.imperator) return;

        if (message.user.timers.imperatorbonus >= Date.now())
          return bot(
            `👑 Император бонус можно будет получить через ${unixStampLefta(
              message.user.timers.imperatorbonus - Date.now()
            )}.`
          );

        let imperatorbonus1 = utils.random(1, 6);

        message.user.timers.imperatorbonus = Date.now() + 86400000;

        if (imperatorbonus1 === 1) {
          let bonuscash = utils.random(10000000000000, 10000000000000000);

          message.user.balance += bonuscash;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonuscash)} $ 🙂`);
        }

        if (imperatorbonus1 === 2) {
          let bonusbtc = utils.random(100000000, 500000000);

          message.user.btc += bonusbtc;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonusbtc)}₿`);
        }

        if (imperatorbonus1 === 3) {
          let bonusrating = utils.random(150000, 650000);

          message.user.rating += bonusrating;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonusrating)} 👑`);
        }

        if (imperatorbonus1 === 4) {
          let bonusopit = utils.random(3000, 10000);

          message.user.opit += bonusopit;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonusopit)} опыта 🏆`);
        }

        if (imperatorbonus1 === 5) {
          message.user.c3 += 5;

          message.send({ sticker_id: 108235 });

          bot(`УХ-ТЫ! 🎊\n🤗 Поздравляю, вы выиграли 5 донат-кейсов! 📦`);
        }

        if (imperatorbonus1 === 6) {
          message.user.c5 += 2;
          message.send({ sticker_id: 108225 });
          message.send(
            `ВОТ ЭТО УДАЧА! 🎊\n😱 Поздравляю, вы выиграли 2 супер кейса! 📦`
          );
        }
      }
    );

   cmd.hear(
      /^(?:бонус титан|бонус Titan|Titan бонус|премиум титан)$/i,
      async (message, bot) => {
        if (message.user.settings.titan !== true) return;

        if (message.user.timers.titanbonus > Date.now())
          return bot(
            ` Титан бонус можно будет получить через ${unixStampLefta(
              message.user.timers.titanbonus - Date.now()
            )}`
          );

        let titanbonus1 = utils.random(1, 5);

        message.user.timers.titanbonus = Date.now() + 86400000;

        if (titanbonus1 === 1) {
          let bonuscash = utils.random(5000000000, 50000000000);

          message.user.balance += bonuscash;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonuscash)}$. 🙂`);
        }

        if (titanbonus1 === 2) {
          let bonusbtc = utils.random(100000, 5000000);

          message.user.btc += bonusbtc;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonusbtc)}₿. 😅`);
        }

        if (titanbonus1 === 3) {
          let bonusrating = utils.random(3000, 30000);

          message.user.rating += bonusrating;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonusrating)}👑`);
        }

        if (titanbonus1 === 4) {
          let bonusopit = utils.random(300, 3000);

          message.user.opit += bonusopit;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonusopit)} опыта. 🏆`);
        }

        if (titanbonus1 === 5) {
          let bonusbilet = utils.random(1, 4);

          message.user.bilet += bonusbilet;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonusbilet)} билета. 🎫`);
        }
      }
    );

    cmd.hear(
      /^(?:бонус премиум|бонус PREMIUM|PREMIUM бонус|премиум бонус)$/i,
      async (message, bot) => {
        if (message.user.settings.premium !== true) return;

        if (message.user.timers.prembonus > Date.now())
          return bot(
            `💓 Премиум бонус можно будет получить через ${unixStampLefta(
              message.user.timers.prembonus - Date.now()
            )}`
          );

        let premiumbonus = utils.random(1, 5);

        message.user.timers.prembonus = Date.now() + 86400000;

        if (premiumbonus === 1) {
          let bonuscash = utils.random(5000000000, 50000000000);

          return bot(`поздравляю, вы выиграли ${utils.sp(bonuscash)}$. 🙂`);
        }

        if (premiumbonus === 2) {
          let bonusbtc = utils.random(100000, 5000000);

          message.user.btc += bonusbtc;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonusbtc)}₿. 😅`);
        }

        if (premiumbonus === 3) {
          let bonusrating = utils.random(3000, 30000);

          message.user.rating += bonusrating;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonusrating)}👑`);
        }

        if (premiumbonus === 4) {
          let bonusopit = utils.random(300, 3000);

          message.user.opit += bonusopit;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonusopit)} опыта. 🏆`);
        }

        if (premiumbonus === 5) {
          let bonusbilet = utils.random(1, 4);

          message.user.bilet += bonusbilet;

          return bot(`поздравляю, вы выиграли ${utils.sp(bonusbilet)} билета. 🎟`);
        }
      }
    );

cmd.hear(/^(?:бонус вип|бонус VIP|VIP бонус|вип бонус)$/i, async (message, bot) => {

  if (message.user.settings.vip !== true) return;

  const timeLeft = message.user.timers.vipbonus - Date.now();
  if (timeLeft > 0) {
    const formattedTime = unixStampLefta(timeLeft);
    return bot(`🎲 Вип бонус можно будет получить через ${formattedTime} `);
  }


  let vipbonus = utils.random(1, 4);
  message.user.timers.vipbonus = Date.now() + 86400000;

  let bonusMessage, attachment;

  switch (vipbonus) {
    case 1:
      let bonuscash = utils.random(3000000000, 30000000000);
      message.user.balance += bonuscash;
      bonusMessage = `поздравляю, вы выиграли ${utils.sp(bonuscash)}$.`;
      attachment = utils.pick([`photo-219408161_457239349`]);
      break;
    case 2:
      let bonusbtc = utils.random(50000, 5000000);
      message.user.btc += bonusbtc;
      bonusMessage = `поздравляю, вы выиграли ${utils.sp(bonusbtc)}₿.`;
      attachment = utils.pick([`photo-219408161_457239350`]);
      break;
    case 3:
      let bonusrating = utils.random(1000, 10000);
      message.user.rating += bonusrating;
      bonusMessage = `поздравляю, вы выиграли ${utils.sp(bonusrating)}👑`;
      attachment = utils.pick([`photo-219408161_457239351`]);
      break;
    case 4:
      let bonusopit = utils.random(100, 1000);
      message.user.opit += bonusopit;
      bonusMessage = `поздравляю, вы выиграли ${utils.sp(bonusopit)} опыта. 🏆`;
      attachment = utils.pick([`photo-219408161_457239352`]);
      break;
  }

  return bot(bonusMessage, { attachment });
});

module.exports = commands;
