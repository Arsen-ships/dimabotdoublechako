let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

let chats = require('../database/chats.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';
let casino = require("../database/casino.json");

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });


cmd.hear(/^(?:казино|🎲 Казино|азино|ставка)\s(.*)$/i, async (message, bot) => {
  if (message.user.captcha.vid !== false) {
    if (message.user.captcha.vid === 1)
      return bot(`подозрительная активность! ❌
Введите «капча ${message.user.captcha.otvet}», чтобы пройти проверку на робота!`);

    if (message.user.captcha.vid === 2)
      return bot(`подозрительная активность! ❌
Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2
        }» и введите "капча [ответ]"`);
  }

  let captcha = utils.random(1, 100);

  if (captcha === 44) {
    let t = utils.pick([1, 2]);

    if (t === 1) {
      let otv = utils.random(100, 500);

      message.user.captcha.vid = 1;

      message.user.captcha.otvet = otv;

      return bot(`подозрительная активность! ❌
Введите «капча ${otv}», чтобы пройти проверку на робота!`);
    }

    if (t === 2) {
      let pr1 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20]);

      let pr2 = utils.pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20]);

      message.user.captcha.vid = 2;

      message.user.captcha.otvet = pr1 + pr2;

      message.user.captcha.primer = pr1 + pr2;

      return bot(`подозрительная активность! ❌
Решите пример «${message.user.captcha.otvet / 2} + ${message.user.captcha.otvet / 2
        }» и введите "капча [ответ]"`);
    }
  }



  if (message.args[1] < 0) return;

  message.args[1] = message.args[1].replace(/(\.|\,)/gi, "");

  message.args[1] = message.args[1].replace(/(к|k)/gi, "000");

  message.args[1] = message.args[1].replace(/(м|m)/gi, "000000");

  message.args[1] = message.args[1].replace(
    /(вабанк|вобанк|все|всё)/gi,
    message.user.balance
  );

  if (!Number(message.args[1])) return;

  message.args[1] = Math.floor(Math.round(Number(message.args[1])));

  const smileos = utils.pick(["🙂", "😇"]);

  const smileyes = utils.pick(["🙂", "😃", "😄", "🤑", "☺"]);

  const smileno = utils.pick(["😕", "😔", "😫"]);

  if (message.args[1] <= 0) return;

  if (message.args[1] > message.user.balance)
    return bot(`у вас нет данной суммы`);
  else if (message.args[1] <= message.user.balance) {
    let multiply = [];

    let nalog = 0;

    message.user.balance -= message.args[1];

    if (message.args[1] < 10 && message.args[1] >= 1) {
      nalog = 0.01;

      multiply = [0.25, 5, 0.75, 1, 2, 5, 10, 50, 100, 1000]; //1169.5 - 10 - 116.95

      if (message.user.settings.vip) multiply = multiply.concat([250]); //1419.5 - 11 - 129.04

      if (message.user.settings.premium) multiply = multiply.concat([250, 500]); //1919.5 - 12 - 159.95

      if (message.user.settings.titan) multiply = multiply.concat([250, 2500]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 100 && message.args[1] >= 10) {
      nalog = 0.01;

      multiply = [0.25, 0, 5, 0.75, 1, 2, 5, 10, 50, 100, 500]; //669 - 10 - 66.9

      if (message.user.settings.vip) multiply = multiply.concat([250]); //919 - 11 - 83.54

      if (message.user.settings.premium) multiply = multiply.concat([250, 400]); //1319 - 12 -109.9

      if (message.user.settings.titan) multiply = multiply.concat([250, 1000]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 1000 && message.args[1] >= 100) {
      nalog = 0.02;

      multiply = [0.5, 0.75, 1, 2, 5, 10, 50, 50, 100, 200]; //419.25 - 10 - 41.93

      if (message.user.settings.vip) multiply = multiply.concat([100]); //519.25 - 11 - 47.2

      if (message.user.settings.premium) multiply = multiply.concat([100, 150]); //669.25 - 55.7

      if (message.user.settings.titan) multiply = multiply.concat([200, 220]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 10000 && message.args[1] >= 1000) {
      nalog = 0.02;

      multiply = [0.5, 0.75, 1, 2, 5, 10, 50, 50, 100, 100]; //319.25 - 10 - 31.93

      if (message.user.settings.vip) multiply = multiply.concat([50]); //369.25 - 11 - 33.56

      if (message.user.settings.premium) multiply = multiply.concat([50, 100]); //469.25 - 12 - 39.104

      if (message.user.settings.titan) multiply = multiply.concat([75, 100]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 100000 && message.args[1] >= 10000) {
      nalog = 0.03;

      multiply = [0.5, 0.75, 0.75, 1, 2, 5, 10, 50, 50, 100, 100]; //320 - 11 - 29.09

      if (message.user.settings.vip) multiply = multiply.concat([50]); //370 - 12 - 30.83

      if (message.user.settings.premium) multiply = multiply.concat([50, 75]); //445 - 13 - 34.23

      if (message.user.settings.titan) multiply = multiply.concat([75, 100]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 1000000 && message.args[1] >= 100000) {
      nalog = 0.03;

      multiply = [0.5, 0.5, 0.75, 0.75, 1, 2, 2, 5, 10, 50, 50, 100, 100]; //322.5 - 13 - 24.8

      if (message.user.settings.vip) multiply = multiply.concat([25]); //347.5 - 14 - 24.82

      if (message.user.settings.premium) multiply = multiply.concat([25, 50]); //397.5 - 15 - 26.5

      if (message.user.settings.titan) multiply = multiply.concat([50, 75]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 10000000 && message.args[1] >= 1000000) {
      nalog = 0.04;

      multiply = [0.5, 0.5, 0.75, 0.75, 1, 2, 2, 5, 10, 50, 50, 100]; //222.5 - 12 - 18.54

      if (message.user.settings.vip) multiply = multiply.concat([20]); //242.5 - 13 - 18.65

      if (message.user.settings.premium) multiply = multiply.concat([20, 35]); //277.5 - 14 - 19.82

      if (message.user.settings.titan) multiply = multiply.concat([50, 40]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 100000000 && message.args[1] >= 10000000) {
      nalog = 0.04;

      multiply = [0.25, 0.5, 0.5, 0.75, 0.75, 1, 2, 2, 5, 10, 20, 50, 100]; //192.75 - 13 - 14.82

      if (message.user.settings.vip) multiply = multiply.concat([15]); //207.75 - 14 - 14.83

      if (message.user.settings.premium) multiply = multiply.concat([15, 25]); //232.75 - 15 - 15.51

      if (message.user.settings.titan) multiply = multiply.concat([20, 30]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 1000000000 && message.args[1] >= 100000000) {
      nalog = 0.05;

      multiply = [
        0.25, 0.25, 0.5, 0.5, 0.75, 0.75, 1, 2, 2, 5, 5, 10, 20, 25, 50,
      ]; //123 - 15 - 8.2

      if (message.user.settings.vip) multiply = multiply.concat([10]); //133 - 14 - 9.5

      if (message.user.settings.premium) multiply = multiply.concat([10, 15]); //148 - 15 - 9.86

      if (message.user.settings.titan) multiply = multiply.concat([15, 20]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 10000000000 && message.args[1] >= 1000000000) {
      nalog = 0.05;

      multiply = [
        0.25, 0.25, 0.5, 0.5, 0.75, 0.75, 0.75, 1, 2, 2, 5, 5, 5, 10, 15, 25,
      ]; // 73.75 - 16 - 4.6

      if (message.user.settings.vip) multiply = multiply.concat([5]); // 78.75 - 17 - 4.63

      if (message.user.settings.premium) multiply = multiply.concat([5, 10]); //88.75 - 18 - 4.93

      if (message.user.settings.titan) multiply = multiply.concat([10, 15]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 100000000000 && message.args[1] >= 10000000000) {
      nalog = 0.06;

      multiply = [
        0.25, 0.25, 0.25, 0.25, 0.5, 0.5, 0.75, 0.75, 0.75, 1, 2, 2, 2, 2, 2, 2,
        5, 5, 10,
      ]; //36.75 - 18 - 2.

      if (message.user.settings.vip) multiply = multiply.concat([3]); // 39.75 - 19 - 2.09

      if (message.user.settings.premium) multiply = multiply.concat([3, 5]); // 44.75 - 20 - 2.23

      if (message.user.settings.titan) multiply = multiply.concat([4, 7]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 1000000000000 && message.args[1] >= 100000000000) {
      nalog = 0.06;

      multiply = [
        0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 0.5, 0.75, 0.75, 0.75, 1, 2, 2, 2, 2,
        2, 2, 2, 5, 5,
      ]; // 29 - 19 - 1.52

      if (message.user.settings.vip) multiply = multiply.concat([2]); //31 - 20 - 1.55

      if (message.user.settings.premium) multiply = multiply.concat([2, 5]); //36 - 21 - 1.71

      if (message.user.settings.titan) multiply = multiply.concat([3, 6]); //1919.5 - 12 - 159.95
    }

    if (message.args[1] < 10000000000000 && message.args[1] >= 1000000000000) {
      nalog = 0.07;

      multiply = [
        0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 0.5, 0.5, 0.5, 0.75, 0.75,
        0.75, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
      ]; //26 - 23 - 1.13

      if (message.user.settings.vip) multiply = multiply.concat([2]); // 28 - 24 - 1.16

      if (message.user.settings.premium) multiply = multiply.concat([2, 2]); // 30 - 25 - 1.2

      if (message.user.settings.titan) multiply = multiply.concat([3, 3]); //1919.5 - 12 - 159.95
    }

    if (
      message.args[1] < 100000000000000 &&
      message.args[1] >= 10000000000000
    ) {
      nalog = 0.07;

      multiply = [
        0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 0.5, 0.5,
        0.5, 0.75, 0.75, 0.75, 0.75, 0.75, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
      ]; //28 - 27 - 1.037

      if (message.user.settings.vip) multiply = multiply.concat([2]); //30 - 28 - 1.07

      if (message.user.settings.premium)
        multiply = multiply.concat([0.25, 0.25, 5]); //32.25 - 30 - 1.075

      if (message.user.settings.titan)
        multiply = multiply.concat([0.25, 1.25, 5]); //1919.5 - 12 - 159.95
    }

    if (
      message.args[1] < 1000000000000000 &&
      message.args[1] >= 100000000000000
    ) {
      nalog = 0.08;

      multiply = [
        0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 0.5,
        0.5, 0.5, 0.75, 0.75, 0.75, 0.75, 0.75, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2,
      ]; //26 - 27 - 0.96

      if (message.user.settings.vip) multiply = multiply.concat([1]); //27 - 28 -0.96

      if (message.user.settings.premium) multiply = multiply.concat([1, 2]); //29 - 29 - 1

      if (message.user.settings.titan) multiply = multiply.concat([1, 3]); //1919.5 - 12 - 159.95
    }

    if (
      message.args[1] < 10000000000000000 &&
      message.args[1] >= 1000000000000000
    ) {
      nalog = 0.09;

      multiply = [
        0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25,
        0.25, 0.25, 0.25, 0.25, 0.5, 0.5, 0.5, 0.5, 0.75, 0.75, 0.75, 0.75,
        0.75, 1, 2, 2, 2, 2, 2, 2, 2, 2,
      ]; //24 - 27 - 0.88

      if (message.user.settings.vip) multiply = multiply.concat([1]); // 25 - 28 - 0.89

      if (message.user.settings.premium) multiply = multiply.concat([1.2]); ///25.2 - 28 - 0.9

      if (message.user.settings.titan) multiply = multiply.concat([1.5]); //1919.5 - 12 - 159.95
    }

    if (
      message.args[1] < 100000000000000000 &&
      message.args[1] >= 10000000000000000
    ) {
      nalog = 0.09;

      multiply = [
        0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25,
        0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 0.5, 0.5, 0.5, 0.75,
        0.75, 0.75, 0.75, 0.75, 1, 2, 2, 2, 2, 2, 2,
      ]; //20 - 27 - 0.74

      if (message.user.settings.vip) multiply = multiply = multiply.concat([1]); //21 - 28 - 0.75

      if (message.user.settings.premium)
        multiply = multiply = multiply.concat([1.2]); //21.2 - 28 - 0.76

      if (message.user.settings.titan) multiply = multiply.concat([1.4]); //1919.5 - 12 - 159.95
    }

    if (
      message.args[1] < 1000000000000000000 &&
      message.args[1] >= 100000000000000000
    ) {
      nalog = 0.09;

      multiply = [
        0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25,
        0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 0.5, 0.5, 0.5, 0.75,
        0.75, 0.75, 0.75, 0.75, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 2, 2, 2, 2, 2,
      ]; //20 - 27 - 0.74

      if (message.user.settings.vip) multiply = multiply = multiply.concat([1]); //21 - 28 - 0.75

      if (message.user.settings.premium)
        multiply = multiply = multiply.concat([1.2]); //21.2 - 28 - 0.76

      if (message.user.settings.titan) multiply = multiply.concat([1.3]); //1919.5 - 12 - 159.95
    }

    if (message.user.settings.vip) nalog += 0.01;

    if (message.user.settings.premium) nalog += 0.02;

    if (message.user.balance > 10000000000) multiply = multiply.concat([0.75]);

    //if (message.user.balance > 100000000000) multiply = multiply.concat([0.25]);

    if (message.user.balance > 1000000000000)
      multiply = multiply.concat([0.25]);

    if (message.user.balance > 10000000000000)
      multiply = multiply.concat([0.75]);

    if (message.user.balance > 100000000000000)
      multiply = multiply.concat([0.5]);

    if (message.user.balance > 1000000000000000)
      multiply = multiply.concat([0.5]);

    if (message.user.balance > 10000000000000000)
      multiply = multiply.concat([0.25]);

    if (message.user.balance > 100000000000000000)
      multiply = multiply.concat([0.25]);

    if (message.user.balance > 1000000000000000000)
      multiply = multiply.concat([0.25, 0.5]);

    if (message.user.balance > 10000000000000000000)
      multiply = multiply.concat([0.25, 0.5, 0.25, 0.5, 0.25, 0.5]);

    if (message.user.balance > 100000000000000000000)
      multiply = multiply.concat([0.25, 0.5, 0.25, 0.5, 0.25, 0.5, 0.25, 0.5]);

    if (message.user.balance > 1000000000000000000000)
      multiply = multiply.concat([0.25, 0.5, 0.25, 0.5, 0.25, 0.5, 0.25, 0.5]);

    if (message.user.balance > 10000000000000000000000)
      multiply = multiply.concat([
        0.25, 0.5, 0.25, 0.5, 0.25, 0.5, 0.25, 0.5, 0.25, 0.5, 0.25, 0.5, 0.25,
        0.5, 0.25, 0.5,
      ]);

    if (message.user.rating > 10000) multiply = multiply.concat([0.75]);

    if (message.user.rating > 100000) multiply = multiply.concat([0.25]);

    if (message.user.rating > 1000000) multiply = multiply.concat([0.5]);

    if (message.user.rating > 10000000) multiply = multiply.concat([0.5]);

    if (message.user.rating > 100000000) multiply = multiply.concat([0.25]);

    if (message.user.rating > 1000000000)
      multiply = multiply.concat([0.25, 0.5]);

    if (message.user.rating > 10000000000)
      multiply = multiply.concat([0.25, 0.5]);

    if (message.user.rating > 100000000000)
      multiply = multiply.concat([0.25, 0.5]);

    if (message.user.rating > 1000000000000)
      multiply = multiply.concat([0.25, 0.5]);

    if (message.user.rating > 10000000000000)
      multiply = multiply.concat([0.25, 0.5]);

    if (message.user.btc > 100000000) multiply = multiply.concat([0.5]);

    if (message.user.btc > 1000000000) multiply = multiply.concat([0.25]);

    if (message.user.btc > 10000000000) multiply = multiply.concat([0.75]);

    if (message.user.btc > 100000000000) multiply = multiply.concat([0.5]);

    if (message.user.btc > 1000000000000) multiply = multiply.concat([0.25]);

    if(message.isChat) multiply = multiply.concat([1.12,1.24,1.36]);


    if (message.isChat) {
      if (chats) {
        const chat = chats.find(chat => chat.id === message.chatId);
        if (chat) {
          if (chat.statuepeoplelvl >= 1) {
            multiply = multiply.concat([3]);
          }

          if (chat.statuepeoplelvl >= 2) {
            multiply = multiply.concat(multiply);

            multiply = multiply.concat(multiply);

            nalog -= 0.01;

            multiply = multiply.concat(multiply);

            multiply = multiply.concat(multiply);

            multiply = multiply.concat(multiply);

            multiply = multiply.concat(multiply);

            multiply = multiply.concat(multiply);

            if (message.args[1] < 100000000000000)
              multiply = multiply.concat([100]);
          }

          if (chat.statuepeoplelvl >= 3) {
            multiply = multiply.concat(multiply);

            multiply = multiply.concat(multiply);

            multiply = multiply.concat(multiply);

            if (message.args[1] < 50000000000000)
              multiply = multiply.concat([200]);
          }

          if (chat.statuepeoplelvl >= 5) {
            let multileaf;

            multileaf = [
              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0,
              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0,
              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0,
              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
              0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6,
              0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6,
              0, 0, 0, 0, 
            ];

            multileaf = utils.pick(multileaf);

            if (multileaf === 1) {
              message.user.leaf += 20;

              await bot(
                `🎰Удача на вашей стороне!\n🎲Дополнительный приз: листики (20 шт)`
              );
            } else if (multileaf === 2) {
              message.user.ruds.plazma += 10;

              await bot(
                `🎰Удача на вашей стороне!\n🎲Дополнительный приз: плазма (10 шт)`
              );
            } else if (multileaf === 3) {
              message.user.ruds.obsidian += 30;

              await bot(
                `🎰Удача на вашей стороне!\n🎲Дополнительный приз: обсидиан (30 шт)`
              );
            } else if (multileaf === 4) {
              message.user.rub += 50;

              await bot(
                `🎰Удача на вашей стороне!\n🎲Дополнительный приз: ЧакоРуб (50 шт)`
              );
            } else if (multileaf === 5) {
              message.user.bilet += 2;

              await bot(
                `🎰Удача на вашей стороне!\n🎲Дополнительный приз: Билеты для фортуны (2 шт)`
              );
            } else if (multileaf === 6) {
              message.user.sprcoin += 10;

              await bot(
                `🎰Удача на вашей стороне!\n🎲Дополнительный приз: SpringCoin (10 шт)`
              );
            } else if (multileaf === 6) {
              message.user.balance2 += 5000;

              await bot(
                `🎰Удача на вашей стороне!\n🎲Дополнительный приз: GB (5.000 шт)`
              );
            }
          }
        }
      }
    }

    if (message.user.settings.topdon) {
      nalog = 0;

      multiply.concat([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]);

      multiply.forEach(function (item, index) {
        if (item === 0) {
          multiply[index] = 0.3;
        }
      });
    }

    if (message.user.settings.king) {
      multiply.sort();

      for (let i = 0; i < multiply.length; i++) {
        if (multiply[i] < 0.75) multiply[i] = 0.75;
      }
    }

    multiply = utils.pick(multiply); //



    if (message.user.casinoplus > 0) {
      multiply = utils.pick([1, 2]);

      message.user.casinoplus -= 1;
    }

    if (message.user.casinominus > 0) {
      multiply = utils.pick([0.25, 0.25, 0.5, 0.75]);

      message.user.casinominus -= 1;
    }

    if (message.user.balance > 100000000000000) nalog += 0.04;

    if (message.isChat) {
      if (chats) {
        if (multiply > 1) {
          if (message.user.settings.adm < 1) {
            const chat = chats.find(chat => chat.id === message.chatId);
            if (chat) {
              chat.statuemoney += Number(
                Math.floor(
                  Math.round(
                    (message.args[1] * multiply - message.args[1]) * nalog
                  )
                )
              );

            chat.statuemoney = Number(
              Math.floor(Math.round(chat.statuemoney))
            );

            if (chat.statuemoney >= 1000000000000000) {
              chat.statuemoneylvl = 1;
            }

            if (chat.statuemoney >= 50000000000000000) {
              chat.statuemoneylvl = 2;
            }

            if (chat.statuemoney >= 500000000000000000) {
              statuemoneylvl = 3;
            }

            if (chat.statuemoneylvl === 1) {
              nalog -= 0.01;
            }

            if (chat.statuemoneylvl === 2) {
              nalog -= 0.03;
            }

            if (chat.statuemoneylvl === 3) {
              nalog -= 0.2;
            }

            if (nalog < 0) nalog = 0;
          }
        }
      }
    }
    }

    if (message.user.settings.joker === true && message.user.inf === true) {
      multiply = message.user.infcas;
    }

    if (multiply <= 1)
      message.user.balance += Math.floor(
        Math.round(message.args[1] * multiply)
      );

    if (multiply > 1)
      message.user.balance += Math.floor(
        Math.round(
          message.args[1] * multiply * (1 - nalog) + message.args[1] * nalog
        )
      );

    if (multiply < 1 && message.user.settings.adm < 1)
      casino.balance += Number(
        Math.floor(
          Math.round(
            message.args[1] - Math.floor(Math.round(message.args[1] * multiply))
          )
        )
      );

    if (multiply > 1 && message.user.settings.adm < 1)
      casino.balance -= Number(
        Math.floor(
          Math.round(
            (Math.floor(Math.round(message.args[1] * multiply)) -
              message.args[1]) *
            (1 - nalog)
          )
        )
      );

    if (typeof message.user.questcasino === "number") {
      if (multiply >= 1) {
        message.user.questcasino++;

        if (message.user.questcasino >= 5) {
          await bot(
            `Поздравляем, Вы 5 раз выиграли в казино и получаете 📦 1 Донат-кейс.`
          );

          message.user.c3 += 1;

          message.user.questcasino = true;
        }
      } else {
        message.user.questcasino = 0;
      }
    }

    let photo = ``;

    if (multiply > 1) photo = `photo-211261524_457504145`;

    if (multiply === 1) photo = `photo-211261524_457504145`;

    if (multiply < 1) photo = `photo-211261524_457504146`;

    let wow = utils.pick([`😃`, `😄`, `😏`, `🙃`, `🙂`, `😲`, `🤤`]);

    let txt = utils.pick([
      `Вам очень повезло!`,
      `Вы везучий!`,
      `Повезло-повезло`,
      `Удача — с вами!`,
      `Да ты везучий!`,
    ]);

    await bot(
      `${multiply === 1
        ? `${txt} — ваши деньги остаются при вас (x${multiply}) ${smileos}`
        : `${multiply < 1
          ? `вы проиграли ${utils.sp(
            message.args[1] - message.args[1] * multiply
          )}$ 🚫
❌ » Ставка сгорела на x${multiply} ${smileno}`
          : `вы выиграли ${utils.sp(
            Math.floor(
              (message.args[1] * multiply - message.args[1]) *
              (1 - nalog)
            )
          )}$ 💵
${wow} » ${txt}
♻️ » Умножена ставка на x${multiply} ${smileyes}`
        }`
      }
💰 » Баланс: ${utils.sp(message.user.balance)}$

	`,
      {
        attachment: photo,

        keyboard: JSON.stringify({
          inline: true,

          buttons: [
            [
              {
                action: {
                  type: "text",

                  payload: { command: `казино ${message.args[1]}` },

                  label: `🎰 Поставить повторно (${utils.rn(message.args[1])})`,
                },

                color: "primary",
              },
            ],
          ],
        }),
      }
    );
  }
});

module.exports = commands;
