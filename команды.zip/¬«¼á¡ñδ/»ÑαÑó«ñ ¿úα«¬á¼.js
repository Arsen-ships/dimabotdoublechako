let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
    try {
        const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
        return tokens; // Возвращаем все данные из файла
    } catch (error) {
        console.error('Ошибка при чтении токенов:', error);
        return null; // Возвращаем null в случае ошибки
    }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
    const tokens = {
        token: token,
        spoler: spoler,
        chatlogi: chatlogi
    };

    try {
        fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
        console.log('Токены успешно сохранены.');
    } catch (error) {
        console.error('Ошибка при сохранении токенов:', error);
    }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });


cmd.hear(/^(?:передать|перевести|передай|перидать|пиредать|пиредай|перевод)\s?(.*)?\s(.*)$/i, async (message, bot) => {
    if (message.user.bans.pban)
        return bot(`Вам запрещено передавать деньги другим игрокам! ❌`);

    if (message.chat.type === 1) {

        let userId = 0;
        if ((message.replyMessage || message.forwards[0]) && !message.args[1]) {
            userId = message.replyMessage.senderId || message.forwards[0].senderId;
        } else if (!(message.replyMessage || message.forwards[0]) && message.args[1]) {
            userId = (await getResolve(message.args[1], vk.api)).id;
        }

        let user = double.find(x => x.id === userId || x.uid == Number(message.args[1]));

        if (!user) return bot('🚫 Этот игрок не играет в бота.');
        if (user.bans.ban) return bot('🚫 Данный игрок находится в бане.');

        if (!message.args[2]) return bot('💬 Укажите сумму, которую хотите отправить.');

        message.args[2] = message.args[2].replace(/(\.|\,)/ig, '');
        message.args[2] = message.args[2].replace(/(к|k)/ig, '000');
        message.args[2] = message.args[2].replace(/(м|m)/ig, '000000');
        message.args[2] = message.args[2].replace(/(вабанк|вобанк|все|всё)/ig, message.user.balance);

        if (!Number(message.args[2])) return bot('🚫 Укажите сумму, которую хотите отправить.');
        message.args[2] = Math.floor(Number(message.args[2]));

        if (message.args[2] <= 0) return bot('🚫 Укажите сумму, которую хотите отправить.');
        if (message.args[2] > message.user.balance2) return bot('🚫 У вас недостаточно GB коинов.');
        else if (message.args[1] !== 'найдено') {
            if (user.id === message.user.id) return bot('🚫 Нельзя перевести самому себе.');

            message.user.balance2 -= message.args[2];
            user.balance2 += message.args[2];

            await bot('вы зашли в мобильный банк, создаём транзакцию..');

            setTimeout(async () => {
                await bot(`вы перевели [id${user.id}|${user.tag}] ${utils.sp(message.args[2])} GB 💳`);
            }, 1000);

            try {
                sendNotification(user, `📢 [id${user.id}|${user.tag}], новый перевод! Игрок [id${message.user.id}|${message.user.tag}] отправил Вам ${utils.sp(message.args[2])} GB 🔕 Нажмите кнопку ниже, если не хотите получать подобные сообщения`);
            } catch (error) {
                console.error('Ошибка при передаче денег: лс у пользователя закрыто');
            }
        }

    }
    if (message.chat.type === 0) {

    let smileng = utils.pick([
        `🌷`,
        `🌸`,
        `🌹`,
        `🌺`,
        `🌼`,
        `💐`,
        `❤️`,
        `💓`,
        `💕`,
    ]);


    message.args[2] = message.args[2].replace(/([.,])/gi, "");

    message.args[2] = message.args[2].replace(/(к|k)/gi, "000");

    message.args[2] = message.args[2].replace(/([мm])/gi, "000000");

    message.args[2] = message.args[2].replace(
        /(вабанк|вобанк|все|всё)/gi,
        message.user.balance
    );

    if (message.user.inf === true)
        return bot(`Выключите безлимитный баланс ${smileng}`);

    if (!Number(message.args[2])) return;

    message.args[2] = Math.floor(Number(message.args[2]));

    if (message.args[2] <= 0) return;

    if (message.args[2] > message.user.bank)
        return bot(`Недостаточно средств на балансе банка! ❌

💳 Баланс банка: ${utils.sp(message.user.bank)}$`);
    else if (message.args[2] <= message.user.bank) {
        if (message.user.limit == null)
            message.user.limit = { timer: utils.time(), sent: 0 };

        if (utils.time() - message.user.limit.timer >= 10800) {
            message.user.limit.timer = utils.time();

            message.user.limit.sent = 0;

            message.user.limit.paylimit = message.user.limit.playerlimit;
        }

        if (message.args[2] > message.user.limit.paylimit)
            return bot(
                `Вы указали число, больше Вашего лимита на данный момент!\n✅ Доступно ещё к передаче: ${utils.sp(
                    message.user.limit.paylimit
                )}$\n🔄 Лимит восстанавливается каждые 3 часа.`
            );

        let user = double.find((x) => x.uid === Number(message.args[1]));

        if (!user) return bot(`убедитесь в правильности ID игрока`);

        if (user.uid === message.user.uid) return bot(`Неверный ID`);

        if (message.user.pay < Date.now()) {
            message.user.pay = Date.now() + 5000;

            return bot(`Вы точно хотите перевести игроку @id${user.id} (${user.tag
                }) ${utils.sp(message.args[2])}$ 💵

⏳ У Вас есть 5 сек. на повторный ввод команды, чтобы передать средства.`);
        }

        if (message.user.pay > Date.now()) {
            await vk.api.messages.send({
                chat_id: chatlogi,
                forward_messages: message.id,
                message: `# LOG-BANK:\n\n👤 Передал: @id${message.user.id} (${message.user.tag
                    })[ID: ${message.user.uid}]\n🤑 Получил: @id${user.id} (${user.tag})[${user.uid
                    }]\n💵 Сумма: ${utils.sp(message.args[2])}$`,
                random_id: 0,
            });

            message.user.pay = Date.now() + 1000;

            message.user.bank -= Math.floor(Number(message.args[2]));

            message.user.limit.paylimit -= Math.floor(Number(message.args[2]));

            message.user.limit.sent += Math.floor(Number(message.args[2]));

            user.bank += Math.floor(Number(message.args[2] * 0.95));

            return bot(
                `Успешно! Игрок получил Ваши средства. Детальная информация о переводе:\n\n➡️ Переведено ${utils.sp(
                    message.args[2]
                )}$\n➖ С учётом коммисии пришло ${utils.sp(
                    message.args[2] * 0.95
                )}$\n👤 Получатель: ${user.mention ? `@id${user.id} (${user.tag})` : `${user.tag}`
                }\n▶️ Оставшийся лимит: ${utils.sp(
                    message.user.limit.paylimit
                )}$\n${smileng}`
            );
        }

        await bot(
            `вы передали игроку ${user.tag} ${utils.sp(message.args[2])}$ ${smileng}`
        );

        if (user.notifications)
            await vk.api.messages.send({
                user_id: user.id,
                message: `🔔 Уведомление:
👤 Игрок @id${message.user.id} (${message.user.tag})[ID: ${message.user.uid
                    }] перевел Вам ${utils.sp(
                        message.args[2]
                    )}$ (с учётом комиссии пришло ${utils.sp(message.args[2] * 0.95)}$) 💵
🔕 Введите «Уведомления выкл», если не хотите получать подобные сообщения ${smileng}`,
                random_id: 0,
            });
    }

}

});


cmd.hear(/^уведомления\s(выкл|вкл)$/i, async (message, bot) => {
    if (message.args[1].toLowerCase() === "выкл") {
        message.user.notifications = false;
        return bot(`уведомления отключены! 🔕`);
    }

    if (message.args[1].toLowerCase() === "вкл") {
        message.user.notifications = true;
        return bot(`уведомления включены! 🔔`);
    }
});


module.exports = commands;
