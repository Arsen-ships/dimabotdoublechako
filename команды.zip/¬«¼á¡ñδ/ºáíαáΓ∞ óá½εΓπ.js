let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });


cmd.hear(/^(?:забрать|отдай|минус)\s([0-9]+)\s(.*)$/i, async (message, bot) => {
	  const groupInfo = await vk.api.call('groups.getById', {
            access_token: tokenData.token,
            v: '5.131', // Версия API
        });

  if (!groupInfo || groupInfo.length === 0) {
            throw new Error('Не удалось получить информацию о группе.');
        }

        // Извлекаем group_id из первого элемента массива groups
  const groupId = groupInfo[0].id;

  const admins = await vk.api.groups.getMembers({ group_id: groupId, filter: 'managers' });

  if (!admins.items.find(x => x.id === message.senderId)) return;
		message.args[2] = message.args[2].replace(/(\.|\,)/ig, '');
		message.args[2] = message.args[2].replace(/(к|k)/ig, '000');
		message.args[2] = message.args[2].replace(/(м|m)/ig, '000000');
		message.args[2] = message.args[2].replace(/(вабанк|вобанк|все|всё)/ig, message.user.balance);
	
		if(!Number(message.args[2])) return;
		message.args[2] = Math.floor(Number(message.args[2]));
	
		if(message.args[2] <= 0) return bot(`укажите сумму, которую хотите забрать.`)
	
		
		else if(message.args[2])
		{
			let user = double.find(x=> x.uid === Number(message.args[1]));
			if(!user) return bot(`укажите ID игрока из его профиля. `);
	

			user.balance -= message.args[2];
			await bot(`вы забрали у [id${user.id}|${user.tag}] ${utils.sp(message.args[2])} GB`);
				}
					try{
		 vk.api.messages.send({chat_id: chatlogi, message: `🔱 Super - [id${message.user.id}|${message.user.tag}]
🆔 Забрал у игрока - ${ Number(message.args[1])} 
👑 Сумма GB - ${utils.sp(message.args[2])} `, random_id: 0})
					}catch(e) {
	console.log('Забрали GB.')
};
	});

module.exports = commands;
