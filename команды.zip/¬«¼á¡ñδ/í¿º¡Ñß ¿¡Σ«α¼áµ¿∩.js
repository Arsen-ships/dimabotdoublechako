let utils = require('../utils.js')

const commands =[];

const fs = require('fs'); 

let double = require('../database/users.json')

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    // console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 

const spoler = tokenData.spoler;

const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

let fink=true

const businesses = require('../spisok/business spisok.js')
const businesses2 = require("../spisok/бизнесы.js")


cmd.hear(/^(?:бизнес|биз)$/i, async (message, bot) => {
  let text = ``;
    return bot(`помощь по бизнесу:
    
🔥 Бизнес [1/4] - 📊 Показывает текущую активность бизнеса.

💵 Бизнес снять [1/4] [сумма] - 💰 Снимите деньги со счёта бизнеса.

👥 Бизнес нанять [1/4] [кол-во] - 👨‍🏭 Укажите, сколько сотрудников вы хотите нанять.

${text}`);
});

cmd.hear(/^(?:бизнес)\s(\d)$/i, async (message, bot) => {

  if (message.chat.type === 1) {

    if (!message.user.settings) {
      message.user.settings = {};
    }
    message.args[1] = Math.floor(Number(message.args[1]));

    if (message.user.settings.busi === true) {
      if (message.args[1] < 1 || message.args[1] > 5) {
        return bot(`используйте: Бизнес [от 1 до 5]`);
      }
    } else {
      if (message.args[1] < 1 || message.args[1] > 4) {
        return bot(`используйте: Бизнес [от 1 до 4]`);
      }
    }

    if (message.user.business.length < message.args[1]) {
      return bot(`у вас нет этого бизнеса`);
    }

    message.args[1]--;

    const biz = businesses[message.user.business[message.args[1]].id - 1][message.user.business[message.args[1]].upgrade - 1];
    let text = ``;
    if (!fink) {
      text += `❗ Прибыль в бизнес сейчас не поступает. Введутся тех.работы\n`;
    }

    const businessStats = `статистика бизнеса «${biz.name}»: ❄️
💰 Прибыль: ${utils.sp(Math.floor(biz.earn / biz.workers * message.user.business[message.args[1]].workers))} GB / ч.

👷‍♂️ Рабочих: ${message.user.business[message.args[1]].workers}/${biz.workers}

💵 На балансе бизнеса: ${utils.sp(message.user.business[message.args[1]].moneys)} GB.

${text}
${businesses[message.user.business[message.args[1]].id - 1][message.user.business[message.args[1]].upgrade] != null ? "▶️ Доступно улучшение бизнеса! Цена: " + utils.sp(businesses[message.user.business[message.args[1]].id - 1][message.user.business[message.args[1]].upgrade].cost) + " GB." : ""}`;

    return bot(businessStats, {
      attachment: utils.pick([`${businesses[message.user.business[message.args[1]].id - 1][message.user.business[message.args[1]].upgrade - 1].photo}`])
    });
  }
  if (message.chat.type === 0) {
    if (!message.user.settings) {
      message.user.settings = {};
    }
    message.args[1] = Math.floor(Number(message.args[1]));

    if (message.user.settings.busi === true) {
      if (message.args[1] < 1 || message.args[1] > 5) {
        return bot(`используйте: Бизнес [от 1 до 5]`);
      }
    } else {
      if (message.args[1] < 1 || message.args[1] > 4) {
        return bot(`используйте: Бизнес [от 1 до 4]`);
      }
    }

    if (message.user.business2.length < message.args[1]) {
      return bot(`у вас нет этого бизнеса`);
    }

    message.args[1]--;

    const biz = businesses2[message.user.business2[message.args[1]].id - 1][message.user.business2[message.args[1]].upgrade - 1];
    let text = ``;
    if (!fink) {
      text += `❗ Прибыль в бизнес сейчас не поступает. Введутся тех.работы\n`;
    }

    const businessStats = `статистика бизнеса «${biz.name}»: ❄️
💰 Прибыль: ${utils.sp(Math.floor(biz.earn / biz.workers * message.user.business2[message.args[1]].workers))} $ / ч.

👷‍♂️ Рабочих: ${message.user.business2[message.args[1]].workers}/${biz.workers}

💵 На балансе бизнеса: ${utils.sp(message.user.business2[message.args[1]].moneys)} $

${text}
${businesses2[message.user.business2[message.args[1]].id - 1][message.user.business2[message.args[1]].upgrade] != null ? "▶️ Доступно улучшение бизнеса! Цена: " + utils.sp(businesses2[message.user.business2[message.args[1]].id - 1][message.user.business2[message.args[1]].upgrade].cost) + " $" : ""}`;

    return bot(businessStats, {
      attachment: utils.pick([`${businesses2[message.user.business2[message.args[1]].id - 1][message.user.business2[message.args[1]].upgrade - 1].photo}`])
    });
  }
});

module.exports = commands;