let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
  hear: (pattern, action) => {
    commands.push([pattern, action]);
  }
};

const ostats = [
  {
    id: 1,
    smile: "🐷✨",
    buff: "+100% у урону босса",
    cost: 49,
  },
];

let cars = require('../spisok/машины.js')
let trees = require('../spisok/деревья.js')
let presidents = require("../database/presidents.json");
let autosounder = require('../spisok/autosounder.js')
let sound = require('../spisok/машина динамики.js')
let pets = require('../spisok/питомцы.js')
let pets2 = require('../spisok/питомцы2.js')
let pets3 = require('../spisok/питомцы3.js')
let petsupd = require('../spisok/питомцыул.js')
let yachts = require('../spisok/яхты.js')
let airplanes = require('../spisok/самолеты.js')
let helicopters = require('../spisok/вертолеты.js')
let apartments = require('../spisok/апартаменты.js')
let homes = require('../spisok/дома.js')
let videocards = require('../spisok/видеокарты.js')
let farms = require('../spisok/фермы.js')
let minertool = require('../spisok/инструменты.js')
let computers = require('../spisok/компьютеры.js')
let works = require('../spisok/работники.js')
let businesses2 = require("../spisok/бизнесы.js")
let businesses = require("../spisok/business spisok.js")


const tokensFilePath = './database/tokens.json';

function getToken() {
  try {
    const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
    return tokens; // Возвращаем все данные из файла
  } catch (error) {
    console.error('Ошибка при чтении токенов:', error);
    return null; // Возвращаем null в случае ошибки
  }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
  const tokens = {
    token: token,
    spoler: spoler,
    chatlogi: chatlogi
  };

  try {
    fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
    console.log('Токены успешно сохранены.');
  } catch (error) {
    console.error('Ошибка при сохранении токенов:', error);
  }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:профиль|проф|🔅 Профиль|я)$/i, async (message, bot) => {
  if (message.user.marriage.partner && message.user.questbrak === false) {
    message.user.questbrak = true;

    message.user.c3 += 1;

    await bot(`Поздравляем, вы состоите в браке и с получаете 📦 1 донат-кейс`);
  }


  const groupInfo = await vk.api.call('groups.getById', {
    access_token: tokenData.token,
    v: '5.131',
  });

  if (!groupInfo || groupInfo.length === 0) {
    throw new Error('Не удалось получить информацию о группе.');
  }

  const groupId = groupInfo[0].id;



  let follow = await vk.api.call("groups.isMember", {
    user_id: message.senderId,
    group_id: groupId,
  });

  if (follow) {
    if (message.user.questfollow === false) {
      message.user.questfollow = true;

      await bot(`Вы подписались на группу и получаете 25.ООО.ООО.ООО.ООО$`);

      message.user.balance += 25000000000000;
    }
  }

  if (message.user.settings.agent === undefined) {
    message.user.settings.agent = false;
  }

  let text = ``;

  const pet = pets.find((x) => x.id === message.user.misc.pet);

  const pet2 = pets2.find((x) => x.id === message.user.misc.pet2);

  const pet3 = pets3.find((x) => x.id === message.user.misc.pet3);
  // let president = presidents.find((x) => x.id === message.user.id);

  if (message.user.uid === message.user.astats.fakeid)
    text += `🆔 Ваш ID: ${message.user.uid}\n`;
  if (message.user.uid !== message.user.astats.fakeid)
    text += `🆔 Ваш ID: ${message.user.astats.fakeid}\n`;

  if (message.user.id === spoler) text += "🔥💯 Cоздатель\n";

  if (message.user.prazdnikbussines) text += "🎄Last Christmas🎄\n";

  if (message.user.settings.imperator) text += `👑 IMPERATOR 👑\n`;

  if (message.user.settings.topdon) text += `🎉 D🌟O💖N 🎊\n`;

  if (message.user.settings.vip) text += `👑 VIP статус\n`;

  if (message.user.settings.premium) text += `👑 Premium статус\n`;

  if (message.user.settings.titan) text += `👑 Titan статус\n`;

  if (message.user.settings.joker) text += `🃏 Джокер\n`;

  if (message.user.settings.busi) text += `🤵 Бизнесмен\n`;

  if (message.user.settings.king) text += `🌈КОРОЛЬ🌈\n`;

  if (
    message.user.stock.status !== "Администратор" &&
    message.user.stock.status !== "VIP" &&
    message.user.stock.status !== "Titan" &&
    message.user.stock.status !== "Premium" &&
    message.user.stock.status !== "Игрок"
  )

  if (message.user.ostat > 0)
    text += `\n🆕 Статус: [${ostats[message.user.ostat - 1].smile}]\nБафф: ${ostats[message.user.ostat - 1].buff
      }\n\n`;

  if (message.user.settings.astat) {
    const roles = {
      1: "👤 Модератор",
      2: "🔑 Администратор",
      3: "🤗 Гл.Администратор",
      4: "♻️ Зам создателя",
      5: "❄️ Основатель",
    };


    const userRole = message.user.settings.adm;
    if (roles[userRole]) {
      text += roles[userRole] + "\n";
    }


    for (let i = 1; i < userRole; i++) {
      if (roles[i]) {
        text += roles[i] + "\n";
      }
    }


    if (userRole > 5) {
      text += "❄️ Всевышний админ\n";
    }
  }


  if (message.user.stock.status) {
    text += `🔅 Титул: «${message.user.stock.status}»\n`;
  } else {

  }

  text += `\n💳 Валюты:\n`;

  if (message.user.inf) {
    text += `💰 Наличными: ∞\n`;
  } else {
    text += `💰 Наличными: ${utils.sp(message.user.balance)} $\n`;
  }


  if (message.user.bank)
    text += `💳 В банке: ${utils.sp(message.user.bank)} $\n`;

  if (message.user.btc)
    text += `🌐 Биткоины: ${utils.sp(message.user.btc)} BTC\n`;

  text += `👑 Рейтинг: ${utils.sp(message.user.rating)}\n`;

  text += `⚡ Энергия: ${message.user.energy}
〽️ Опыт:  ${utils.sp(message.user.opit)}\n`;
  if (message.user.balance2 > 0) {
    text += `💸 ${utils.sp(message.user.balance2)} GB\n`;
  } else {

  }

  if (message.user.work)
    text += `⚒️ Работа: ${works[message.user.work - 1].name}\n`;
  if (message.user.marriage.partner === 0)
    
  if (
    message.user.transport.car ||
    message.user.transport.yacht ||
    message.user.transport.airplane ||
    message.user.transport.helicopter ||
    message.user.realty.home ||
    message.user.realty.apartment ||
    message.user.misc.phone ||
    message.user.business ||
    message.user.misc.pet ||
    message.user.misc.clock
  )

 {
    text += `\n♻️ Имущество:\n`;

    if (message.user.transport.car)
      text +=
        `⠀🚗` +
        (message.user.astats.car === false
          ? ` «${cars[message.user.transport.car - 1].name}»`
          : ` «${message.user.astats.car}»`) +
        (message.user.scar.gosnomer === "undefined"
          ? ``
          : ` [${message.user.scar.gosnomer}]`) +
        `\n`;

    if (message.user.transport.yacht)
      text +=
        `⠀🛥` +
        (message.user.astats.yacht === false
          ? ` «${yachts[message.user.transport.yacht - 1].name}»`
          : ` «${message.user.astats.yacht}»`) +
        `\n`;

    if (message.user.transport.airplane)
      text +=
        `⠀🛩` +
        (message.user.astats.airplane === false
          ? ` «${airplanes[message.user.transport.airplane - 1].name}»`
          : ` «${message.user.astats.airplane}»`) +
        `\n`;

    if (message.user.transport.helicopter)
      text +=
        `⠀🚁` +
        (message.user.astats.helicopter === false
          ? ` «${helicopters[message.user.transport.helicopter - 1].name}»`
          : ` «${message.user.astats.helicopter}»`) +
        `\n`;

    if (message.user.realty.home)
      text +=
        `⠀🏠` +
        (message.user.astats.homes === false
          ? ` «${homes[message.user.realty.home - 1].name}»`
          : ` «${message.user.astats.homes}»`) +
        `\n`;

    if (message.user.misc.videocard)
      text +=
        `⠀📼` +
        (message.user.astats.videocard === false
          ? ` «${videocards[message.user.misc.videocard - 1].name}»`
          : ` «${message.user.astats.videocard}»`) +
        `(${utils.sp(message.user.misc.videocard_count)} шт.)` +
        `\n`;

    if (message.user.realty.apartment)
      text +=
        `⠀🌇` +
        (message.user.astats.apartment === false
          ? ` «${apartments[message.user.realty.apartment - 1].name}»`
          : ` «${message.user.astats.apartment}»`) +
        `\n`;

    if (message.user.minertool)
      text += ` 🔧 «${minertool[message.user.minertool - 1].name}»\n`;

    if (message.user.tree)
      text += `⠀🌳 «${trees[message.user.tree - 1].name}»\n`;

    if (message.user.autosound)
      text += `⠀🚗🔊 «${autosounder[message.user.autosound - 1].name}»\n`;

    if (message.user.misc.phone)
      text += `⠀📱 «${phones[message.user.misc.phone - 1].name}»\n`;

    if (message.user.misc.clock)
      text += `⠀⌚ «${clocks[message.user.misc.clock - 1].name}»\n`;

    if (message.user.misc.pet)
      text += `⠀${pet.ico} Питомец: «${pets[message.user.misc.pet - 1].name
        }»\n`;

    if (message.user.misc.pet2)
      text += `⠀${pet2.ico} Питомец: «${pets2[message.user.misc.pet2 - 1].name
        }»\n`;

    if (message.user.misc.pet3)
      text += `⠀${pet3.ico} Питомец: «${pets3[message.user.misc.pet3 - 1].name
        }»\n`;

    if (message.user.misc.computer)
      text += `⠀🖥 «${computers[message.user.misc.computer - 1].name}»\n`;

    if (message.user.misc.farm)
      text += `⠀🔋 «${farms[message.user.misc.farm - 1].name}» (${utils.sp(
        message.user.misc.farm_count
      )} шт.)\n`;

    // Добавление информации о бизнесах
    if (message.user.business && message.user.business.length > 0) {
      text += '🏢 Бизнесы на GB:\n';
      for (let business of message.user.business) {
        const businessInfo = businesses[business.id - 1][business.upgrade - 1];
        text += `${businessInfo.icon} ${businessInfo.name}\n`;
      }
    } else {

    }

    if (message.user.business2 && message.user.business2.length > 0) {
      text += '🏢 Бизнесы на валюту:\n';
      for (let business2 of message.user.business2) {
        const businessInfo = businesses2[business2.id - 1][business2.upgrade - 1];
        text += `${businessInfo.icon} ${businessInfo.name}\n`;
      }
    } else {

    }

    if (
      message.user.stars1 ||
      message.user.stars2 ||
      message.user.stars3 ||
      message.user.stars4 ||
      message.user.stars5
    )
      text += `\n💫 Звезды:\n`;

    if (message.user.stars1) text += `⠀☀ Солнце\n`;

    if (message.user.stars2) text += `⠀🌠 Сириус\n`;

    if (message.user.stars3) text += `⠀🛑 Красный гигант\n`;

    if (message.user.stars4) text += `⠀🧬 Плазмовый гигант\n`;

    if (message.user.stars5) text += `⠀💰 Донатный гигант\n`;
  }

  text += `\n⏳ ${message.user.regDate}`;

  return bot(`ваш игровой профиль:\n${text}`, {
    attachment: message.user.photo,
  });
});

cmd.hear(/^(?:профиль фото|проф фото|пфото)\s(.*)$/i, async (message, bot) => {
  message.user.photo = message.args[1];

  return bot(`ваш профиль изменён 🤗`);
});


module.exports = commands;
