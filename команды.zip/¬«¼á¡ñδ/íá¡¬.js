let utils = require('../utils.js')

const commands = [];

const fs = require('fs');

let double = require('../database/users.json')

const cmd = {
    hear: (pattern, action) => {
        commands.push([pattern, action]);
    }
};

const tokensFilePath = './database/tokens.json';

function getToken() {
    try {
        const tokens = JSON.parse(fs.readFileSync(tokensFilePath, 'utf8'));
        return tokens; // Возвращаем все данные из файла
    } catch (error) {
        console.error('Ошибка при чтении токенов:', error);
        return null; // Возвращаем null в случае ошибки
    }
}

// Функция для записи токена и других данных
function saveTokens(token, spoler, chatlogi) {
    const tokens = {
        token: token,
        spoler: spoler,
        chatlogi: chatlogi
    };

    try {
        fs.writeFileSync(tokensFilePath, JSON.stringify(tokens, null, 2), 'utf8');
        // console.log('Токены успешно сохранены.');
    } catch (error) {
        console.error('Ошибка при сохранении токенов:', error);
    }
}

// Пример использования
const tokenData = getToken();

const chatlogi = tokenData.chatlogi; // чат для логов 
const spoler = tokenData.spoler;
const { VK } = require('vk-io');
const vk = new VK({ token: tokenData.token });

cmd.hear(/^(?:банк)$/i, async (message, bot) => {

    if (message.chat.type == 0) {
        await bot(`🏦 На вашем банковском счету находится ${utils.sp(message.user.bank)} $ 🌧️`)
        return
    }

    if ( message.chat.type === 1) {
        const chat = message.chat;
        if (
            chat.gametime <= 5
        ) return bot(`до конца раунда осталось менее пяти секунд, ставки не принимаются`)




        const currentGame = message.chat.games[message.chat.games.length - 1];
        if (!currentGame.stavki[0]) {
            return bot(`в этом раунде еще никто не поставил

Хеш игры: ${currentGame.hash}


        `);
        }


        let stakes = {
            x2: '\nCтавки на x2:\n',
            x3: '\nСтавки на x3:\n',
            x5: '\nСтавки на x5:\n',
            x50: '\nСтавки на x50:\n'
        };


        for (let id in currentGame.stavki) {
            let user = currentGame.stavki[id];
            let userTag = `[id${user.id}|${double.find(x => x.id === user.id).tag}] - ${utils.sp(user.amount)} GB\n`;

            switch (user.type) {
                case 2:
                    stakes.x2 += userTag;
                    break;
                case 3:
                    stakes.x3 += userTag;
                    break;
                case 5:
                    stakes.x5 += userTag;
                    break;
                case 50:
                    stakes.x50 += userTag;
                    break;
            }
        }


        let text = '';
        if (stakes.x2.length > 15) text += stakes.x2;
        if (stakes.x3.length > 15) text += stakes.x3;
        if (stakes.x5.length > 15) text += stakes.x5;
        if (stakes.x50.length > 16) text += stakes.x50;


        const totalStaked = utils.sp(currentGame.stavki.reduce((sum, stake) => sum + stake.amount, 0));


        bot(`всего поставлено: ${utils.sp(totalStaked)} GB 💸
${text}

Хеш игры: 
${currentGame.hash}

До конца раунда: ${message.chat.gametime} сек.
    `);
        return
    }



});


cmd.hear(/^(?:банк)\s(?:снять)\s(.*)$/i, async (message, bot) => {
    if ((message.chat && message.chat.type === 0) || message.peerType === 'user') {
        message.args[1] = message.args[1].replace(/([.,])/gi, "");

        message.args[1] = message.args[1].replace(/([кk])/gi, "000");

        message.args[1] = message.args[1].replace(/([мm])/gi, "000000");

        message.args[1] = message.args[1].replace(
            /(вабанк|вобанк|все|всё)/gi,
            message.user.bank
        );

        if (message.user.inf === true) return bot(`выключите безлимитный баланс`);

        if (!Number(message.args[1])) return;

        message.args[1] = Math.floor(Number(message.args[1]));

        if (message.args[1] <= 0) return;

        if (message.args[1] > message.user.bank) return bot(`у вас нет данной суммы`);
        else if (message.args[1] <= message.user.bank) {
            message.user.balance += message.args[1];

            message.user.bank -= message.args[1];

            return bot(
                `вы успешно сняли ${utils.sp(
                    message.args[1]
                )}$ со своего банковского счёта 💳

▶️ Остаток на счёте: ${utils.sp(message.user.bank)}$
💰 Ваш баланс: ${utils.sp(message.user.balance)}$`,
                { attachment: `photo-228669263_457239017` }
            );
        }
    }
});

cmd.hear(/^(?:банк)\s(.*)$/i, async (message, bot) => {
    if ((message.chat && message.chat.type === 0) || message.peerType === 'user') {
        message.args[1] = message.args[1].replace(/([.,])/gi, "");
        message.args[1] = message.args[1].replace(/([кk])/gi, "000");
        message.args[1] = message.args[1].replace(/([мm])/gi, "000000");
        message.args[1] = message.args[1].replace(
            /(вабанк|вобанк|все|всё)/gi,
            message.user.balance
        );
        if (message.user.inf === true) return bot(`выключите безлимитный баланс`);

        if (!Number(message.args[1])) return;

        message.args[1] = Math.floor(Number(message.args[1]));

        if (message.args[1] <= 0) return;
        if (message.args[1] <= 14) return bot(`минимальная сумма вклада 50$`);
        if (message.user.banklim === undefined) {
            message.user.banklim = false;
        }

        if (!message.user.settings.imperator) {
            if (
                message.args[1] + message.user.bank - 1 >= message.user.limit.banklimit &&
                !message.user.banklim
            )
                return bot(
                    `максимальная сумма вклада ${utils.sp(message.user.limit.banklimit)}$`
                );
            if (
                message.args[1] + message.user.bank - 1 >= 100000000000000000 &&
                message.user.banklim
            )
                return bot(`максимальная сумма вклада 100.000.000.000.000.000 $ ❌`);
        }

        if (message.args[1] > message.user.balance)
            return bot(`у вас нет данной суммы`);
        else if (message.args[1] <= message.user.balance) {
            message.user.balance -= message.args[1];
            message.user.bank += message.args[1];
            return bot(
                `вы успешно положили на свой банковский счёт ${utils.sp(
                    message.args[1]
                )}$ 💵💰`
            );
        }
    }
});

module.exports = commands;
