const utils = require('../utils.js');

const businesses2 = [
    [
        {


            name: "Захудалая лачуга️",

            photo: "",

            cost: utils.numstring("100.000.000"),

            earn: utils.numstring("100.000"),

            workers: 2,

            id: 1,

            icon: "🏚",
        },

        {

            name: "Деревенская таверна",

            photo: "",

            cost: utils.numstring("5.000.000"),

            earn: utils.numstring("500.000"),

            workers: 10,

            id: 1,

            icon: "🍻",
        },

        {


            name: "Городская гильдия",

            photo: "",

            cost: utils.numstring("10.000.000"),

            earn: utils.numstring("900.000"),

            workers: 30,

            id: 1,

            icon: "🏰",
        },

        {


            name: "Королевский дворец",

            photo: "",

            cost: utils.numstring("20.000.000"),

            earn: utils.numstring("1.000.000"),

            workers: 50,

            id: 1,

            icon: "👑",
        },

        {


            name: "Заколдованный лес",

            photo: "",

            cost: utils.numstring("40.000.000"),

            earn: utils.numstring("1.500.000"),

            workers: 200,

            id: 1,

            icon: "🌲",
        },

        {


            name: "Подземный лабиринт",

            photo: "",

            cost: utils.numstring("80.000.000"),

            earn: utils.numstring("2.000.000"),

            workers: 750,

            id: 1,

            icon: "🔦",
        },
    ],
    [
        {
            name: "Песочница sandbox",

            photo: "",

            cost: utils.numstring("1.000.000.000"),

            earn: utils.numstring("3.000.000"),

            workers: 1,

            id: 2,

            icon: "🏖",
        },

        {
            name: "Игровая площадка Playground",

            photo: "",

            cost: utils.numstring("500.000.000"),

            earn: utils.numstring("6.000.000"),

            workers: 5,

            id: 2,

            icon: "🤸‍♀",
        },

        {
            name: "Развлекательный центр",

            photo: "",

            cost: utils.numstring("1.000.000.000"),

            earn: utils.numstring("8.000.000"),

            workers: 10,

            id: 2,

            icon: "🎉",
        },

        {
            name: "Виртуальный парк",

            photo: "",

            cost: utils.numstring("3.000.000.000"),

            earn: utils.numstring("12.000.000"),

            workers: 40,

            id: 2,

            icon: "🎢",
        },

        {
            name: "Захватывающий мир",

            photo: "",

            cost: utils.numstring("5.000.000.000"),

            earn: utils.numstring("24.000.000"),

            workers: 150,

            id: 2,

            icon: "🌎",
        },

        {
            name: "Метавселенная",

            photo: "",

            cost: utils.numstring("10.000.000.000"),

            earn: utils.numstring("50.000.000"),

            workers: 400,

            id: 2,

            icon: "🌐",
        },
    ],

    [
        {
            name: "Дискетка",

            photo: "",

            cost: utils.numstring("10.000.000.000"),

            earn: utils.numstring("18.000.000"),

            workers: 3,

            id: 3,

            icon: "💾",
        },

        {
            name: "CD-ROM",

            photo: "",

            cost: utils.numstring("50.000.000.000"),

            earn: utils.numstring("18.000.000"),

            workers: 7,

            id: 3,

            icon: "💿",
        },

        {
            name: "DVD-диск",

            photo: "",

            cost: utils.numstring("90.000.000.000"),

            earn: utils.numstring("22.000.000"),

            workers: 15,

            id: 3,

            icon: "📀",
        },

        {
            name: "Blu-ray Blu-ray",

            photo: "",

            cost: utils.numstring("150.000.000.000"),

            earn: utils.numstring("30.000.000"),

            workers: 80,

            id: 3,

            icon: "🫙",
        },

        {
            name: "Облачное хранилище",

            photo: "",

            cost: utils.numstring("250.000.000.000"),

            earn: utils.numstring("50.000.000"),

            workers: 300,

            id: 3,

            icon: "☁",
        },

        {
            name: "Серверная ферма",

            photo: "",

            cost: utils.numstring("500.000.000.000"),

            earn: utils.numstring("100.000.000"),

            workers: 300,

            id: 3,

            icon: "🖥",
        },
    ],

    [
        {
            name: "Кафе",

            photo: "",

            cost: utils.numstring("100.000.000.000"),

            earn: utils.numstring("96.000.000"),

            workers: 3,

            id: 4,

            icon: "☕",
        },

        {
            name: "Ресторан",

            photo: "",

            cost: utils.numstring("500.000.000.000"),

            earn: utils.numstring("260.000.000"),

            workers: 10,

            id: 4,

            icon: "🍽",
        },

        {
            name: "Элитный ресторан",

            photo: "",

            cost: utils.numstring("1.000.000.000.000"),

            earn: utils.numstring("350.000.000"),

            workers: 70,

            id: 4,

            icon: "🥂",
        },

        {
            name: "Гастрономический рай",

            photo: "",

            cost: utils.numstring("1.500.000.000.000"),

            earn: utils.numstring("500.000.000"),

            workers: 500,

            id: 4,

            icon: "🤤",
        },


        {
            name: "Мишленовский ресторан",

            photo: "",

            cost: utils.numstring("7.000.000.000.000"),

            earn: utils.numstring("1.500.000.000"),

            workers: 500,

            id: 4,

            icon: "⭐",
        },
    ],

    [
        {
            name: "Уличный киоск",

            photo: "",

            cost: utils.numstring("500.000.000.000"),

            earn: utils.numstring("576.000.000"),

            workers: 5,

            id: 5,

            icon: "🌆",
        },

        {
            name: "Маленький магазинчик",

            photo: "",

            cost: utils.numstring("1.000.000.000.000"),

            earn: utils.numstring("800.000.000"),

            workers: 20,

            id: 5,

            icon: "🌆",
        },

        {
            name: "Просторный магазин",

            photo: "",

            cost: utils.numstring("5.000.000.000.000"),

            earn: utils.numstring("1.500.000.000"),

            workers: 200,

            id: 5,

            icon: "🌆",
        },

        {
            name: "Торговый центр",

            photo: "",

            cost: utils.numstring("7.000.000.000.000"),

            earn: utils.numstring("2.000.000.000"),

            workers: 1000,

            id: 5,

            icon: "🌆",
        },

        {
            name: "Онлайн-магазин",

            photo: "",

            cost: utils.numstring("9.000.000.000.000"),

            earn: utils.numstring("5.000.000.000"),

            workers: 1000,

            id: 5,

            icon: "🌆",
        },

        {
            name: "Международная сеть",

            photo: "",

            cost: utils.numstring("11.000.000.000.000"),

            earn: utils.numstring("10.000.000.000"),

            workers: 1000,

            id: 5,

            icon: "🌎",
        },
    ],

    [
        {
            name: "Подвальный магазинчик",

            photo: "",

            cost: utils.numstring("2.000.000.000.000"),

            earn: utils.numstring("3.456.000.000"),

            workers: 50,

            id: 6,

            icon: "📦",
        },

        {
            name: "Магазинчик у метро",

            photo: "",

            cost: utils.numstring("1.000.000.000.000"),

            earn: utils.numstring("5.000.000.000"),

            workers: 75,

            id: 6,

            icon: "🚇",
        },

        {
            name: "Интернет-магазин",

            photo: "",

            cost: utils.numstring("5.000.000.000.000"),

            earn: utils.numstring("10.000.000.000"),

            workers: 200,

            id: 6,

            icon: "💻",
        },

        {
            name: "Геймерский бутик",

            photo: "",

            cost: utils.numstring("7.000.000.000.000"),

            earn: utils.numstring("30.000.000.000"),

            workers: 360,

            id: 6,

            icon: "✨",
        },

        {
            name: "Онлайн-платформа",

            photo: "",

            cost: utils.numstring("10.000.000.000.000"),

            earn: utils.numstring("80.000.000.000"),

            workers: 700,

            id: 6,

            icon: "🌐",
        },

        {
            name: "Международная сеть",

            photo: "",

            cost: utils.numstring("20.000.000.000.000"),

            earn: utils.numstring("130.000.000.000"),

            workers: 700,

            id: 6,

            icon: "🌍",
        },
    ],

    [
        {
            name: "Доска достижений",

            photo: "",

            cost: utils.numstring("10.000.000.000.000"),

            earn: utils.numstring("22.500.000.000"),

            workers: 10,

            id: 7,

            icon: "🏆",
        },

        {
            name: "Клуб достижений",

            photo: "",

            cost: utils.numstring("10.000.000.000.000"),

            earn: utils.numstring("50.000.000.000"),

            workers: 60,

            id: 7,

            icon: "🎉",
        },

        {
            name: "Онлайн-платформа",

            photo: "",

            cost: utils.numstring("20.000.000.000.000"),

            earn: utils.numstring("100.000.000.000"),

            workers: 200,

            id: 7,

            icon: "🕹",
        },

        {
            name: "Соревновательная Арена",

            photo: "",

            cost: utils.numstring("30.000.000.000.000"),

            earn: utils.numstring("300.000.000.000"),

            workers: 700,

            id: 7,

            icon: "🔥",
        },

        {
            name: "Вселенная Достижений",

            photo: "",

            cost: utils.numstring("50.000.000.000.000"),

            earn: utils.numstring("600.000.000.000"),

            workers: 700,

            id: 7,

            icon: "🚀",
        },

        {
            name: "Зал Славы",

            photo: "",

            cost: utils.numstring("80.000.000.000.000"),

            earn: utils.numstring("1.500.000.000.000"),

            workers: 700,

            id: 7,

            icon: "✨",
        },
    ],

    [
        {
            name: "Комната отдыха",

            photo: "",

            cost: utils.numstring("50.000.000.000.000"),

            earn: utils.numstring("200.000.000.000"),

            workers: 5,

            id: 8,

            icon: "🎮",
        },

        {
            name: "Клуб геймеров",

            photo: "",

            cost: utils.numstring("12.000.000.000.000"),

            earn: utils.numstring("200.000.000.000"),

            workers: 10,

            id: 8,

            icon: "🍻",
        },

        {
            name: "Киберспортивный центр",

            photo: "",

            cost: utils.numstring("20.000.000.000.000"),

            earn: utils.numstring("350.000.000.000"),

            workers: 50,

            id: 8,

            icon: "🏆",
        },

        {
            name: "Геймерский отель",

            photo: "",

            cost: utils.numstring("30.000.000.000.000"),

            earn: utils.numstring("500.000.000.000"),

            workers: 500,

            id: 8,

            icon: "🏨",
        },

        {
            name: "Развлекательный комплекс",

            photo: "",

            cost: utils.numstring("50.000.000.000.000"),

            earn: utils.numstring("800.000.000.000"),

            workers: 500,

            id: 8,

            icon: "🎉",
        },

        {
            name: "Геймерский рай на Земле",

            photo: "",

            cost: utils.numstring("80.000.000.000.000"),

            earn: utils.numstring("2.000.000.000.000"),

            workers: 500,

            id: 8,

            icon: "🤩",
        },
    ],

    [
        {
            name: "Старый сундук",

            photo: "",

            cost: utils.numstring("100.000.000.000.000"),

            earn: utils.numstring("300.000.000.000"),

            workers: 8,

            id: 9,

            icon: "🏜",
        },

        {
            name: "Волшебный магазин",

            photo: "",

            cost: utils.numstring("50.000.000.000.000"),

            earn: utils.numstring("500.000.000.000"),

            workers: 20,

            id: 9,

            icon: "🧙‍♂",
        },

        {
            name: "Храм реликвий",

            photo: "",

            cost: utils.numstring("80.000.000.000.000"),

            earn: utils.numstring("800.000.000.000"),

            workers: 50,

            id: 9,

            icon: "🙏",
        },

        {
            name: "Зачарованный магазин",

            photo: "",

            cost: utils.numstring("100.000.000.000.000"),

            earn: utils.numstring("2.000.000.000.000"),

            workers: 250,

            id: 9,

            icon: "🌟",
        },

        {
            name: "Магазин артефактов",

            photo: "",

            cost: utils.numstring("150.000.000.000.000"),

            earn: utils.numstring("5.000.000.000.000"),

            workers: 250,

            id: 9,

            icon: "💎",
        },

        {
            name: "Зал сокровищ",

            photo: "",

            cost: utils.numstring("200.000.000.000.000"),

            earn: utils.numstring("10.000.000.000.000"),

            workers: 250,

            id: 9,

            icon: "💰",
        },
    ],

    [
        {
            name: "Консоль управления",

            photo: "",

            cost: utils.numstring("1.000.000.000.000.000"),

            earn: utils.numstring("2.400.000.000.000"),

            workers: 40,

            id: 10,

            icon: "💡",
        },

        {
            name: "Пульт управления ⚙",

            photo: "",

            cost: utils.numstring("150.000.000.000.000"),

            earn: utils.numstring("5.000.000.000.000"),

            workers: 75,

            id: 10,

            icon: "💡",
        },

        {
            name: "Квантовый компьютер",

            photo: "",

            cost: utils.numstring("200.000.000.000.000"),

            earn: utils.numstring("9.000.000.000.000"),

            workers: 300,

            id: 10,

            icon: "⚛",
        },

        {
            name: "ИИ-система управления",

            photo: "",

            cost: utils.numstring("250.000.000.000.000"),

            earn: utils.numstring("15.000.000.000.000"),

            workers: 650,

            id: 10,

            icon: "🤖",
        },

        {
            name: "Искусственный разум",

            photo: "",

            cost: utils.numstring("300.000.000.000.000"),

            earn: utils.numstring("19.000.000.000.000"),

            workers: 650,

            id: 10,

            icon: "🧠",
        },
    ],

    [
        {
            name: "Новичок",

            photo: "",

            cost: utils.numstring("15.000.000.000.000.000"),

            earn: utils.numstring("20.000.000.000.000"),

            workers: 100,

            id: 11,

            icon: "👶",
        },

        {
            name: " Ученик",

            photo: "",

            cost: utils.numstring("1.500.000.000.000.000"),

            earn: utils.numstring("30.000.000.000.000"),

            workers: 200,

            id: 11,

            icon: "📚",
        },

        {
            name: "Мастер",

            photo: "",

            cost: utils.numstring("2.000.000.000.000.000"),

            earn: utils.numstring("50.000.000.000.000"),

            workers: 350,

            id: 11,

            icon: "🏆",
        },

        {
            name: "Эксперт",

            photo: "",

            cost: utils.numstring("3.000.000.000.000.000"),

            earn: utils.numstring("70.000.000.000.000"),

            workers: 650,

            id: 11,

            icon: "🤓",
        },

        {
            name: "Легенда",

            photo: "",

            cost: utils.numstring("4.000.000.000.000.000"),

            earn: utils.numstring("90.000.000.000.000"),

            workers: 650,

            id: 11,

            icon: "🌟",
        },

        {
            name: "Творец",

            photo: "",

            cost: utils.numstring("5.000.000.000.000.000"),

            earn: utils.numstring("100.000.000.000.000"),

            workers: 650,

            id: 11,

            icon: "👨‍🎨",
        },
    ],

    [
        {
            name: "Лоток на рынке",

            photo: "photo-211261524_457239207",

            cost: utils.numstring("150.000.000.000.000.000"),

            earn: utils.numstring("100.000.000.000.000"),

            workers: 10000,

            id: 12,

            icon: "🛸",
        },

        {
            name: "Международная торговая площадка",

            photo: "",

            cost: utils.numstring("5.000.000.000.000.000"),

            earn: utils.numstring("150.000.000.000.000"),

            workers: 10000,

            id: 12,

            icon: "🌍",
        },

        {
            name: "Цифровая Империя",

            photo: "",

            cost: utils.numstring("10.000.000.000.000.000"),

            earn: utils.numstring("200.000.000.000.000"),

            workers: 10000,

            id: 12,

            icon: "👑",
        },
    ],

    [
        {
            name: "Золотая лихорадка",

            photo: "photo-211261524_457239207",

            cost: utils.numstring("1.000.000.000.000.000.000"),

            earn: utils.numstring("100.000.000.000.000"),

            workers: 10000,

            id: 13,

            icon: "💰",
        },

        {
            name: "Запретный город",

            photo: "",

            cost: utils.numstring("500.000.000.000.000.000"),

            earn: utils.numstring("200.000.000.000.000"),

            workers: 10000,

            id: 13,

            icon: "🏯",
        },

        {
            name: "Город сокровищ",

            photo: "",

            cost: utils.numstring("1.000.000.000.000.000.000"),

            earn: utils.numstring("500.000.000.000.000"),

            workers: 10000,

            id: 13,

            icon: "💎",
        },
    ],

    [
        {
            name: "Заброшенная пещера",

            photo: "photo-211261524_457239207",

            cost: utils.numstring("25.000.000.000.000.000.000"),

            earn: utils.numstring("2.000.000.000.000.000"),

            workers: 10000,

            id: 14,

            icon: "🦇",
        },

        {
            name: "Запретная зона",

            photo: "",

            cost: utils.numstring("1.000.000.000.000.000.000"),

            earn: utils.numstring("3.000.000.000.000.000"),

            workers: 10000,

            id: 14,

            icon: "⛔",
        },

        {
            name: "Бездна",

            photo: "",

            cost: utils.numstring("10.000.000.000.000.000.000"),

            earn: utils.numstring("4.000.000.000.000.000"),

            workers: 10000,

            id: 14,

            icon: "🕳",
        },

        {
            name: "Преисподняя",

            photo: "",

            cost: utils.numstring("15.000.000.000.000.000.000"),

            earn: utils.numstring("5.000.000.000.000.000"),

            workers: 10000,

            id: 14,

            icon: "🔥",
        },
    ],

    [
        {
            name: "Глобальный рынок",

            photo: "photo-211261524_457239207",

            cost: utils.numstring("50.000.000.000.000.000.000"),

            earn: utils.numstring("5.000.000.000.000.000"),

            workers: 10000,

            id: 15,

            icon: "🛸",
        },

        {
            name: "Метавселенная товаров",

            photo: "",

            cost: utils.numstring("15.000.000.000.000.000.000"),

            earn: utils.numstring("8.000.000.000.000.000"),

            workers: 10000,

            id: 15,

            icon: "🌌",
        },

        {
            name: "Темница",

            photo: "",

            cost: utils.numstring("40.000.000.000.000.000.000"),

            earn: utils.numstring("10.000.000.000.000.000"),

            workers: 10000,

            id: 15,

            icon: "👑",
        },
    ],

    [
        {
            name: "Киностудии по всему миру",

            cost: utils.numstring("15.000.000.000.000.000"),

            earn: utils.numstring("250.000.000.000.000"),

            workers: 7500,

            id: 16,

            icon: "📹",
        },

        {
            name: "Киностудии по всей галактике",

            photo: "",

            cost: utils.numstring("20.000.000.000.000.000"),

            earn: utils.numstring("300.000.000.000.000"),

            workers: 10000,

            id: 16,

            icon: "📹",
        },
    ],

    [
        {
            name: "Кладбище зомби",

            cost: 1000000000,

            earn: 1000000000000,

            workers: 1,

            id: 17,

            icon: "☣",
        },

        {
            name: "Кладбище скелетов",

            cost: 1000000000000000,

            earn: 3000000000000,

            workers: 1,

            id: 17,

            icon: "☣",
        },

        {
            name: "Кладбище духов",

            cost: 2000000000000000,

            earn: 10000000000000,

            workers: 1,

            id: 17,

            icon: "☣",
        },
    ],

    [
        {
            name: "꧁༒☆•ѦƊ•☆༒꧂",

            photo: "photo-197579361_457241472",

            cost: 2000000000000000,

            earn: 6666666666666,

            workers: 666666666,

            id: 18,

            icon: "☣",
        },
    ],

    [
        {
            name: "Ледяные миньоны",

            photo: "photo-197579361_457241609",

            cost: 2000000000000000,

            earn: 10000000000000,

            workers: 20,

            id: 19,

            icon: "❄",
        },
    ],

    [
        {
            name: "🤯𝙹𝚜𝚙𝚏𝚘𝚘𝚕𝚑𝟷𝟿🤯",

            photo: "photo-197579361_457247553",

            cost: 2000000000000000,

            earn: 6000000000000,

            workers: 5,

            id: 20,

            icon: "♻",
        },
    ],

    [
        {
            name: "Страдания людей",

            photo: "photo-197579361_457265687",

            cost: 10000000000000,

            earn: 10000000000000,

            workers: 4,

            id: 21,

            icon: "☣",
        },
    ],

    [
        {
            name: "Sex Shop",

            photo: "photo-197579361_457265686",

            cost: 10000000000000,

            earn: 10000000000000,

            workers: 5000,

            id: 22,

            icon: "☣",
        },
    ],

    [
        {
            name: "Корпорация по сборке ПК",

            photo: "photo-197579361_457265689",

            cost: 10000000000000,

            earn: 10000000000000,

            workers: 12345654321,

            id: 23,

            icon: "☣",
        },
    ],

    [
        {
            name: "Майнинг биткоинов",

            photo: "photo-197579361_457337226",

            cost: 2000000000000000,

            earn: 20000000000000,

            workers: 500,

            id: 24,

            icon: "🌐",
        },
    ],

    [
        {
            name: "Сытый Ёжик",

            cost: 1000000000000000,

            earn: 15000000000000,

            workers: 666,

            id: 25,

            icon: "🦔",
        },
    ],

    [
        {
            name: "Атл групп",

            photo: "photo-197579361_457342282",

            cost: 1000000000000000,

            earn: 15000000000000,

            workers: 500,

            id: 26,

            icon: "🅰️",
        },
    ],

    [
        {
            name: "Личный Бизнес",

            photo: "photo",

            cost: 1000000000000000,

            earn: 15000000000000,

            workers: 666,

            id: 27,

            icon: "📇",
        },
    ],

    [
        {
            name: "TikTok House",

            photo: "photo",

            cost: 1000000000000000,

            earn: 15000000000000,

            workers: 666,

            id: 28,

            icon: "🏠",
        },
    ],

    [
        {
            name: "TikTok House",

            photo: "photo",

            cost: 1000000000000000,

            earn: 15000000000000,

            workers: 666,

            id: 29,

            icon: "🏠",
        },
    ],

    [
        {
            name: "Космодром и полеты на Венеру",

            photo: "photo-211261524_457255183",

            cost: 1000000000000000,

            earn: 40000000000000,

            workers: 40000,

            id: 30,

            icon: "🏠",
        },
    ],

    [
        {
            name: "Магазин Живого пива",

            photo: "photo-211261524_457260547",

            cost: 1000000000000000,

            earn: 25000000000000,

            workers: 40000,

            id: 31,

            icon: "🏠",
        },
    ],

    [
        {
            name: "🌪ᴘᴀʀᴀᴅɪsᴇ🌪",

            photo: "photo-211261524_457260547",

            cost: 1000000000000000,

            earn: 10000000000000,

            workers: 40000,

            id: 32,

            icon: "🏠",
        },
    ],

    [
        {
            name: "Личная шахта",

            photo: "photo-211261524_457279755",

            cost: 1500000000000000,

            earn: 15000000000000,

            workers: 40000,

            id: 33,

            icon: "🧨",
        },
    ],

    [
        {
            name: "Аэропорт",

            photo: "",

            cost: 1500000000000000,

            earn: 5000000000000,

            workers: 40000,

            id: 34,

            icon: "🧨",
        },

        {
            name: "Аэропорт",

            photo: "",

            cost: 1500000000000000,

            earn: 15000000000000,

            workers: 40000,

            id: 34,

            icon: "🧨",
        },
    ],
];

module.exports = businesses2;
