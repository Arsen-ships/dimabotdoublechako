const utils = require('../utils.js'); 

const businesses = [
  [
    {
      name: "Шаурмечная",

      photo: "doc777271147_682500050",

      cost: utils.numstring("50.000"),

      earn: utils.numstring("500"),

      workers: 2,

      id: 1,

      icon: "🥖",
    },

    {

      name: "5 шаурмечных",

      photo: "doc777271147_682500050",

      cost: utils.numstring("60.000"),

      earn: utils.numstring("1.000"),

      workers: 10,

      id: 1,

      icon: "🥖",
    },

    {

      name: "Небольшая сеть шаурмечных",

      photo: "doc777271147_682500050",

      cost: utils.numstring("65.000"),

      earn: utils.numstring("2.000"),

      workers: 30,

      id: 1,

      icon: "🥖",
    },

    {

      name: "Средняя сеть шаурмечных",

      photo: "doc777271147_682500050",

      cost: utils.numstring("75.000"),

      earn: utils.numstring("3.000"),

      workers: 50,

      id: 1,

      icon: "🥖",
    },

    {

      name: "Лучшие шаурмечные в стране",

      photo: "doc777271147_682500050",

      cost: utils.numstring("80.000"),

      earn: utils.numstring("4.000"),

      workers: 200,

      id: 1,

      icon: "🥖",
    },

    {

      name: "Мировая шаурмечная",

      photo: "doc777271147_682500050",

      cost: utils.numstring("90.000"),

      earn: utils.numstring("5.000"),

      workers: 750,

      id: 1,

      icon: "🥖",
    },
  ],

  [
    {
      name: "Ларёк",

      photo: "doc777271147_682500070",

      cost: utils.numstring("100.000"),

      earn: utils.numstring("2.000"),

      workers: 1,

      id: 2,

      icon: "🏪",
    },

    {
      name: "5 ларьков",

      photo: "doc777271147_682500070",

      cost: utils.numstring("130.000"),

      earn: utils.numstring("3.000"),

      workers: 5,

      id: 2,

      icon: "🏪",
    },

    {
      name: "Небольшая сеть ларьков",

      photo: "doc777271147_682500070",

      cost: utils.numstring("150.000"),

      earn: utils.numstring("4.000"),

      workers: 10,

      id: 2,

      icon: "🏪",
    },

    {
      name: "Средняя сеть ларьков",

      photo: "doc777271147_682500070",

      cost: utils.numstring("180.000"),

      earn: utils.numstring("5.000"),

      workers: 40,

      id: 2,

      icon: "🏪",
    },

    {
      name: "Ларьки во всех городах страны",

      photo: "doc777271147_682500070",

      cost: utils.numstring("190.000"),

      earn: utils.numstring("8.000"),

      workers: 150,

      id: 2,

      icon: "🏪",
    },

    {
      name: "Ларьки в каждой стране",

      photo: "doc777271147_682500070",

      cost: utils.numstring("215.000"),

      earn: utils.numstring("10.000"),

      workers: 400,

      id: 2,

      icon: "🏪",
    },
  ],

  [
    {
      name: "Забегаловка",

      photo: "doc777271147_682500079",

      cost: utils.numstring("250.000"),

      earn: utils.numstring("6.000"),

      workers: 3,

      id: 3,

      icon: "🍴",
    },

    {
      name: "Общепит",

      photo: "doc777271147_682500079",

      cost: utils.numstring("250.000"),

      earn: utils.numstring("7.000"),

      workers: 7,

      id: 3,

      icon: "🍴",
    },

    {
      name: "Ресторан",

      photo: "doc777271147_682500079",

      cost: utils.numstring("270.000"),

      earn: utils.numstring("8.000"),

      workers: 15,

      id: 3,

      icon: "🍴",
    },

    {
      name: "Небольшая сеть ресторанов",

      photo: "doc777271147_682500079",

      cost: utils.numstring("290.000"),

      earn: utils.numstring("10.000"),

      workers: 80,

      id: 3,

      icon: "🍴",
    },

    {
      name: "Лучшие рестораны в стране",

      photo: "doc777271147_682500079",

      cost: utils.numstring("310.000"),

      earn: utils.numstring("13.000"),

      workers: 300,

      id: 3,

      icon: "🍴",
    },

    {
      name: "Лучшие рестораны в мире",

      photo: "doc777271147_682500079",

      cost: utils.numstring("340.000"),

      earn: utils.numstring("15.000"),

      workers: 300,

      id: 3,

      icon: "🍴",
    },
  ],

  [
    {
      name: "Мини-магазин",

      photo: "doc777271147_682500095",

      cost: utils.numstring("350.000"),

      earn: utils.numstring("4.000"),

      workers: 3,

      id: 4,

      icon: "👛",
    },

    {
      name: "Магазин",

      photo: "doc777271147_682500095",

      cost: utils.numstring("405.000"),

      earn: utils.numstring("7.000"),

      workers: 10,

      id: 4,

      icon: "👛",
    },

    {
      name: "Сеть магазинов",

      photo: "doc777271147_682500095",

      cost: utils.numstring("435.000"),

      earn: utils.numstring("12.000"),

      workers: 70,

      id: 4,

      icon: "👛",
    },

    {
      name: "Сеть супермаркетов",

      photo: "doc777271147_682500095",

      cost: utils.numstring("450.000"),

      earn: utils.numstring("13.000"),

      workers: 500,

      id: 4,

      icon: "👛",
    },

    {
      name: "Сеть гипермаркетов",

      photo: "doc777271147_682500095",

      cost: utils.numstring("480.000"),

      earn: utils.numstring("17.000"),

      workers: 500,

      id: 4,

      icon: "👛",
    },

    {
      name: "Крупнейший ТЦ",

      photo: "doc777271147_682500095",

      cost: utils.numstring("490.000"),

      earn: utils.numstring("20.000"),

      workers: 500,

      id: 4,

      icon: "👛",
    },
  ],

  [
    {
      name: "Завод в гараже",

      photo: "doc777271147_682500103",

      cost: utils.numstring("500.000"),

      earn: utils.numstring("5.000"),

      workers: 5,

      id: 5,

      icon: "🌆",
    },

    {
      name: "Средний завод",

      photo: "doc777271147_682500103",

      cost: utils.numstring("555.000"),

      earn: utils.numstring("7.000"),

      workers: 20,

      id: 5,

      icon: "🌆",
    },

    {
      name: "Сеть заводов",

      photo: "doc777271147_682500103",

      cost: utils.numstring("600.000"),

      earn: utils.numstring("13.000"),

      workers: 200,

      id: 5,

      icon: "🌆",
    },

    {
      name: "Главные заводы страны",

      photo: "doc777271147_682500103",

      cost: utils.numstring("640.000"),

      earn: utils.numstring("18.000"),

      workers: 1000,

      id: 5,

      icon: "🌆",
    },

    {
      name: "Главные заводы мира",

      photo: "doc777271147_682500103",

      cost: utils.numstring("670.000"),

      earn: utils.numstring("22.000"),

      workers: 1000,

      id: 5,

      icon: "🌆",
    },

    {
      name: "Главный межпланетный завод",

      photo: "doc777271147_682500103",

      cost: utils.numstring("690.000"),

      earn: utils.numstring("30.000"),

      workers: 1000,

      id: 5,

      icon: "🌆",
    },
  ],

  [
    {
      name: "Угольная шахта",

      photo: "doc777271147_682500112",

      cost: utils.numstring("700.000"),

      earn: utils.numstring("9.000"),

      workers: 50,

      id: 6,

      icon: "🏚",
    },

    {
      name: "Золотая шахта",

      photo: "doc777271147_682500112",

      cost: utils.numstring("740.000"),

      earn: utils.numstring("12.000"),

      workers: 75,

      id: 6,

      icon: "🏚️",
    },

    {
      name: "Алмазная шахта",

      photo: "doc777271147_682500112",

      cost: utils.numstring("780.000"),

      earn: utils.numstring("18.000"),

      workers: 200,

      id: 6,

      icon: "🏚",
    },

    {
      name: "Алмазный карьер",

      photo: "doc777271147_682500112",

      cost: utils.numstring("810.000"),

      earn: utils.numstring("25.000"),

      workers: 360,

      id: 6,

      icon: "🏚",
    },

    {
      name: "Крупнейший алмазный карьер",

      photo: "doc777271147_682500112",

      cost: utils.numstring("820.000"),

      earn: utils.numstring("30.000"),

      workers: 700,

      id: 6,

      icon: "🏚",
    },

    {
      name: "Мировой алмазный карьер",

      photo: "doc777271147_682500112",

      cost: utils.numstring("830.000"),

      earn: utils.numstring("40.000"),

      workers: 700,

      id: 6,

      icon: "🏚",
    },
  ],

  [
    {
      name: "Маленький офис",

      photo: "doc777271147_682500121",

      cost: utils.numstring("840.000"),

      earn: utils.numstring("11.000"),

      workers: 10,

      id: 7,

      icon: "🏢",
    },

    {
      name: "Средний офис",

      photo: "doc777271147_682500121",

      cost: utils.numstring("860.000"),

      earn: utils.numstring("15.000"),

      workers: 60,

      id: 7,

      icon: "🏢",
    },

    {
      name: "Большой офис",

      photo: "doc777271147_682500121",

      cost: utils.numstring("888.000"),

      earn: utils.numstring("22.000"),

      workers: 200,

      id: 7,

      icon: "🏢",
    },

    {
      name: "Офис-небоскрёб",

      photo: "doc777271147_682500121",

      cost: utils.numstring("900.000"),

      earn: utils.numstring("27.000"),

      workers: 700,

      id: 7,

      icon: "🏢",
    },

    {
      name: "Офисный квартал",

      photo: "doc777271147_682500121",

      cost: utils.numstring("935.000"),

      earn: utils.numstring("35.000"),

      workers: 700,

      id: 7,

      icon: "🏢",
    },

    {
      name: "Офисный город",

      photo: "doc777271147_682500121",

      cost: utils.numstring("940.000"),

      earn: utils.numstring("40.000"),

      workers: 700,

      id: 7,

      icon: "🏢",
    },
  ],

  [
    {
      name: "Любительский GameDev",

      photo: "doc777271147_682500137",

      cost: utils.numstring("950.000"),

      earn: utils.numstring("18.000"),

      workers: 5,

      id: 8,

      icon: "🕹",
    },

    {
      name: "Инди GameDev",

      photo: "doc777271147_682500137",

      cost: utils.numstring("1.000.000"),

      earn: utils.numstring("25.000"),

      workers: 10,

      id: 8,

      icon: "🕹",
    },

    {
      name: "AA GameDev",

      photo: "doc777271147_682500137",

      cost: utils.numstring("1.100.000"),

      earn: utils.numstring("35.000"),

      workers: 50,

      id: 8,

      icon: "🕹",
    },

    {
      name: "AAA GameDev",

      photo: "doc777271147_682500137",

      cost: utils.numstring("1.200.000"),

      earn: utils.numstring("42.000"),

      workers: 500,

      id: 8,

      icon: "🕹",
    },

    {
      name: "AAAA GameDev",

      photo: "doc777271147_682500137",

      cost: utils.numstring("1.300.000"),

      earn: utils.numstring("53.000"),

      workers: 500,

      id: 8,

      icon: "🕹",
    },

    {
      name: "AAAAA+ GameDev",

      photo: "doc777271147_682500137",

      cost: utils.numstring("1.400.000"),

      earn: utils.numstring("60.000"),

      workers: 500,

      id: 8,

      icon: "🕹️",
    },
  ],

  [
    {
      name: "Нефтевышка",

      photo: "doc777271147_682500145",

      cost: utils.numstring("1.500.000"),

      earn: utils.numstring("20.000"),

      workers: 8,

      id: 9,

      icon: "🏜",
    },

    {
      name: "Нефтяная платформа в море",

      photo: "doc777271147_682500145",

      cost: utils.numstring("1.800.000"),

      earn: utils.numstring("35.000"),

      workers: 20,

      id: 9,

      icon: "🏜",
    },

    {
      name: "Нефтяная платформа в океане",

      photo: "doc777271147_682500145",

      cost: utils.numstring("2.000.000"),

      earn: utils.numstring("43.000"),

      workers: 50,

      id: 9,

      icon: "🏜",
    },

    {
      name: "5 нефтеплатформ в океанах",

      photo: "doc777271147_682500145",

      cost: utils.numstring("2.100.000"),

      earn: utils.numstring("54.000"),

      workers: 250,

      id: 9,

      icon: "🏜",
    },

    {
      name: "25 нефтеплатформ в океанах",

      photo: "doc777271147_682500145",

      cost: utils.numstring("2.200.000"),

      earn: utils.numstring("67.000"),

      workers: 250,

      id: 9,

      icon: "🏜",
    },

    {
      name: "125 нефтеплатформ в океанах",

      photo: "doc777271147_682500145",

      cost: utils.numstring("2.300.000"),

      earn: utils.numstring("75.000"),

      workers: 250,

      id: 9,

      icon: "🏜",
    },
  ],

  [
    {
      name: "Мини АЭС",

      photo: "doc777271147_682500153",

      cost: utils.numstring("2.500.000"),

      earn: utils.numstring("25.000"),

      workers: 40,

      id: 10,

      icon: "💡",
    },

    {
      name: "Средняя АЭС",

      photo: "doc777271147_682500153",

      cost: utils.numstring("2.700.000"),

      earn: utils.numstring("35.000"),

      workers: 75,

      id: 10,

      icon: "💡",
    },

    {
      name: "АЭС с 5 энергоблоками",

      photo: "doc777271147_682500153",

      cost: utils.numstring("2.900.000"),

      earn: utils.numstring("65.000"),

      workers: 300,

      id: 10,

      icon: "💡",
    },

    {
      name: "Крупнейшая атомная станция",

      photo: "doc777271147_682500153",

      cost: utils.numstring("3.100.000"),

      earn: utils.numstring("75.000"),

      workers: 650,

      id: 10,

      icon: "💡",
    },

    {
      name: "Крупнейший комплекс станций",

      photo: "doc777271147_682500153",

      cost: utils.numstring("3.200.000"),

      earn: utils.numstring("80.000"),

      workers: 650,

      id: 10,

      icon: "💡",
    },
  ],

  [
    {
      name: "Космическое агентство",

      photo: "doc777271147_682500192",

      cost: utils.numstring("3.300.000"),

      earn: utils.numstring("30.000"),

      workers: 100,

      id: 11,

      icon: "🚀",
    },

    {
      name: "Улучшенное космическое агентство",

      photo: "doc777271147_682500192",

      cost: utils.numstring("3.500.000"),

      earn: utils.numstring("55.000"),

      workers: 200,

      id: 11,

      icon: "🚀",
    },

    {
      name: "Продвинутое космическое агентство",

      photo: "doc777271147_682500192",

      cost: utils.numstring("3.800.000"),

      earn: utils.numstring("68.000"),

      workers: 350,

      id: 11,

      icon: "🚀",
    },

    {
      name: "Космическое агентство по полетам на Марс",

      photo: "doc777271147_682500192",

      cost: utils.numstring("4.000.000"),

      earn: utils.numstring("76.000"),

      workers: 650,

      id: 11,

      icon: "🚀",
    },

    {
      name: "Космическое агентство по полетам на Юпитер",

      photo: "doc777271147_682500192",

      cost: utils.numstring("4.200.000"),

      earn: utils.numstring("80.000"),

      workers: 650,

      id: 11,

      icon: "🚀",
    },

    {
      name: "Космическое агентство по полетам на Солнце",

      photo: "doc777271147_682500192",

      cost: utils.numstring("4.400.000"),

      earn: utils.numstring("90.000"),

      workers: 650,

      id: 11,

      icon: "🚀",
    },
  ],

  [
    {
      name: "CleverCodingNinja", // Умный Кодирующий Ниндзя

      photo: "",

      cost: utils.numstring("4.500.000"),

      earn: utils.numstring("30.000"),

      workers: 10000,

      id: 12,

      icon: "🛸",
    },

    {
      name: "NinjaCoderXtreme", // Ниндзя Кодер Крайний

      photo: "",

      cost: utils.numstring("5.000.000"),

      earn: utils.numstring("70.000"),

      workers: 10000,

      id: 12,

      icon: "🚀",
    },

    {
      name: "CodingNinjaElite", // Элитный Кодирующий Ниндзя

      photo: "",

      cost: utils.numstring("5.555.555"),

      earn: utils.numstring("100.000"),

      workers: 10000,

      id: 12,

      icon: "🚀",
    },
  ],
];

module.exports = businesses;
