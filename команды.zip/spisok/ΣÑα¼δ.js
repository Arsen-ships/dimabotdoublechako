const utils = require('../utils.js');

const farms = [
    {
        name: "7U Nvidia",

        cost: 100000000,

        id: 1,
    },

    {
        name: "AntminerS9",

        cost: 2000000000,

        id: 2,
    },

    {
        name: "FM2020-BT400",

        cost: 70000000000,

        id: 3,
    },

    {
        name: "Gеnеsis Mining",

        cost: 500000000000,

        id: 4,
    },

    {
        name: "GigаWаtt",

        cost: 1000000000000,

        id: 5,
    },

    {
        name: "TerraEngine",

        cost: 10000000000000,

        id: 6,
    },

    {
        name: "YotaMiner",

        cost: 50000000000000,

        id: 7,
    },
];


module.exports = farms;
