const utils = require('../utils.js');


const sound = [
    {
        name: "Батины динамики",
        cost: 5000000000,
        min: 10,
        max: 20,
        id: 1,
    },
    {
        name: "SWAT G410TS",
        cost: 25000000000,
        min: 20,
        max: 40,
        id: 2,
    },
    {
        name: "PionnerTX-302AS",
        cost: 50000000000,
        min: 40,
        max: 80,
        id: 3,
    },
    {
        name: "Alphard RTS-455T",
        cost: 100000000000,
        min: 80,
        max: 160,
        id: 4,
    },
    {
        name: "Bulava 250 HTS",
        cost: 250000000000,
        min: 160,
        max: 320,
        id: 5,
    },
    {
        name: "Machette RX-900",
        cost: 500000000000,
        min: 320,
        max: 640,
        id: 6,
    },
    {
        name: "JBL EX-290 GLA 250",
        cost: 1000000000000,
        min: 640,
        max: 960,
        id: 7,
    },
    {
        name: "Bass Sound",
        cost: 5000000000000,
        min: 960,
        max: 1920,
        id: 8,
    },
];

module.exports = sound;
