const utils = require('../utils.js');


const pets2 = [
    {
        name: "Рыжик-Стёпа🐈Стёпа-Рыжик",

        cost: 100,

        min: 50,

        max: 100,

        photo: `photo-211261524_457278281`,

        ico: `🐈`,

        id: 1,
    },
];






module.exports = pets2;

