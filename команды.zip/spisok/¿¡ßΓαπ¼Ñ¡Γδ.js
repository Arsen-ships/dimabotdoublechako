const utils = require('../utils.js');

const minertool = [
    {
        name: "Деревянная кирка",

        cost: 1600000000000,

        id: 1,
    },

    {
        name: "Стальная кирка",

        cost: 10000000000000,

        id: 2,
    },

    {
        name: "Буровая установка",

        cost: 60000000000000,

        id: 3,
    },

    {
        name: "Адронный коллайдер",

        cost: 400000000000000,

        id: 4,
    },

    {
        name: "Разрушитель частиц",

        cost: 1000000000000000,

        id: 5,
    },
];

module.exports = minertool;
