const utils = require('../utils.js');

const phones = [
    {
        name: "Nokia 108",

        cost: 50000,

        id: 1,
    },

    {
        name: "Nokia 3310",

        cost: 500000,

        id: 2,
    },

    {
        name: "BQ Aquaris M5",

        cost: 5000000,

        id: 3,
    },

    {
        name: "ASUS ZenFone 4",

        cost: 6000000,

        id: 4,
    },

    {
        name: "Samsung Galaxy S11",

        cost: 1300000000,

        id: 5,
    },

    {
        name: "Escobar Fold 1",

        cost: 1550000000,

        id: 6,
    },

    {
        name: "iPhone 11 Pro Max",

        cost: 2500000000,

        id: 7,
    },

    {
        name: "Xiaomi Mi Mix Alpha",

        cost: 2600000000,

        id: 8,
    },

    {
        name: "Samsung Galaxy S50+",

        cost: 2800000000,

        id: 9,
    },
];

module.exports = phones;
