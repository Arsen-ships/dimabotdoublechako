const utils = require('../utils.js');

const works = [
    {
        name: "Дворник",

        requiredLevel: 1,

        min: 10000,

        max: 25000,

        id: 1,
    },

    {
        name: "Сантехник",

        requiredLevel: 2,

        min: 50000,

        max: 125000,

        id: 2,
    },

    {
        name: "Электрик",

        requiredLevel: 3,

        min: 250000,

        max: 625000,

        id: 3,
    },

    {
        name: "Слесарь",

        requiredLevel: 4,

        min: 1250000,

        max: 3100000,

        id: 4,
    },

    {
        name: "Юрист",

        requiredLevel: 5,

        min: 6200000,

        max: 15500000,

        id: 5,
    },

    {
        name: "Бухгалтер",

        requiredLevel: 7,

        min: 31000000,

        max: 77000000,

        id: 6,
    },

    {
        name: "Бармен",

        requiredLevel: 10,

        min: 144000000,

        max: 360000000,

        id: 7,
    },

    {
        name: "Администратор",

        requiredLevel: 15,

        min: 720000000,

        max: 1800000000,

        id: 8,
    },

    {
        name: "Программист",

        requiredLevel: 20,

        min: 3600000000,

        max: 9000000000,

        id: 9,
    },

    {
        name: "Главный Программист",

        requiredLevel: 25,

        min: 18000000000,

        max: 45000000000,

        id: 10,
    },

    {
        name: "Директор",

        requiredLevel: 35,

        min: 90000000000,

        max: 230000000000,

        id: 11,
    },

    {
        name: "Президент",

        requiredLevel: 50,

        min: 500000000000,

        max: 1000000000000,

        id: 12,
    },

    {
        name: "Мафиози",

        requiredLevel: 100,

        min: 1000000000000,

        max: 2000000000000,

        id: 13,
    },

    {
        name: "Шахтер",

        requiredLevel: 500,

        min: 2000000000000,

        max: 3000000000000,

        id: 14,
    },

    {
        name: "Создатель Чако",

        requiredLevel: 1000,

        min: 5000000000000,

        max: 6000000000000,

        id: 15,
    },
];

module.exports = works;
