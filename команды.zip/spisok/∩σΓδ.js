const utils = require('../utils.js');

const yachts = [
    {
        name: "Ванна",

        cost: 10000000000,

        id: 1,
    },

    {
        name: "Nauticat 331",

        cost: 10000000000000,

        id: 2,
    },

    {
        name: "Nordhavn 56 MS",

        cost: 15000000000000,

        id: 3,
    },

    {
        name: "Princess 60",

        cost: 25000000000000,

        id: 4,
    },

    {
        name: "Azimut 70",

        cost: 35000000000000,

        id: 5,
    },

    {
        name: "Dominator 40M",

        cost: 50000000000000,

        id: 6,
    },

    {
        name: "Moonen 124",

        cost: 60000000000000,

        id: 7,
    },

    {
        name: "Wider 150",

        cost: 65000000000000,

        id: 8,
    },

    {
        name: "Palmer Johnson 42M SuperSport",

        cost: 80000000000000,

        id: 9,
    },

    {
        name: "Wider 165",

        cost: 85000000000000,

        id: 10,
    },

    {
        name: "Eclipse",

        cost: 150000000000000,

        id: 11,
    },

    {
        name: "Dubai",

        cost: 300000000000000,

        id: 12,
    },

    {
        name: "Streets of Monaco",

        cost: 750000000000000,

        id: 13,
    },
];

module.exports = yachts;
