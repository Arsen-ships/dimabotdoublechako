const utils = require('../utils.js');


const homes = [
    {
        name: "Деревенский домик",

        cost: 500000000000,

        id: 1,
    },

    {
        name: "Маленький домик",

        cost: 7000000000000,

        id: 2,
    },

    {
        name: "Особняк в центре города",

        cost: 50000000000000,

        id: 3,
    },

    {
        name: "Загородный дом",

        cost: 200000000000000,

        id: 4,
    },

    {
        name: "Дом Тима Кука",

        cost: 800000000000000,

        id: 5,
    },
];

module.exports = homes;
