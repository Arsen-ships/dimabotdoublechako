const utils = require('../utils.js');

const helicopters = [
    {
        name: "Шарик с пропеллером",

        cost: 150000000000,

        id: 1,
    },

    {
        name: "RotorWay Exec 162F",

        cost: 300000000000,

        id: 2,
    },

    {
        name: "Robinson R44",

        cost: 450000000000,

        id: 3,
    },

    {
        name: "Hiller UH-12C",

        cost: 1300000000000,

        id: 4,
    },

    {
        name: "AW119 Koala",

        cost: 2500000000000,

        id: 5,
    },

    {
        name: "MBB BK 117",

        cost: 4000000000000,

        id: 6,
    },

    {
        name: "Eurocopter EC130",

        cost: 7500000000000,

        id: 7,
    },

    {
        name: "Leonardo AW109 Power",

        cost: 10000000000000,

        id: 8,
    },

    {
        name: "Sikorsky S-76",

        cost: 15000000000000,

        id: 9,
    },

    {
        name: "Bell 429WLG",

        cost: 19000000000000,

        id: 10,
    },

    {
        name: "NHI NH90",

        cost: 35000000000000,

        id: 11,
    },

    {
        name: "Kazan Mi-35M",

        cost: 60000000000000,

        id: 12,
    },

    {
        name: "Bell V-22 Osprey",

        cost: 135000000000000,

        id: 13,
    },
];

module.exports = helicopters;
