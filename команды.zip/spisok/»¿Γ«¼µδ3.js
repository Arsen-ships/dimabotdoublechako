const utils = require('../utils.js');


const pets3 = [
    {
        name: "Пальма",

        cost: 100,

        min: 75,

        max: 125,

        photo: `photo-211261524_457301426`,

        ico: `🐈`,

        id: 1,
    },
];

module.exports = pets3;
