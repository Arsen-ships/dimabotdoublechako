const utils = require('../utils.js');

const computers = [
    {
        name: "DЕXР Аquilоn О175",

        cost: 10000,

        id: 1,
    },

    {
        name: "HYРЕRРС NЕО",

        cost: 500000,

        id: 2,
    },

    {
        name: "DЕLL Аliеnwаrе Аurоrа R7",

        cost: 1000000,

        id: 3,
    },

    {
        name: "HYРЕRРС СОSMОS X 3",

        cost: 3000000,

        id: 4,
    },

    {
        name: "HYРЕRРС РRЕMIUM",

        cost: 5000000,

        id: 5,
    },
];


module.exports = computers;
