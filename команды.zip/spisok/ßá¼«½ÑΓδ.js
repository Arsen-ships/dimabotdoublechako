const utils = require('../utils.js');

const airplanes = [
    {
        name: "Параплан",

        cost: 100000000000,

        id: 1,
    },

    {
        name: "АН-2",

        cost: 350000000000,

        id: 2,
    },

    {
        name: "Cessna-172E",

        cost: 700000000000,

        id: 3,
    },

    {
        name: "Supermarine Spitfire",

        cost: 1000000000000,

        id: 4,
    },

    {
        name: "BRM NG-5",

        cost: 1400000000000,

        id: 5,
    },

    {
        name: "Cessna T210",

        cost: 2600000000000,

        id: 6,
    },

    {
        name: "Beechcraft 1900D",

        cost: 5500000000000,

        id: 7,
    },

    {
        name: "Cessna 550",

        cost: 8000000000000,

        id: 8,
    },

    {
        name: "Hawker 4000",

        cost: 22400000000000,

        id: 9,
    },

    {
        name: "Learjet 31",

        cost: 45000000000000,

        id: 10,
    },

    {
        name: "Airbus A318",

        cost: 85000000000000,

        id: 11,
    },

    {
        name: "F-35A",

        cost: 160000000000000,

        id: 12,
    },

    {
        name: "Boeing 747-430 Custom",

        cost: 225000000000000,

        id: 13,
    },

    {
        name: "C-17A Globemaster III",

        cost: 350000000000000,

        id: 14,
    },

    {
        name: "F-22 Raptor",

        cost: 400000000000000,

        id: 15,
    },

    {
        name: "Airbus 380 Custom",

        cost: 600000000000000,

        id: 16,
    },

    {
        name: "B-2 Spirit Stealth Bomber",

        cost: 1359000000000000,

        id: 17,
    },
];

module.exports = airplanes;
